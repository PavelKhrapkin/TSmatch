namespace ZetaResourceEditor.Code.DL
{
	using System.IO;

	public enum GridSourceType
	{
		Project,
		ProjectFolder,
		FileGroup
	}

	/// <summary>
	/// Something that is editable in a grid.
	/// </summary>
	public interface IGridEditableData
	{
		GridSourceType SourceType { get; }

		/// <summary>
		/// Is NULL if no real file group.
		/// </summary>
		FileGroup FileGroup { get; }

		Project Project { get; set; }
		DirectoryInfo FolderPath { get; }

		FileFileInfo[] GetFileFileInfosSorted();
		//void SortFileFileFileInfos();

		IInheritedSettings ParentSettings { get; }
		FileGroupStates InMemoryState { get; set; }
		string JoinedFilePaths { get; }
		string[] FilePaths { get; }
		string GetNameIntelligent(Project project);
		string GetFullNameIntelligent(Project project);
		long GetChecksum(Project project);
		string[] GetLanguageCodes(Project project);
	}
}