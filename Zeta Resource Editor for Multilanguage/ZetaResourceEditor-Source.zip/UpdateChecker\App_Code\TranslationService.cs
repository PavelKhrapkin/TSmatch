﻿using System;
using System.Web.Services;
using Zeta.EnterpriseLibrary.Logging;

/////////////////////////////////////////////////////////////////////////////

[WebService(Namespace = @"http://www.zeta-resource-editor.com/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class TranslationService :
	ApiKeyProtectedWebServiceBase
{
	#region Private configuration settings.
	// ----------------------------------------------------------------------

	private static readonly string _googleUrl = @"http://translate.google.com/translate_t";
	private static readonly string _googleRefererUrl = @"http://translate.google.com/";
    private static readonly string _parseRegexPattern = @"<input type=hidden name=gtrans value=\""(.*?)\"">"; // AJ CHANGE @"<span.*?id=.{0,1}result_box.{0,1}[^>]*?>(.*?)</span>";
	private static readonly string _httpPostData =
		@"?action=Translate&client=t&hl=en&ie=UTF-8&source={TextToTranslate}&text={TextToTranslate}&langpair={SourceLanguageCode}/{DestinationLanguageCode}&sl={SourceLanguageCode}&tl={DestinationLanguageCode}&old_sl={SourceLanguageCode}&old_tl={DestinationLanguageCode}&old_submit=Translate";

	private readonly TranslationMode3[] _validSourceTranslationModes =
		new[]
			{
				new TranslationMode3(@"auto"),
				new TranslationMode3(@"af"),
				new TranslationMode3(@"sq"),
				new TranslationMode3(@"ar"),
				new TranslationMode3(@"bg"),
				new TranslationMode3(@"zh-CN"),
				new TranslationMode3(@"da"),
				new TranslationMode3(@"de"),
				new TranslationMode3(@"en"),
				new TranslationMode3(@"et"),
				new TranslationMode3(@"fi"),
				new TranslationMode3(@"fr"),
				new TranslationMode3(@"gl"),
				new TranslationMode3(@"el"),
				//new TranslationMode3(@"iw"),
				new TranslationMode3(@"hi"),
				new TranslationMode3(@"id"),
				//new TranslationMode3(@"ga"),
				new TranslationMode3(@"is"),
				new TranslationMode3(@"it"),
				new TranslationMode3(@"ja"),
				//new TranslationMode3(@"yi"),
				new TranslationMode3(@"ca"),
				new TranslationMode3(@"ko"),
				new TranslationMode3(@"hr"),
				new TranslationMode3(@"lv"),
				new TranslationMode3(@"lt"),
				new TranslationMode3(@"ms"),
				//new TranslationMode3(@"mt"),
				new TranslationMode3(@"mk"),
				new TranslationMode3(@"nl"),
				new TranslationMode3(@"no"),
				new TranslationMode3(@"fa"),
				new TranslationMode3(@"pl"),
				new TranslationMode3(@"pt"),
				new TranslationMode3(@"ro"),
				new TranslationMode3(@"ru"),
				new TranslationMode3(@"sv"),
				new TranslationMode3(@"sr"),
				new TranslationMode3(@"sk"),
				new TranslationMode3(@"sl"),
				new TranslationMode3(@"es"),
				new TranslationMode3(@"sw"),
				//new TranslationMode3(@"tl"),
				new TranslationMode3(@"th"),
				new TranslationMode3(@"cs"),
				new TranslationMode3(@"tr"),
				new TranslationMode3(@"uk"),
				new TranslationMode3(@"hu"),
				new TranslationMode3(@"vi"),
				//new TranslationMode3(@"cy"),
				new TranslationMode3(@"be"),
			};

	private readonly TranslationMode3[] _validDestinationTranslationModes =
		new[]
			{
				new TranslationMode3(@"af"),
				new TranslationMode3(@"sq"),
				new TranslationMode3(@"ar"),
				new TranslationMode3(@"bg"),
				new TranslationMode3(@"zh-TW"),
				new TranslationMode3(@"zh-CN"),
				new TranslationMode3(@"da"),
				new TranslationMode3(@"de"),
				new TranslationMode3(@"en"),
				new TranslationMode3(@"et"),
				new TranslationMode3(@"fi"),
				new TranslationMode3(@"fr"),
				new TranslationMode3(@"gl"),
				new TranslationMode3(@"el"),
				//new TranslationMode3(@"iw"),
				new TranslationMode3(@"hi"),
				new TranslationMode3(@"id"),
				//new TranslationMode3(@"ga"),
				new TranslationMode3(@"is"),
				new TranslationMode3(@"it"),
				new TranslationMode3(@"ja"),
				//new TranslationMode3(@"yi"),
				new TranslationMode3(@"ca"),
				new TranslationMode3(@"ko"),
				new TranslationMode3(@"hr"),
				new TranslationMode3(@"lv"),
				new TranslationMode3(@"lt"),
				new TranslationMode3(@"ms"),
				//new TranslationMode3(@"mt"),
				new TranslationMode3(@"mk"),
				new TranslationMode3(@"nl"),
				new TranslationMode3(@"no"),
				new TranslationMode3(@"fa"),
				new TranslationMode3(@"pl"),
				new TranslationMode3(@"pt"),
				new TranslationMode3(@"ro"),
				new TranslationMode3(@"ru"),
				new TranslationMode3(@"sv"),
				new TranslationMode3(@"sr"),
				new TranslationMode3(@"sk"),
				new TranslationMode3(@"sl"),
				new TranslationMode3(@"es"),
				new TranslationMode3(@"sw"),
				//new TranslationMode3(@"tl"),
				new TranslationMode3(@"th"),
				new TranslationMode3(@"cs"),
				new TranslationMode3(@"tr"),
				new TranslationMode3(@"uk"),
				new TranslationMode3(@"hu"),
				new TranslationMode3(@"vi"),
				//new TranslationMode3(@"cy"),
				new TranslationMode3(@"be"),
			};

	// ----------------------------------------------------------------------
	#endregion

	#region Public web methods.
	// ----------------------------------------------------------------------

	/// <summary>
	/// Get a list of all valid source translation modes.
	/// </summary>
	/// <returns></returns>
	[WebMethod]
	public TranslationMode3[] GetAllSourceTranslationModes()
	{
		try
		{
			return _validSourceTranslationModes;
		}
		catch (Exception x)
		{
			LogCentral.Current.LogError(
				@"Error getting source translation modes.",
				x);
			throw;
		}
	}

	/// <summary>
	/// Get a list of all valid destination translation modes.
	/// </summary>
	/// <returns></returns>
	[WebMethod]
	public TranslationMode3[] GetAllDestinationTranslationModes()
	{
		try
		{
			return _validDestinationTranslationModes;
		}
		catch (Exception x)
		{
			LogCentral.Current.LogError(
				@"Error getting destination translation modes.",
				x);
			throw;
		}
	}

	[WebMethod]
	public SelfTranslationInformation GetSelfTranslationInformation()
	{
		try
		{
			var info =
				new SelfTranslationInformation
					{
						GoogleUrl = _googleUrl,
						GoogleRefererUrl = _googleRefererUrl,
						ParseRegexPattern = _parseRegexPattern,
						HttpPostData = _httpPostData
					};

			return info;
		}
		catch (Exception x)
		{
			LogCentral.Current.LogError(
				@"Error getting destination self translation information.",
				x);
			throw;
		}
	}

	// ----------------------------------------------------------------------
	#endregion
}

/////////////////////////////////////////////////////////////////////////////

/// <summary>
/// Helper class for details about a translation mode.
/// </summary>
public struct TranslationMode3
{
	#region Public methods.
	// ----------------------------------------------------------------------

	/// <summary>
	/// Initializes a new instance of the <see cref="TranslationMode3"/> struct.
	/// </summary>
	/// <param name="languageCode" ),The language code.</param>
	public TranslationMode3(
		string languageCode)
	{
		LanguageCode = languageCode;
	}

	// ----------------------------------------------------------------------
	#endregion

	#region Public variables.
	// ----------------------------------------------------------------------

	public string LanguageCode;

	// ----------------------------------------------------------------------
	#endregion
}

/////////////////////////////////////////////////////////////////////////////

public struct SelfTranslationInformation
{
	public string GoogleUrl;
	public string GoogleRefererUrl;
	public string ParseRegexPattern;
	public string HttpPostData;
}

/////////////////////////////////////////////////////////////////////////////
