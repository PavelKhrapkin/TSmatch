﻿using System;
using System.Configuration;
using System.Web.Services;

public class ApiKeyProtectedWebServiceBase :
	WebService
{
	private static string referenceApiKey
	{
		get
		{
			return ConfigurationManager.AppSettings[@"wsApiKey"];
		}
	}

	protected void CheckThrowApiKey(
		string apiKey)
	{
		if (string.IsNullOrEmpty(apiKey))
		{
			throw new ArgumentException("API key cannot be NULL or empty.", @"apiKey");
		}
		else if (string.Compare(apiKey, referenceApiKey, true) != 0)
		{
			throw new Exception("Invalid API key.");
		}
	}
}