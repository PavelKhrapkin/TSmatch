namespace ZetaResourceEditor.UI.Main
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System;
	using System.Collections.Generic;
	using System.ComponentModel;
	using System.Diagnostics;
	using System.Globalization;
	using System.IO;
	using System.Reflection;
	using System.Windows.Forms;
	using Code.App;
	using Code.DL;
	using Code.Helper;
	using Code.Misc.Events;
	using DevExpress.XtraBars;
	using DevExpress.XtraEditors;
	using ExportImport;
	using Helper.Base;
	using LeftTree;
	using Properties;
	using RightContent;
	using Tools;
	using Translation;
	using Zeta.EnterpriseLibrary.Common;
	using Zeta.EnterpriseLibrary.Common.IO;
	using Zeta.EnterpriseLibrary.Logging;
	using Zeta.EnterpriseLibrary.Tools.Storage;
	using Zeta.EnterpriseLibrary.Windows.Common;

	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// 
	/// </summary>
	public partial class MainForm :
		RibbonFormBase
	{
		private static MainForm _current;

		public void NotifyFileGroupStateChanged(IGridEditableData gridEditableData)
		{
			FileGroupStateChanged.Raise(this, new FileGroupStateChangedEventArgs(gridEditableData));
		}

		private FastSmartWeakEvent<EventHandler<FileGroupStateChangedEventArgs>> _fileGroupStateChanged;

		public FastSmartWeakEvent<EventHandler<FileGroupStateChangedEventArgs>> FileGroupStateChanged
		{
			get
			{
				// ReSharper disable ConvertIfStatementToNullCoalescingExpression
				if (_fileGroupStateChanged == null)
				// ReSharper restore ConvertIfStatementToNullCoalescingExpression
				{
					_fileGroupStateChanged =
						new FastSmartWeakEvent<EventHandler<FileGroupStateChangedEventArgs>>();
				}

				return _fileGroupStateChanged;
			}
		}

		#region Properties
		// ------------------------------------------------------------------

		/// <summary>
		/// Current instance.
		/// </summary>
		/// <value>The current instance.</value>
		public static MainForm Current
		{
			get
			{
				return _current;
			}
		}

		/// <summary>
		/// Gets the user storage or as a fall back the global storage.
		/// </summary>
		/// <value>The user storage intelligent.</value>
		public static IPersistentPairStorage UserStorageIntelligent
		{
			get
			{
				if (_current == null ||
					_current.ProjectFilesControl == null ||
					_current.ProjectFilesControl.Project == null ||
					_current.ProjectFilesControl.Project.DynamicSettingsUser == null)
				{
					return FormHelper.Storage;
				}
				else
				{
					return _current.ProjectFilesControl.Project.DynamicSettingsUser;
				}
			}
		}

		/// <summary>
		/// Gets the project files control.
		/// </summary>
		/// <value>The project files control.</value>
		internal ProjectFilesUserControl ProjectFilesControl
		{
			get
			{
				return projectFilesUserControl;
			}
		}

		/// <summary>
		/// Gets the group files control.
		/// </summary>
		/// <value>The group files control.</value>
		internal GroupFilesUserControl GroupFilesControl
		{
			get
			{
				return groupFilesControl;
			}
		}

		// ------------------------------------------------------------------
		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="MainForm"/> class.
		/// </summary>
		public MainForm()
		{
			InitializeComponent();
			_current = this;

			//if (!DesignMode)
			//{
			//    // http://community.devexpress.com/forums/t/80133.aspx

			//    DevExpress.UserSkins.BonusSkins.Register();
			//    DefaultLookAndFeel.LookAndFeel.SetSkinStyle(@"Seven Classic");
			//}
		}

		/// <summary>
		/// Saves the changes back to the XML files
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void saveToolStripMenuItem_Click(
			object sender,
			ItemClickEventArgs e)
		{
			SaveWithDialog();
			UpdateUI();
		}

		internal void SaveWithDialog()
		{
			if (groupFilesControl.CurrentFileGroupControl != null)
			{
				groupFilesControl.CurrentFileGroupControl.DoSaveFiles(
					SaveOptions.None);
			}
		}

		/// <summary>
		/// Opens the "Open Files" Dialog, and calls the method to 
		/// fill the Grid.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void openToolStripMenuItem_Click(
			object sender,
			ItemClickEventArgs e)
		{
			groupFilesControl.OpenWithDialog();
			UpdateUI();
		}

		#region MRU handling, both for files and projects.
		// ------------------------------------------------------------------

		private const int MruMaxCharSize = 250;
		private const int MruMaxMruItems = 16;

		private void loadMruFileFiles()
		{
			barSubRecentFiles.ItemLinks.Clear();

			var files = coreLoadMruFileFiles();

			if (files.Length <= 0)
			{
				barSubRecentFiles.Visibility = BarItemVisibility.Never;
				barSubRecentFiles.Enabled = false;
			}
			else
			{
				barSubRecentFiles.Visibility = BarItemVisibility.Always;
				barSubRecentFiles.Enabled = true;

				var index = 0;
				foreach (var file in files)
				{
					var splitted = FileGroup.SplitFilePaths(file);

					if (splitted.Length > 0)
					{
						var bbi =
							new BarButtonItem
								{
									Caption =
										string.Format(
										@"{0} {1}",
										index + 1,
										ZrePathHelper.ShortenPathName(
											splitted[0],
											MruMaxCharSize)),
									Tag = file,
									Enabled = true,
									Visibility = BarItemVisibility.Always,
									LargeImageIndex = 41
								};

						bbi.ItemClick += bbi_ItemClick;

						barSubRecentFiles.ItemLinks.Add(bbi);

						index++;
					}
				}

				// --

				if (barSubRecentFiles.ItemLinks.Count > 0)
				{
					var bbi =
						new BarButtonItem
						{
							Caption =
								Resources.SR_MainFormNew_loadMruFileFiles_ClearRecentFilesList,
							Description = Resources.SR_MainFormNew_loadMruFileProjects_RemovesAllItemsFromTheListAbove,
							Enabled = true,
							Visibility = BarItemVisibility.Always
						};

					bbi.ItemClick +=
						delegate
						{
							coreStoreMruFileFiles(new string[] { });
							UpdateUI();
							loadMruFileFiles();
						};

					barSubRecentFiles.ItemLinks.Add(bbi, true);
				}
			}
		}

		private void loadMruFileProjects()
		{
			barSubRecentProjects.ItemLinks.Clear();

			var files = coreLoadMruProjectFiles();

			if (files.Length <= 0)
			{
				barSubRecentProjects.Visibility = BarItemVisibility.Never;
				barSubRecentProjects.Enabled = false;
			}
			else
			{
				barSubRecentProjects.Visibility = BarItemVisibility.Always;
				barSubRecentProjects.Enabled = true;

				var index = 0;
				foreach (var file in files)
				{
					var bbi =
						new BarButtonItem
						{
							Caption =
								string.Format(
								@"{0} {1}",
								index + 1,
								ZrePathHelper.ShortenPathName(
									file,
									MruMaxCharSize)),
							Tag = file,
							Enabled = true,
							Visibility = BarItemVisibility.Always,
							LargeImageIndex = 40
						};

					bbi.ItemClick += bbi_ItemClick2;

					barSubRecentProjects.ItemLinks.Add(bbi);

					index++;
				}

				// --

				if (barSubRecentProjects.ItemLinks.Count > 0)
				{
					var bbi =
						new BarButtonItem
						{
							Caption =
								Resources.SR_MainFormNew_loadMruFileProjects_ClearRecentProjectsList,
							Description = Resources.SR_MainFormNew_loadMruFileProjects_RemovesAllItemsFromTheListAbove,
							Enabled = true,
							Visibility = BarItemVisibility.Always
						};

					bbi.ItemClick +=
						delegate
						{
							coreStoreMruProjectFiles(new string[] { });
							UpdateUI();
							loadMruFileProjects();
						};

					barSubRecentProjects.ItemLinks.Add(bbi, true);
				}
			}
		}

		private void bbi_ItemClick(object sender, ItemClickEventArgs e)
		{
			var paths = FileGroup.SplitFilePaths((string)e.Item.Tag);

			if (paths.Length > 0)
			{
				DialogResult r;
				if (groupFilesControl.CurrentFileGroupControl != null)
				{
					r = groupFilesControl.CurrentFileGroupControl.DoSaveFiles(
						SaveOptions.OnlyIfModified |
						SaveOptions.AskConfirm);
				}
				else
				{
					r = DialogResult.OK;
				}

				if (r == DialogResult.OK)
				{
					addMruFilesFile(FileGroup.JoinFilePaths(paths));
					//_mruFilesMenu.SetFirstFile( e.Number );

					groupFilesControl.DoLoadFiles(
						FileGroup.CheckCreate(
							ProjectFilesControl.Project,
							paths));
				}
			}
			else
			{
				removeMruFilesFile(FileGroup.JoinFilePaths(paths));
				//_mruFilesMenu.RemoveFile( e.Number );
			}
			UpdateUI();
		}

		private void bbi_ItemClick2(object sender, ItemClickEventArgs e)
		{
			var path = (string)e.Item.Tag;

			if (!string.IsNullOrEmpty(path))
			{
				DialogResult r;

				if (groupFilesControl.CurrentFileGroupControl != null)
				{
					r = groupFilesControl.CurrentFileGroupControl.DoSaveFiles(
						SaveOptions.OnlyIfModified |
						SaveOptions.AskConfirm);
				}
				else
				{
					r = DialogResult.OK;
				}

				if (r == DialogResult.OK)
				{
					//_mruProjectsMenu.SetFirstFile( e.Number );
					addMruProjectFile(path);

					ProjectFilesControl.DoLoadProject(new FileInfo(path));
				}
			}
			else
			{
				//_mruProjectsMenu.RemoveFile( e.Number );
				removeMruProjectFile(path);
			}
			UpdateUI();
		}

		private static string[] coreLoadMruFileFiles()
		{
			var paths =
				ConvertHelper.ToString(
					FormHelper.RestoreValue(
						@"Mru.FileFiles",
						string.Empty),
					string.Empty);

			var result = new List<string>(
				paths.Split(new[] { @"###~~~###" },
				StringSplitOptions.RemoveEmptyEntries));

			while (result.Count > MruMaxMruItems)
			{
				result.RemoveAt(result.Count - 1);
			}

			return result.ToArray();
		}

		private static void coreStoreMruFileFiles(
			string[] paths)
		{
			var splitted =
				paths == null || paths.Length < 0
					? string.Empty
					: string.Join(@"###~~~###", paths);

			FormHelper.SaveValue(@"Mru.FileFiles", splitted);
		}

		private static string[] coreLoadMruProjectFiles()
		{
			var paths =
				ConvertHelper.ToString(
					FormHelper.RestoreValue(
						@"Mru.ProjectFiles",
						string.Empty),
					string.Empty);

			var result = new List<string>(
				paths.Split(new[] { @"###~~~###" },
				StringSplitOptions.RemoveEmptyEntries));

			while (result.Count > MruMaxMruItems)
			{
				result.RemoveAt(result.Count - 1);
			}

			return result.ToArray();
		}

		private static void coreStoreMruProjectFiles(
			string[] paths)
		{
			var splitted =
				paths == null || paths.Length < 0
					? string.Empty
					: string.Join(@"###~~~###", paths);

			FormHelper.SaveValue(@"Mru.ProjectFiles", splitted);
		}

		private static void addMruFilesFile(
			string file)
		{
			if (!string.IsNullOrEmpty(file))
			{
				var items = new List<string>(coreLoadMruFileFiles());

				for (var index = 0; index < items.Count; ++index)
				{
					if (string.Compare(items[index], file, true) == 0)
					{
						items.RemoveAt(index);
						break;
					}
				}

				//if ( File.Exists( file ) )
				{
					items.Insert(0, file);
				}

				coreStoreMruFileFiles(items.ToArray());
			}
		}

		private static void addMruProjectFile(
			string file)
		{
			if (!string.IsNullOrEmpty(file))
			{
				var items = new List<string>(coreLoadMruProjectFiles());

				for (var index = 0; index < items.Count; ++index)
				{
					if (string.Compare(items[index], file, true) == 0)
					{
						items.RemoveAt(index);
						break;
					}
				}

				if (File.Exists(file))
				{
					items.Insert(0, file);
				}

				coreStoreMruProjectFiles(items.ToArray());
			}
		}

		private static void removeMruFilesFile(
			string file)
		{
			if (!string.IsNullOrEmpty(file))
			{
				var items = new List<string>(coreLoadMruFileFiles());

				for (var index = 0; index < items.Count; ++index)
				{
					if (string.Compare(items[index], file, true) == 0)
					{
						items.RemoveAt(index);
						break;
					}
				}

				coreStoreMruFileFiles(items.ToArray());
			}
		}

		private static void removeMruProjectFile(
			string file)
		{
			if (!string.IsNullOrEmpty(file))
			{
				var items = new List<string>(coreLoadMruProjectFiles());

				for (var index = 0; index < items.Count; ++index)
				{
					if (string.Compare(items[index], file, true) == 0)
					{
						items.RemoveAt(index);
						break;
					}
				}

				coreStoreMruProjectFiles(items.ToArray());
			}
		}

		public static void AddMruFiles(string files)
		{
			addMruFilesFile(files);
		}

		public static void AddMruProject(string file)
		{
			addMruProjectFile(file);
		}

		// ------------------------------------------------------------------
		#endregion

		private void aboutZetaResxEditorToolStripMenuItem_Click(
			object sender,
			ItemClickEventArgs e)
		{
			using (var about = new AboutForm())
			{
				about.ShowDialog(this);
			}
			UpdateUI();
		}

		/// <summary>
		/// Changes an tag in the XML doc.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void renameTagToolStripMenuItem_Click(
			object sender,
			ItemClickEventArgs e)
		{
			groupFilesControl.CurrentFileGroupControl.RenameTag();
			UpdateUI();
		}

		/// <summary>
		/// Delete a tag
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance 
		/// containing the event data.</param>
		private void deleteTagToolStripMenuItem_Click(
			object sender,
			ItemClickEventArgs e)
		{
			groupFilesControl.CurrentFileGroupControl.DeleteTag();
			UpdateUI();
		}

		/// <summary>
		/// Add a tag
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void addTagToolStripMenuItem_Click(
			object sender,
			ItemClickEventArgs e)
		{
			groupFilesControl.CurrentFileGroupControl.AddTag();
			UpdateUI();
		}

		/// <summary>
		/// Open the Options form
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void optionsToolStripMenuItem1_Click(
			object sender,
			ItemClickEventArgs e)
		{
			using (var form = new OptionsForm())
			{
				form.ShowDialog(this);
			}

			UpdateUI();
		}

		/// <summary>
		/// Closes the opened files
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void closeToolStripMenuItem_Click(
			object sender,
			ItemClickEventArgs e)
		{
			groupFilesControl.CloseAndSaveDataGrid();
			UpdateUI();
		}

		/// <summary>
		/// 2009-06-12, Uwe Keim:
		/// For now, disabled, until finished with coding.
		/// </summary>
		private const bool CanImportExport = true;

		/// <summary>
		/// Updates the UserControls
		/// </summary>
		public override void UpdateUI()
		{
			base.UpdateUI();

			groupImportExport.Enabled =
				/*groupFilesControl.CurrentFileGroupControl != null ||*/
				projectFilesUserControl.Project != null;

			buttonExport.Enabled = buttonImport.Enabled = CanImportExport;

			buttonSaveResourceFiles.Enabled =
				groupFilesControl.CanSave;
			buttonCloseResourceFiles.Enabled =
				groupFilesControl.CanClose;
			buttonAddNewTag.Enabled =
					groupFilesControl.CurrentFileGroupControl != null &&
						groupFilesControl.CurrentFileGroupControl.CanAddTag;
			buttonDeleteTag.Enabled =
					groupFilesControl.CurrentFileGroupControl != null &&
						groupFilesControl.CurrentFileGroupControl.CanDeleteTag;
			buttonRenameTag.Enabled =
					groupFilesControl.CurrentFileGroupControl != null &&
						groupFilesControl.CurrentFileGroupControl.CanRenameTag;

			buttonTranslateMissingLanguages.Enabled =
				groupFilesControl.CurrentFileGroupControl != null &&
						groupFilesControl.CurrentFileGroupControl.CanAutoTranslateMissingTranslations;

			buttonCloseAllDocuments.Enabled =
				groupFilesControl.CanCloseAllDocuments;

			buttonOpenFileGroupFolder.Enabled =
				groupFilesControl.CanOpenFolderOfCurrentResourceFile;

			buttonOpenProjectFile.Enabled =
				ProjectFilesControl != null && ProjectFilesUserControl.CanOpenProjectFile;
			buttonSaveProjectFile.Enabled =
				ProjectFilesControl != null && ProjectFilesControl.CanSaveProjectFile;
			buttonCloseProject.Enabled =
				ProjectFilesControl != null && ProjectFilesControl.CanCloseProjectFile;
			buttonAddFilesToFileGroup.Enabled =
				ProjectFilesControl != null && ProjectFilesControl.CanAddFilesToFileGroup;
			buttonRemoveFileFromGroup.Enabled =
				ProjectFilesControl != null && ProjectFilesControl.CanRemoveFileFromFileGroup;
			buttonCreateNewFile.Enabled =
				ProjectFilesControl != null && ProjectFilesControl.CanCreateNewFile;
			buttonCreateNewFiles.Enabled =
				ProjectFilesControl != null && ProjectFilesControl.CanCreateNewFiles;

			buttonEditFileGroupSettings.Enabled =
				ProjectFilesControl != null && ProjectFilesControl.CanEditFileGroupSettings;

			buttonCreateNewProject.Enabled =
				ProjectFilesControl != null && ProjectFilesUserControl.CanCreateNewProject;
			buttonAddFileGroupToProject.Enabled =
				buttonAutomaticallyAddFileGroupsToProject.Enabled =
				buttonAddFromVisualStudio.Enabled =
				ProjectFilesControl != null && ProjectFilesControl.CanAddResourceFilesToProject;
			buttonRemoveFileGroupFromProject.Enabled =
				ProjectFilesControl != null && ProjectFilesControl.CanRemoveResourceFilesFromProject;
			buttonEditProjectSettings.Enabled =
				ProjectFilesControl != null && ProjectFilesControl.CanEditProjectSettings;

			buttonFind.Enabled =
					groupFilesControl.CurrentFileGroupControl != null &&
						groupFilesControl.CurrentFileGroupControl.CanFind;
			buttonFindNext.Enabled =
					groupFilesControl.CurrentFileGroupControl != null &&
						groupFilesControl.CurrentFileGroupControl.CanFindNext;

			buttonRefresh.Enabled =
				ProjectFilesControl != null && ProjectFilesControl.CanRefresh;

			buttonMoveUp.Enabled =
				ProjectFilesControl != null && ProjectFilesControl.CanMoveUp;
			buttonMoveDown.Enabled =
				ProjectFilesControl != null && ProjectFilesControl.CanMoveDown;

			if (mainFormMainSplitContainer.PanelVisibility ==
				SplitPanelVisibility.Both)
			{
				buttonShowHideProjectPanel.Caption =
					Resources.SR_MainForm_UpdateUI_HideProjectPanel;
				buttonShowHideProjectPanel.Down = true;
			}
			else
			{
				buttonShowHideProjectPanel.Caption =
					Resources.SR_MainForm_UpdateUI_ShowProjectPanel;
				buttonShowHideProjectPanel.Down = false;
			}

			resetLayoutButton.Enabled =
				groupFilesControl != null && groupFilesControl.CanResetLayout;
		}

		/// <summary>
		/// Handles the Load event of the <see cref="MainForm"/> control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance 
		/// containing the event data.</param>
		private void mainForm_Load(
			object sender,
			EventArgs e)
		{
			DataProcessing.CanOverwrite += dataProcessing_CanOverwrite;

			FormHelper.RestoreState(this);
			CenterToScreen();

			ribbon.SelectedPage = ribbonPage1;
			FormBase.RestoreState(mainFormMainSplitContainer);

			loadMruFileProjects();
			loadMruFileFiles();

			if (!handleProjectOnCommandLine())
			{
				projectFilesUserControl.LoadRecentProject();
			}

			Application.Idle += application_Idle;

			UpdateUI();
		}

		private AskOverwriteResult dataProcessing_CanOverwrite(FileInfo filePath)
		{
			var dr = MessageBox.Show(
				this,
				string.Format(
					Resources.SR_MainForm_dataProcessing_CanOverwrite_Do_you_want_to_overwrite_the_read_only_file___0___,
					filePath.Name),
				@"Zeta Resource Editor",
				MessageBoxButtons.YesNoCancel,
				MessageBoxIcon.Question);

			if (dr == DialogResult.Yes)
			{
				return AskOverwriteResult.Overwrite;
			}
			else if (dr == DialogResult.No)
			{
				return AskOverwriteResult.Skip;
			}
			else
			{
				return AskOverwriteResult.Fail;
			}
		}

		/// <summary>
		/// Handles the FormClosing event of the <see cref="MainForm"/> control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.Windows.Forms.FormClosingEventArgs"/> 
		/// instance containing the event data.</param>
		private void mainForm_FormClosing(
			object sender,
			FormClosingEventArgs e)
		{
			var b1 = groupFilesControl.SaveState();
			var b2 = projectFilesUserControl.SaveState();

			if (!b1 || !b2)
			{
				e.Cancel = true;
			}
			else
			{
				projectFilesUserControl.SaveRecentProjectInfo();
				groupFilesControl.SaveRecentFilesInfo();

				projectFilesUserControl.CloseProject();

				ExitAdvertisementForm.CheckShow();

				FormBase.SaveState(mainFormMainSplitContainer);
				FormHelper.SaveState(this);

				((PersistentXmlFilePairStorage)FormHelper.Storage).Flush();
			}
		}

		/// <summary>
		/// Handles the Idle event of the Application control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance 
		/// containing the event data.</param>
		private void application_Idle(
			object sender,
			EventArgs e)
		{
			UpdateUI();

			if (groupFilesControl.CurrentFileGroupControl != null)
			{
				groupFilesControl.CurrentFileGroupControl.UpdateUI();
			}
		}

		/// <summary>
		/// Handles the Shown event of the <see cref="MainForm"/> control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance 
		/// containing the event data.</param>
		private void mainForm_Shown(
			object sender,
			EventArgs e)
		{
			try
			{
				updateAvailableCheckerBackgroundWorker.RunWorkerAsync();
			}
			catch (Exception x)
			{
				// Catch and forget.
				LogCentral.Current.LogError(
					@"Error starting checking for updates.", x);
			}

			fetchAdAsync();

			QuickTranslationForm.CheckRestoreShowForm();

			UpdateUI();
		}

		private void fetchAdAsync()
		{
			try
			{
				adFetchTimer.Stop();

				var ws = WebServiceManager.Current.AdWS;

				var req =
					new AdService.AdRequest
					{
						Culture = CultureInfo.CurrentUICulture.LCID
					};

				ws.GetNextAdCompleted +=
					ws_GetNextAdCompleted;
				ws.GetNextAdAsync(req);
			}
			catch (Exception x)
			{
				LogCentral.Current.LogError(
					@"Silently catching exception when start fetching ad.",
					x);
			}
		}

		private void ws_GetNextAdCompleted(
			object sender,
			AdService.GetNextAdCompletedEventArgs e)
		{
			try
			{
				FormHelper.SyncInvoke(
					this,
					delegate
					{
						barStaticItem1.Caption = e.Result.Text;
						barStaticItem1.Tag = e.Result.Url;
					});

				// Next turn.
				adFetchTimer.Start();
			}
			catch (Exception x)
			{
				LogCentral.Current.LogError(
					@"Silently catching exception when finished fetching ad.",
					x);
			}
		}

		private void adFetchTimer_Tick(
			object sender,
			EventArgs e)
		{
			fetchAdAsync();
		}

		private void findToolStripMenuItem_Click(
			object sender,
			ItemClickEventArgs e)
		{
			groupFilesControl.CurrentFileGroupControl.Find();
			UpdateUI();
		}

		/// <summary>
		/// Handles the Click event of the findNextToolStripMenuItem control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance 
		/// containing the event data.</param>
		private void findNextToolStripMenuItem_Click(
			object sender,
			ItemClickEventArgs e)
		{
			groupFilesControl.CurrentFileGroupControl.FindNext();
			UpdateUI();
		}

		/// <summary>
		/// Handles the Click event of the 
		/// openFolderOfCurrentResourceFileToolStripMenuItem control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance 
		/// containing the event data.</param>
		private void openFolderOfCurrentResourceFileToolStripMenuItem_Click(
			object sender,
			ItemClickEventArgs e)
		{
			groupFilesControl.CurrentFileGroupControl.OpenFolder();
			UpdateUI();
		}

		private void openProjectFileToolStripMenuItem_Click(object sender, ItemClickEventArgs e)
		{
			ProjectFilesControl.OpenWithDialog();
			UpdateUI();
		}

		private void saveProjectFileToolStripMenuItem_Click(object sender, ItemClickEventArgs e)
		{
			ProjectFilesControl.DoSaveFile(SaveOptions.None);
			UpdateUI();
		}

		private void closeProjectFileToolStripMenuItem_Click(object sender, ItemClickEventArgs e)
		{
			ProjectFilesControl.CloseAndSaveProject();
			UpdateUI();
		}

		private void addResourceFilesToProjectToolStripMenuItem_Click(object sender, ItemClickEventArgs e)
		{
			ProjectFilesControl.AddResourceFilesWithDialog();
			UpdateUI();
		}

		private void removeResourceFilesFromProjectToolStripMenuItem_Click(object sender, ItemClickEventArgs e)
		{
			ProjectFilesControl.RemoveResourceFilesWithDialog();
			UpdateUI();
		}

		private void editProjectSettingsToolStripMenuItem_Click(object sender, ItemClickEventArgs e)
		{
			ProjectFilesControl.EditProjectSettingsWithDialog();
			UpdateUI();
		}

		private void createNewProjectToolStripMenuItem_Click(object sender, ItemClickEventArgs e)
		{
			ProjectFilesControl.CreateNewProject();
			groupFilesControl.CloseAllDocuments();
			UpdateUI();
		}

		private void closeAllDocumentsToolStripMenuItem_Click(object sender, ItemClickEventArgs e)
		{
			groupFilesControl.CloseAllDocuments();
			UpdateUI();
		}

		private void saveAllToolStripButton_Click(object sender, ItemClickEventArgs e)
		{
			SaveAllWithDialog();
		}

		private void donateToolStripMenuItem_Click(object sender, ItemClickEventArgs e)
		{
			var sei =
				new ShellExecuteInformation
				{
					FileName = @"http://zeta.li/zre-donate"
				};
			sei.Execute();
		}

		private void visitVendorsWebsiteToolStripMenuItem_Click(object sender, ItemClickEventArgs e)
		{
			var sei =
				new ShellExecuteInformation
				{
					FileName = @"http://zeta.li/zre-home"
				};
			sei.Execute();
		}

		private void addFilesToFileGroupToolStripMenuItem_Click(object sender, ItemClickEventArgs e)
		{
			projectFilesUserControl.AddFilesToFileGroupWithDialog();
			UpdateUI();
		}

		private void removeFileFromGroupToolStripMenuItem_Click(
			object sender,
			ItemClickEventArgs e)
		{
			projectFilesUserControl.RemoveFileFromFileGroupWithDialog();
			UpdateUI();
		}

		private void editResourceFilesSettingsToolStripMenuItem_Click(
			object sender,
			ItemClickEventArgs e)
		{
			projectFilesUserControl.EditFileGroupSettingsWithDialog();
			UpdateUI();
		}

		private void onlineManualToolStripMenuItem_Click(
			object sender,
			ItemClickEventArgs e)
		{
			var sei =
				new ShellExecuteInformation
				{
					FileName = @"http://zeta.li/zre-online-manual"
				};
			sei.Execute();
		}

		internal void SaveAllWithDialog()
		{
			projectFilesUserControl.SaveState(SaveOptions.OnlyIfModified);
			groupFilesControl.SaveState(SaveOptions.OnlyIfModified);
		}

		private void buttonUpdateAvailable_ItemClick(
			object sender,
			ItemClickEventArgs e)
		{
			var url = (string)buttonUpdateAvailable.Tag;

			var sei =
				new ShellExecuteInformation
				{
					FileName = url
				};
			sei.Execute();

			// Also exit myself.
			Close();
			Application.Exit();
		}

		/// <summary>
		/// Handles the DoWork event of the 
		/// updateAvailableCheckerBackgroundWorker control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.ComponentModel.DoWorkEventArgs"/> 
		/// instance containing the event data.</param>
		private void updateAvailableCheckerBackgroundWorker_DoWork(
			object sender,
			DoWorkEventArgs e)
		{
			try
			{
				var assemblyVersion =
					FileHelper.GetAssemblyVersion(
						Assembly.GetEntryAssembly().Location);

				var ws = WebServiceManager.Current.UpdateCheckerWS;
				var url = ws.IsUpdateAvailable(assemblyVersion.ToString());

				e.Result = url;
			}
			catch (Exception x)
			{
				// Catch and forget.
				LogCentral.Current.LogError(
					@"Error during checking for updates.", x);
			}
		}

		/// <summary>
		/// Handles the RunWorkerCompleted event of the 
		/// updateAvailableCheckerBackgroundWorker control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.ComponentModel.RunWorkerCompletedEventArgs"/> 
		/// instance containing the event data.</param>
		private void updateAvailableCheckerBackgroundWorker_RunWorkerCompleted(
			object sender,
			RunWorkerCompletedEventArgs e)
		{
			try
			{
				if (!e.Cancelled &&
					e.Error == null &&
					e.Result != null &&
					!string.IsNullOrEmpty(e.Result as string))
				{
					// Yes, we do have an update, pass the URL to the
					// toolbar button and make it visible.

					buttonUpdateAvailable.Tag = e.Result as string;
					updateRibbonPageGroup.Visible = true;

					//// Make more visible.
					//updateAvailableToolStripButton.ForeColor = Color.Green;
					//updateAvailableToolStripButton.BackColor = Color.Yellow;
					//updateAvailableToolStripButton.Font =
					//    new Font(
					//        updateAvailableToolStripButton.Font,
					//        FontStyle.Bold );
				}
				else if (e.Error != null)
				{
					throw e.Error;
				}
			}
			catch (Exception x)
			{
				// Catch and forget.
				LogCentral.Current.LogError(
					@"Error after checking for updates.", x);
			}
		}

		/// <summary>
		/// Handles the project on command line.
		/// </summary>
		/// <returns></returns>
		private bool handleProjectOnCommandLine()
		{
			var args = Environment.GetCommandLineArgs();

			if (args.Length < 2)
			{
				return false;
			}
			else
			{
				for (var index = 1; index < args.Length; index++)
				{
					var file = args[index];

					if (string.Compare(
							Project.ProjectFileExtension,
							Path.GetExtension(file),
							true) == 0 &&
						File.Exists(file))
					{
						ProjectFilesControl.DoLoadProject(new FileInfo(file));

						return true;
					}
				}

				return false;
			}
		}

		#region Event Handler
		// ------------------------------------------------------------------

		/// <summary>
		/// Handles the <see cref="Control.DragDrop"/> event of the <see cref="MainForm"/> control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.Windows.Forms.DragEventArgs"/> 
		/// instance containing the event data.</param>
		private void mainForm_DragDrop(
			object sender,
			DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop))
			{
				var files = (string[])e.Data.GetData(
					DataFormats.FileDrop);

				if (files != null && files.Length > 0)
				{
					foreach (var file in files)
					{
						// Allow dropping of project files.
						if (string.Compare(
							Project.ProjectFileExtension,
							Path.GetExtension(file),
							true) == 0)
						{
							ProjectFilesControl.DoLoadProject(new FileInfo(file));
							return;
						}
					}
				}
			}
		}

		/// <summary>
		/// Handles the DragEnter event of the <see cref="MainForm"/> control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.Windows.Forms.DragEventArgs"/> 
		/// instance containing the event data.</param>
		private void mainForm_DragEnter(
			object sender,
			DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop))
			{
				var files = (string[])e.Data.GetData(
					DataFormats.FileDrop);

				if (files != null && files.Length > 0)
				{
					foreach (var file in files)
					{
						// Allow dropping of project files.
						if (string.Compare(
							Project.ProjectFileExtension,
							Path.GetExtension(file),
							true) == 0)
						{
							e.Effect = DragDropEffects.Copy;
							return;
						}
					}
				}

				// Not found.
				e.Effect = DragDropEffects.None;
			}
			else
			{
				e.Effect = DragDropEffects.None;
			}
		}

		private void automaticallyAddMultipleFileGroupsToolStripMenuItem_Click(
			object sender,
			ItemClickEventArgs e)
		{
			ProjectFilesControl.AutomaticallyAddAddResourceFilesWithDialog();
			UpdateUI();
		}

		private void toolStripStatusLabel1_Click(object sender, ItemClickEventArgs e)
		{
			var url = barStaticItem1.Tag as string;

			LogCentral.Current.LogInfo(
				string.Format(
				@"About to redirect to advertising web page at '{0}'.",
				url));

			var si =
				new ProcessStartInfo
				{
					FileName = url,
					UseShellExecute = true
				};

			Process.Start(si);
		}

		private void refreshProjectFilesListToolStripMenuItem_Click(object sender, ItemClickEventArgs e)
		{
			ProjectFilesControl.RefreshItems();
		}

		private void quickTranslationToolStripMenuItem_Click(object sender, ItemClickEventArgs e)
		{
			QuickTranslationForm.ShowTheForm();
		}

		private void translateMissingLanguagesToolStripMenuItem_Click(
			object sender,
			ItemClickEventArgs e)
		{
			using (var form = new AutoTranslateForm())
			{
				form.Initialize(groupFilesControl.CurrentFileGroupControl);
				if (form.ShowDialog(this) == DialogResult.OK)
				{
					groupFilesControl.CurrentFileGroupControl.UpdateUI();
					UpdateUI();
				}
			}
		}

		private void buttonExit_ItemClick(object sender, ItemClickEventArgs e)
		{
			Close();
		}

		private void ribbonStatusBar_Click(object sender, EventArgs e)
		{
			barStaticItem1.PerformClick();
		}

		// ------------------------------------------------------------------
		#endregion

		private void buttonExport_ItemClick(object sender, ItemClickEventArgs e)
		{
			SaveWithDialog();

			// Get groups from project
			var groups = ProjectFilesControl.Project.FileGroups;

			// Get groups from tabs
			foreach (var group in GroupFilesControl.GridEditableDatas)
			{
				if (group.FileGroup != null && !groups.Contains(group.FileGroup))
				{
					groups.Add(group.FileGroup);
				}
			}

			using (var wizard = new ExportWizardForm())
			{
				wizard.Initialize(groups, ProjectFilesControl.Project);

				if (wizard.ShowDialog(this) == DialogResult.OK)
				{
					ProjectFilesControl.RefreshItems();
					UpdateUI();
				}
			}
		}

		private void buttonImport_ItemClick(object sender, ItemClickEventArgs e)
		{
			SaveWithDialog();

			// Get groups from project
			var groups = ProjectFilesControl.Project.FileGroups;

			// Get groups from tabs
			foreach (var group in GroupFilesControl.GridEditableDatas)
			{
				if (group.FileGroup != null && !groups.Contains(group.FileGroup))
				{
					groups.Add(group.FileGroup);
				}
			}

			using (var wizard = new ImportWizardForm())
			{
				wizard.Initialize(groups, ProjectFilesControl.Project);

				if (wizard.ShowDialog(this) == DialogResult.OK)
				{
					ProjectFilesControl.RefreshItems();
					UpdateUI();
				}
			}
		}

		private void applicationMenu1_BeforePopup(
			object sender,
			CancelEventArgs e)
		{
			loadMruFileFiles();
			loadMruFileProjects();
		}

		private void buttonMoveUp_ItemClick(object sender, ItemClickEventArgs e)
		{
			projectFilesUserControl.MoveUp();
		}

		private void buttonMoveDown_ItemClick(object sender, ItemClickEventArgs e)
		{
			projectFilesUserControl.MoveDown();
		}

		private void buttonShowHideProjectPanel_ItemClick(
			object sender,
			ItemClickEventArgs e)
		{
			if (mainFormMainSplitContainer.PanelVisibility ==
				SplitPanelVisibility.Both)
			{
				mainFormMainSplitContainer.PanelVisibility =
					SplitPanelVisibility.Panel2;
			}
			else
			{
				mainFormMainSplitContainer.PanelVisibility =
					SplitPanelVisibility.Both;
			}

			UpdateUI();
		}

		private void buttonCreateNewFile_ItemClick(
			object sender,
			ItemClickEventArgs e)
		{
			projectFilesUserControl.CreateNewFileWithDialog();
			UpdateUI();
		}

		private void buttonCreateNewFiles_ItemClick(object sender, ItemClickEventArgs e)
		{
			projectFilesUserControl.CreateNewFilesWithDialog();
			UpdateUI();
		}

		private void buttonLicensing_ItemClick(object sender, ItemClickEventArgs e)
		{
			using (var form = new OptionsForm())
			{
				form.ActiveTabPageIndex = 1;
				form.ShowDialog(this);
			}
			UpdateUI();
		}

		private void resetLayoutButton_ItemClick(object sender, ItemClickEventArgs e)
		{
			groupFilesControl.ResetLayout();
		}

		private void buttonAddFromVisualStudio_ItemClick(object sender, ItemClickEventArgs e)
		{
			projectFilesUserControl.AutomaticallyAddResourceFilesFromSolutionWithDialog();
			UpdateUI();
		}

		private void buttonDonateOne_ItemClick(object sender, ItemClickEventArgs e)
		{
			var sei =
				new ShellExecuteInformation
					{
						FileName =
							string.Format(
								@"http://zeta.li/{0}",
								Resources.SR_MainForm_buttonDonateOne_ItemClick_zre_donate_one_currency)
					};
			sei.Execute();
		}
	}

	/////////////////////////////////////////////////////////////////////////
}