﻿namespace ZetaResourceEditor.UI.Translation
{
    #region Using directives.
    // ----------------------------------------------------------------------

    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Diagnostics;
    using System.Globalization;
    using System.Threading;
    using System.Windows.Forms;
    using Code.AppHost;
    using Code.DL;
    using Code.Helper;
    using DevExpress.XtraEditors;
    using DevExpress.XtraEditors.Controls;
    using Helper;
    using Helper.Base;
    using Helper.Progress;
    using Main;
    using Main.RightContent;
    using Properties;
    using Zeta.EnterpriseLibrary.Common;
    using Zeta.EnterpriseLibrary.Common.Collections;
    using Zeta.EnterpriseLibrary.Common.IO;
    using Zeta.EnterpriseLibrary.Tools.Storage;
    using Zeta.EnterpriseLibrary.Windows.Common;

    // ----------------------------------------------------------------------
    #endregion

    public partial class AutoTranslateForm :
        FormBase
    {
        private ResourceEditorUserControl _fileGroupControl;
        private bool _initialAllowUpdatingDetails;
        private Project _project;

        public AutoTranslateForm()
        {
            InitializeComponent();
        }

        public void Initialize(
            ResourceEditorUserControl fileGroupControl)
        {
            _fileGroupControl = fileGroupControl;
            _project =
                MainForm.Current.ProjectFilesControl.Project
                    ?? Project.CreateHelperProjectInMemoryOnly();

            // --

            if (_fileGroupControl.GridEditableData.Project == null)
            {
                _fileGroupControl.GridEditableData.Project = _project;
            }
        }

        private IEnumerable<string> languageCodes
        {
            get
            {
                return _fileGroupControl.GridEditableData.GetLanguageCodes(_project);
            }
        }

        public override void UpdateUI()
        {
            base.UpdateUI();

            buttonTranslate.Enabled =
                referenceLanguageGroupBox.SelectedIndex >= 0 &&
                languagesToTranslateCheckListBox.CheckedItems.Count > 0 &&
                (!prefixCheckBox.Checked || prefixTextBox.Text.Trim().Length > 0);

            buttonInvert.Enabled =
                languagesToTranslateCheckListBox.Items.Count > 0;
            buttonNone.Enabled =
                languagesToTranslateCheckListBox.CheckedItems.Count > 0;
            buttonAll.Enabled =
                languagesToTranslateCheckListBox.Items.Count > 0 &&
                languagesToTranslateCheckListBox.CheckedItems.Count <
                languagesToTranslateCheckListBox.Items.Count;

            prefixTextBox.Enabled =
                buttonDefault.Enabled =
                prefixCheckBox.Checked;

            buttonSettings.Enabled = _project != null;
        }

        public override void InitiallyFillLists()
        {
            base.InitiallyFillLists();

            foreach (var languageCode in languageCodes)
            {
                if (string.IsNullOrEmpty(languageCode))
                {
                    referenceLanguageGroupBox.Properties.Items.Add(
                        new Pair<string, string>(
                            Resources.SR_TranslationHelper_GetSourceLanguages_AutoDetect,
                            string.Empty));
                }
                else
                {
                    referenceLanguageGroupBox.Properties.Items.Add(
                        new Pair<string, string>(
                            string.Format(
                                @"{0} ({1})",
                                CultureInfo.GetCultureInfo(languageCode).DisplayName,
                                languageCode),
                            languageCode));
                }
            }

            // --
            // Select defaults.

            if (referenceLanguageGroupBox.SelectedIndex < 0 &&
                 referenceLanguageGroupBox.Properties.Items.Count > 0)
            {
                referenceLanguageGroupBox.SelectedIndex = 0;
            }
        }

        private void restoreState(
            IPersistentPairStorage storage)
        {
            prefixTextBox.Text =
                ConvertHelper.ToString(
                    FormHelper.RestoreValue(
                        storage,
                        @"autoTranslateForm.prefixTextBox.Text",
                        prefixTextBox.Text));

            prefixCheckBox.Checked =
                ConvertHelper.ToBoolean(
                    FormHelper.RestoreValue(
                        storage,
                        @"autoTranslateForm.prefixCheckBox.Checked",
                        prefixCheckBox.Checked));

            referenceLanguageGroupBox.SelectedIndex =
                Math.Min(
                    ConvertHelper.ToInt32(
                        FormHelper.RestoreValue(
                            storage,
                            @"autoTranslateForm.referenceLanguageComboBoxEdit.SelectedIndex",
                            referenceLanguageGroupBox.SelectedIndex)),
                    referenceLanguageGroupBox.Properties.Items.Count - 1);

            DevExpressExtensionMethods.RestoreSettings(
                languagesToTranslateCheckListBox,
                storage,
                @"autoTranslateForm.languagesToTranslateCheckListBox");
        }

        private void saveState(
            IPersistentPairStorage storage)
        {
            FormHelper.SaveValue(
                storage,
                @"autoTranslateForm.prefixTextBox.Text",
                prefixTextBox.Text);

            FormHelper.SaveValue(
                storage,
                @"autoTranslateForm.prefixCheckBox.Checked",
                prefixCheckBox.Checked);

            FormHelper.SaveValue(
                storage,
                @"autoTranslateForm.referenceLanguageComboBoxEdit.SelectedIndex",
                referenceLanguageGroupBox.SelectedIndex);

            DevExpressExtensionMethods.PersistSettings(
                languagesToTranslateCheckListBox,
                storage,
                @"autoTranslateForm.languagesToTranslateCheckListBox");
        }

        public override void FillItemToControls()
        {
            base.FillItemToControls();

            fileGroupTextBox.Text =
                _fileGroupControl.GridEditableData.GetNameIntelligent(_project);

            prefixTextBox.Text = FileGroup.DefaultTranslatedPrefix;

            // --

            if (_project != null)
            {
                restoreState(
                    _project.DynamicSettingsGlobalHierarchical);
            }
        }

        private void refillLanguagesToTranslate()
        {
            languagesToTranslateCheckListBox.Items.Clear();

            var forbidden =
                referenceLanguageGroupBox.SelectedIndex >= 0 &&
                referenceLanguageGroupBox.SelectedIndex <
                referenceLanguageGroupBox.Properties.Items.Count
                    ? ((Pair<string, string>)referenceLanguageGroupBox.SelectedItem).Second
                    : string.Empty;

            foreach (var languageCode in languageCodes)
            {
                if (!string.IsNullOrEmpty(languageCode) &&
                     languageCode != forbidden)
                {
                    var index = languagesToTranslateCheckListBox.Items.Add(
                        new Pair<string, string>(
                            string.Format(
                                @"{0} ({1})",
                                CultureInfo.GetCultureInfo(languageCode).DisplayName,
                                languageCode),
                            languageCode));

                    languagesToTranslateCheckListBox.SetItemChecked(index, true);
                }
            }
        }

        private void autoTranslateForm_Load(object sender, EventArgs e)
        {
            FormHelper.RestoreState(this);
            CenterToParent();

            InitiallyFillLists();
            FillItemToControls();

            _initialAllowUpdatingDetails = _fileGroupControl.AllowUpdatingDetails;
            _fileGroupControl.AllowUpdatingDetails = false;

            UpdateUI();
        }

        private void autoTranslateForm_FormClosing(
            object sender,
            FormClosingEventArgs e)
        {
            _fileGroupControl.AllowUpdatingDetails = _initialAllowUpdatingDetails;

            FormHelper.SaveState(this);

            if (_project != null)
            {
                using (new SilentProjectStoreGuard(_project))
                {
                    saveState(_project.DynamicSettingsGlobalHierarchical);
                }
            }
        }

        private void fileGroupTextBox_TextChanged(object sender, EventArgs e)
        {
            UpdateUI();
        }

        private void referenceLanguageGroupBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            refillLanguagesToTranslate();
            UpdateUI();
        }

        private void languagesToTranslateCheckListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateUI();
        }

        private void updateUITimer_Tick(object sender, EventArgs e)
        {
            UpdateUI();
        }

        private void buttonAll_Click(object sender, EventArgs e)
        {
            for (var index = 0; index < languagesToTranslateCheckListBox.Items.Count; ++index)
            {
                languagesToTranslateCheckListBox.SetItemChecked(index, true);
            }
        }

        private void buttonNone_Click(object sender, EventArgs e)
        {
            for (var index = 0; index < languagesToTranslateCheckListBox.Items.Count; ++index)
            {
                languagesToTranslateCheckListBox.SetItemChecked(index, false);
            }
        }

        private void buttonInvert_Click(object sender, EventArgs e)
        {
            for (var index = 0; index < languagesToTranslateCheckListBox.Items.Count; ++index)
            {
                languagesToTranslateCheckListBox.SetItemChecked(
                    index,
                    !languagesToTranslateCheckListBox.GetItemChecked(index));
            }
        }

        private void autoTranslateForm_Shown(object sender, EventArgs e)
        {
            updateUITimer.Start();
        }

        private void buttonTranslate_Click(object sender, EventArgs e)
        {
            var success = false;
            var cancelled = false;
            var table = _fileGroupControl.GetDataSource();
            var translationCount = 0;
            var translationSuccessCount = 0;
            var translationErrorCount = 0;

            var continueOnErrors = _project == null ? true : _project.TranslationContinueOnErrors;
            var delayMilliseconds = _project == null ? 500 : _project.TranslationDelayMilliseconds;

            var gridEditableData = _fileGroupControl.GridEditableData;

            var prefixSuccess =
                prefixCheckBox.Checked
                    ? prefixTextBox.Text.Trim() + @" "
                    : string.Empty;

            var prefixError =
                FileGroup.DefaultTranslationErrorPrefix.Trim() + @" ";

            var refLanguageCode =
                string.IsNullOrEmpty(
                    ((Pair<string, string>)referenceLanguageGroupBox.SelectedItem).Second)
                    ? string.Empty //@"auto"
                    : ((Pair<string, string>)referenceLanguageGroupBox.SelectedItem).Second;
            var toTranslateLanguageCodes =
                new List<string>();
            foreach (CheckedListBoxItem item in languagesToTranslateCheckListBox.CheckedItems)
            {
                var pair = (Pair<string, string>)item.Value;

                toTranslateLanguageCodes.Add(pair.Second);
            }

            using (var gui =
                new BackgroundWorkerLongProgressGui(
                    delegate(
                        object s,
                        DoWorkEventArgs a)
                    {
                        var bw = (BackgroundWorker)s;

                        var refValueIndex = 1;

#pragma warning disable 618,612
                        var prev = DevExpress.Data.CurrencyDataController.DisableThreadingProblemsDetection;
                        DevExpress.Data.CurrencyDataController.DisableThreadingProblemsDetection = true;
#pragma warning restore 618,612

                        try
                        {
                            foreach (DataColumn column in table.Columns)
                            {
                                if (column.Ordinal > 0)
                                {
                                    var raw =
                                        new LanguageCodeDetection(_project)
                                            .DetectLanguageCodeFromFileName(
                                                gridEditableData.ParentSettings,
                                                column.ColumnName);

                                    if (refLanguageCode == raw)
                                    {
                                        refValueIndex = column.Ordinal;
                                        break;
                                    }
                                }
                            }

                            // --

                            foreach (DataColumn column in table.Columns)
                            {
                                if (column.Ordinal > 0 && column.Ordinal != refValueIndex)
                                {
                                    var raw =
                                        new LanguageCodeDetection(_project)
                                            .DetectLanguageCodeFromFileName(
                                                gridEditableData.ParentSettings,
                                                column.ColumnName);

                                    if (toTranslateLanguageCodes.Contains(raw))
                                    {
                                        foreach (DataRow row in table.Rows)
                                        {
                                            if (bw.CancellationPending)
                                            {
                                                throw new CancelOperationException();
                                            }

                                            var text = row[column] as string;
                                            if (string.IsNullOrEmpty(text) ||
                                                text.Trim().Length <= 0)
                                            {
                                                // http://www.codeproject.com/KB/aspnet/ZetaResourceEditor.aspx?msg=3367544#xx3367544xx
                                                if (!FileGroup.IsInternalRow(row))
                                                {
                                                    var sourceText =
                                                        row[refValueIndex] as string;

                                                    if (!string.IsNullOrEmpty(sourceText))
                                                    {
                                                        if (delayMilliseconds > 0)
                                                        {
                                                            Thread.Sleep(delayMilliseconds);
                                                        }

                                                        try
                                                        {
                                                            var destinationText =
                                                                prefixSuccess +
                                                                    Host.TranslationHelper.Translate(
                                                                        sourceText,
                                                                        string.IsNullOrEmpty(refLanguageCode)
                                                                            ? @"auto"
                                                                            : refLanguageCode,
                                                                        raw);

                                                            row[column] = destinationText;

                                                            translationSuccessCount++;
                                                        }
                                                        catch (Exception x)
                                                        {
                                                            translationErrorCount++;

                                                            if (continueOnErrors)
                                                            {
                                                                var destinationText =
                                                                    prefixError +
                                                                        x.Message;

                                                                row[column] = destinationText;
                                                            }
                                                            else
                                                            {
                                                                throw;
                                                            }
                                                        }

                                                        translationCount++;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        catch (CancelOperationException)
                        {
                            // Do nothing.
                        }
                        finally
                        {
#pragma warning disable 618,612
                            DevExpress.Data.CurrencyDataController.DisableThreadingProblemsDetection = prev;
#pragma warning restore 618,612
                        }
                    },
                    delegate(
                        object s,
                        RunWorkerCompletedEventArgs a)
                    {
                        success = !a.Cancelled && a.Error == null;
                        cancelled = a.Cancelled;
                    },
                    BackgroundWorkerLongProgressGui.CancellationMode.Cancelable
                    ))
            {
                Debug.Assert(gui != null);
            }

            if (translationCount > 0)
            {
                _fileGroupControl.MarkGridContentAsModified();
                _fileGroupControl.MarkAsModified();
                _fileGroupControl.UpdateUI();
            }

            XtraMessageBox.Show(
                this,
                string.Format(
                    Resources.SR_AutoTranslateForm_buttonTranslateClick_TranslatingTranslatedTexts,
                    translationCount,
                    translationSuccessCount,
                    translationErrorCount),
                @"Zeta Resource Editor",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information,
                MessageBoxDefaultButton.Button1);

            if (success || cancelled)
            {
                DialogResult = DialogResult.OK;
                Close();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            UpdateUI();
        }

        private void prefixTextBox_TextChanged(object sender, EventArgs e)
        {
            UpdateUI();
        }

        private void languagesToTranslateCheckListBox_ItemCheck(
            object sender,
            DevExpress.XtraEditors.Controls.ItemCheckEventArgs e)
        {
            UpdateUI();
        }

        private void buttonDefault_Click(object sender, EventArgs e)
        {
            prefixTextBox.Text = FileGroup.DefaultTranslatedPrefix;
        }

        private void buttonSettings_Click(object sender, EventArgs e)
        {
            using (var form = new AutoTranslateOptionsForm())
            {
                form.Initialize(_project);

                if (form.ShowDialog(this) == DialogResult.OK)
                {
                    UpdateUI();
                }
            }
        }
    }
}