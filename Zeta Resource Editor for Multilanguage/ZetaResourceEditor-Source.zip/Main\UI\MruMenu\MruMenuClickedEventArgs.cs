namespace ZetaResourceEditor.UI.MruMenu
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System;

	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// Arguments class.
	/// </summary>
	public class MruMenuClickedEventArgs :
		EventArgs
	{
		#region Private variables.
		// ------------------------------------------------------------------

		private readonly int number;
		private readonly string fileName;

		// ------------------------------------------------------------------
		#endregion

		#region Public methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// 
		/// </summary>
		/// <param name="number"></param>
		/// <param name="fileName"></param>
		public MruMenuClickedEventArgs(
			int number,
			string fileName )
		{
			this.number = number;
			this.fileName = fileName;
		}

		// ------------------------------------------------------------------
		#endregion

		#region Public properties.
		// ------------------------------------------------------------------

		/// <summary>
		/// 
		/// </summary>
		public int Number
		{
			get
			{
				return number;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public string Path
		{
			get
			{
				return fileName;
			}
		}

		// ------------------------------------------------------------------
		#endregion
	}

	/////////////////////////////////////////////////////////////////////////
}