namespace ZetaResourceEditor.UI.Helper
{
	using System;
	using System.ComponentModel;
	using System.Windows.Forms;
	using DevExpress.XtraTreeList;
	using DevExpress.XtraTreeList.Nodes;
	using Zeta.EnterpriseLibrary.Windows.Controls;

	public partial class ZetaResourceEditorTreeListControl :
		TreeList
	{
		public ZetaResourceEditorTreeListControl()
		{
			InitializeComponent();
		}

		public ZetaResourceEditorTreeListControl( IContainer container )
		{
			container.Add( this );

			InitializeComponent();
		}

		public bool WasDoubleClick
		{
			get
			{
				return _wasDoubleClick;
			}
			set
			{
				_wasDoubleClick = value;
			}
		}

		private bool _wasDoubleClick;
		private const int WM_LBUTTONDBLCLK = 0x203;

		protected override void WndProc( ref Message m )
		{
			// http://groups.google.com/group/microsoft.public.dotnet.framework.windowsforms/msg/d16ac686dc6b42?hl=en&lr=&ie=UTF-8
			if ( m.Msg == WM_LBUTTONDBLCLK )
			{
				_wasDoubleClick = true;
			}

			base.WndProc( ref m );
		}

		private const string _DUMMY_NODE = @"8f6daa3-3e1c-4a55-b53c-6ca8e68a282a";

		protected override bool OnBeforeChangeExpanded(
			TreeListNode node,
			bool newVal )
		{
			if ( newVal )
			{
				CheckExpandDynamicNodes( node );
			}

			return base.OnBeforeChangeExpanded( node, newVal );
		}

		public event EventHandler<ExpandDynamicChildrenEventArgs> ExpandDynamicChildren;

		public void CheckExpandDynamicNodes(
			TreeListNode node )
		{
			if (
				(node.Nodes.Count > 0 &&
				 node.Nodes[0][0] as string == _DUMMY_NODE) ||
				(node[0] as string == _DUMMY_NODE) )
			{
				var handler = ExpandDynamicChildren;
				if ( handler != null )
				{
					handler( this, new ExpandDynamicChildrenEventArgs( node ) );
				}
			}
		}

		public void CheckAddDummyNode( TreeListNode node )
		{
			if ( node.Nodes.Count <= 0 )
			{
				AppendNode(
					new object[]
						{
							_DUMMY_NODE,
							null,
							null,
							null,
							null
						},
					node );
			}
		}

		public void ClearSelection()
		{
			while ( Selection.Count > 0 )
			{
				Selection[0].Selected = false;
			}
		}

		public TreeListNode SelectedNode
		{
			get
			{
				if ( Selection.Count <= 0 )
				{
					return null;
				}
				else
				{
					return Selection[0];
				}
			}
			set
			{
				ClearSelection();

				if ( value != null )
				{
					value.Selected = true;
				}

				FocusedNode = value;

				if ( value != null )
				{
					MakeNodeVisible( value );
				}
			}
		}

		/// <summary>
		/// Moves the specified node up by one,
		/// staying in the same level.
		/// Wraps if at the top.
		/// </summary>
		/// <param name="item">The item.</param>
		public void MoveItemUpByOne(
			TreeListNode item )
		{
			BeginUpdate();
			try
			{
				var nodes = item.ParentNode == null ? Nodes : item.ParentNode.Nodes;

				var itemIndex = GetNodeIndex( item );

				var newItemIndex = itemIndex - 1;
				if ( newItemIndex < 0 )
				{
					SetNodeIndex( item, nodes.Count );
				}
				else
				{
					SetNodeIndex( item, newItemIndex );
				}
			}
			finally
			{
				EndUpdate();
			}
		}

		/// <summary>
		/// Moves the specified node down by one,
		/// staying in the same level.
		/// Wraps if at the top.
		/// </summary>
		/// <param name="item">The item.</param>
		public void MoveItemDownByOne(
			TreeListNode item )
		{
			BeginUpdate();
			try
			{
				var nodes = item.ParentNode == null ? Nodes : item.ParentNode.Nodes;

				var itemIndex = GetNodeIndex( item );

				var newItemIndex = itemIndex + 1;
				if ( newItemIndex >= nodes.Count )
				{
					SetNodeIndex( item, 0 );
				}
				else
				{
					SetNodeIndex( item, newItemIndex );
				}
			}
			finally
			{
				EndUpdate();
			}
		}

		/// <summary>
		/// Ensures the items order positions set.
		/// </summary>
		public void EnsureItemsOrderPositionsSet(
			TreeListNode parentNode,
			AsynchronousMode asynchronousMode )
		{
			var previousOrderPosition = -1;

			var nodes = parentNode == null ? Nodes : parentNode.Nodes;

			// Take the current item order of the items in the
			// list and ensure the order position is
			// ascending (not naturally immediate following numbers).
			var itemIndex = 0;
			while ( itemIndex < nodes.Count )
			{
				var listViewItem = nodes[itemIndex];

				var obj = (IOrderPosition)listViewItem.Tag;

				var currentOrderPosition = obj.OrderPosition;

				// Must adjust.
				if ( currentOrderPosition <= previousOrderPosition )
				{
					// Increment.
					var newCurrentOrderPosition = previousOrderPosition + 1;

					if ( obj.OrderPosition != newCurrentOrderPosition )
					{
						// New order position.
						obj.OrderPosition = newCurrentOrderPosition;

						// Mark as modified, but do no display update,
						// since nothing VISUAL has changed.
						obj.StoreOrderPosition( asynchronousMode );
					}

					// Remember for next turn.
					previousOrderPosition = newCurrentOrderPosition;
				}
				else
				{
					// Remember for next turn.
					previousOrderPosition = currentOrderPosition;
				}

				itemIndex++;
			}
		}

		public static bool IsNodeChildNodeOf( TreeListNode nodeToTest, TreeListNode potentialParentNode )
		{
			if ( nodeToTest == potentialParentNode )
			{
				return true;
			}
			else
			{
				foreach ( TreeListNode node in potentialParentNode.Nodes )
				{
					if ( IsNodeChildNodeOf( nodeToTest, node ) )
					{
						return true;
					}
				}

				return false;
			}
		}
	}
}