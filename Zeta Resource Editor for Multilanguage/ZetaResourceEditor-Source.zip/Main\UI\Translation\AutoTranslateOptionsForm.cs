namespace ZetaResourceEditor.UI.Translation
{
	using System;
	using System.Windows.Forms;
	using Code.DL;
	using Helper.Base;
	using Zeta.EnterpriseLibrary.Common;
	using Zeta.EnterpriseLibrary.Windows.Common;

	public partial class AutoTranslateOptionsForm :
		FormBase
	{
		private Project _project;

		public AutoTranslateOptionsForm()
		{
			InitializeComponent();
		}

		public override void FillItemToControls()
		{
			base.FillItemToControls();

			translationDelayTextEdit.Text = 
				_project.TranslationDelayMilliseconds.ToString();
			checkEditContinueOnErrors.Checked =
				_project.TranslationContinueOnErrors;
		}

		public override void FillControlsToItem()
		{
			base.FillControlsToItem();

			_project.TranslationDelayMilliseconds = ConvertHelper.ToInt32(translationDelayTextEdit.Text.Trim());
			_project.TranslationContinueOnErrors = checkEditContinueOnErrors.Checked;
		}

		public override void UpdateUI()
		{
			base.UpdateUI();

			buttonOK.Enabled =
				ConvertHelper.IsInt32(translationDelayTextEdit.Text.Trim()) &&
				ConvertHelper.ToInt32(translationDelayTextEdit.Text.Trim()) > 0 &&
				ConvertHelper.ToInt32(translationDelayTextEdit.Text.Trim()) < 50000;
		}

		private void AutoTranslateOptionsForm_Load(
			object sender, 
			EventArgs e)
		{
			FormHelper.RestoreState(this);
			CenterToParent();

			InitiallyFillLists();
			FillItemToControls();

			UpdateUI();
		}

		private void AutoTranslateOptionsForm_FormClosing(
			object sender, 
			FormClosingEventArgs e)
		{
			FormHelper.SaveState(this);
		}

		private void translationDelayTextEdit_EditValueChanged(object sender, EventArgs e)
		{
			UpdateUI();
		}

		private void buttonOK_Click(object sender, EventArgs e)
		{
			FillControlsToItem();
		}

		public void Initialize(Project project)
		{
			_project = project;
		}
	}
}