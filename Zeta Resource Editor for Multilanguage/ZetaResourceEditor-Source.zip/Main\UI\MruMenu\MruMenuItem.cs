namespace ZetaResourceEditor.UI.MruMenu
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System;
	using System.IO;
	using System.Windows.Forms;
	using Zeta.EnterpriseLibrary.Common.Collections;

	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// The menu item which will contain the MRU entry.
	/// </summary>
	/// <remarks>The menu may display a shortened or otherwise invalid 
	/// pathname. This class stores the actual fileName, preferably as a 
	/// fully resolved labelName, that will be returned in the event 
	/// handler.</remarks>
	public class MruMenuItem :
		ToolStripMenuItem
	{
		#region Public methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// Initializes a new instance of the MruMenuItem class.
		/// </summary>
		public MruMenuItem()
		{
			Tag = new Pair<string, string>(
				string.Empty,
				string.Empty );
		}

		/// <summary>
		/// Initializes an MruMenuItem object.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		/// <param name="entryName">Name of the entry.</param>
		/// <param name="realEntryName">Name of the real entry.</param>
		/// <param name="eventHandler">The event handler.</param>
		public MruMenuItem(
			string fileName,
			string entryName,
			string realEntryName,
			EventHandler eventHandler )
		{
			Tag = new Pair<string, string>(
				string.Empty,
				string.Empty );

			FileName = fileName;
			EntryName = realEntryName;

			base.Text = entryName;
			Click += eventHandler;
		}

		// ------------------------------------------------------------------
		#endregion

		#region Public properties.
		// ------------------------------------------------------------------

		/// <summary>
		/// Gets or sets the name of the file.
		/// </summary>
		/// <value>The name of the file.</value>
		public string FileName
		{
			get
			{
				return ((Pair<string, string>)Tag).First;
			}
			set
			{
				((Pair<string, string>)Tag).First = value;
			}
		}

		/// <summary>
		/// Gets or sets the name of the entry.
		/// </summary>
		/// <value>The name of the entry.</value>
		public string EntryName
		{
			get
			{
				string s = ((Pair<string, string>)Tag).Second;

				if ( string.IsNullOrEmpty( s ) )
				{
					s = FileName;

					if ( string.IsNullOrEmpty( s ) )
					{
						return Text;
					}
					else
					{
						return Path.GetFileName( s );
					}
				}
				else
				{
					return s;
				}
			}
			set
			{
				((Pair<string, string>)Tag).Second = value;
			}
		}

		// ------------------------------------------------------------------
		#endregion
	}

	/////////////////////////////////////////////////////////////////////////
}
