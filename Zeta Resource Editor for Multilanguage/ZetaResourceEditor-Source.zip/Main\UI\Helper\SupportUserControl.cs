namespace ZetaResourceEditor.UI.Helper
{
	using System;
	using System.Collections.Generic;
	using System.ComponentModel;
	using System.Windows.Forms;
	using Code.App;
	using Code.AppHost;
	using Base;
	using Zeta.EnterpriseLibrary.Windows.Common;

	[Designer(@"System.Windows.Forms.Design.ButtonBaseDesigner, System.Design")]
	public partial class SupportUserControl :
		UserControlBase
	{
		public SupportUserControl()
		{
			InitializeComponent();

			if (!DesignMode)
			{
				// Hide myself if not wanted.
				if (!Host.WantDisplaySupportOptionsOnForms)
				{
					foreach (Control c in Controls)
					{
						c.Visible = false;
					}
				}
			}
		}

		public static void ReplaceMenuEntryWithSupportMenu(
			ToolStripMenuItem miToReplace)
		{
			SupportUserControl uc = new SupportUserControl();

			int index = miToReplace.Owner.Items.IndexOf(miToReplace);

			List<ToolStripItem> items = new List<ToolStripItem>();
			foreach (ToolStripItem item in uc.contextMenuStrip1.Items)
			{
				items.Add(item);
			}

			foreach (ToolStripItem menuItem in items)
			{
				miToReplace.Owner.Items.Insert(index, menuItem);
				index++;
			}

			miToReplace.Owner.Items.Remove(miToReplace);
		}

		private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			linkLabel1.ContextMenuStrip.Show(
				linkLabel1,
				0,
				linkLabel1.Height);
		}

		private void remoteSupportToolStripMenuItem_Click(object sender, EventArgs e)
		{
			var sei =
				new ShellExecuteInformation
					{
						FileName = @"http://zeta.li/zre-remote-support"
					};
			sei.Execute();
		}

		private void captureScreenshotToClipboardToolStripMenuItem_Click(
			object sender,
			EventArgs e)
		{
			CaptureScreenshotToClipboard(this);
		}

		/// <summary>
		/// Captures the screenshot to clipboard.
		/// </summary>
		/// <param name="owningControl">The owning control.</param>
		public static void CaptureScreenshotToClipboard(
			Control owningControl)
		{
			using (new WaitCursor(owningControl))
			{
				Application.DoEvents();

				var sc = new ScreenCapture();
				sc.CaptureScreenToClipboard();
			}
		}

		private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
		{
			UpdateUI();
		}

		private void uploadFileToolStripMenuItem_Click(object sender, EventArgs e)
		{
			var sei = 
				new ShellExecuteInformation
					{
						FileName = @"http://zeta.li/zre-zeta-uploader"
					};
			sei.Execute();
		}
	}
}
