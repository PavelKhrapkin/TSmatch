namespace ZetaResourceEditor.Code.CommandLine
{
	using DL;

	internal class CommandProcessorReceiveInformation
	{
		public Project Project
		{
			get;
			set;
		}

		public FileGroup[] FileGroups
		{
			get;
			set;
		}

		public string[] LanguageCodes
		{
			get;
			set;
		}

		public string SourceFilePath
		{
			get;
			set;
		}

		public bool IsFileGroupLessXlsFile
		{
			get
			{
				return FileGroups == null || FileGroups.Length <= 0;
			}
		}
	}
}