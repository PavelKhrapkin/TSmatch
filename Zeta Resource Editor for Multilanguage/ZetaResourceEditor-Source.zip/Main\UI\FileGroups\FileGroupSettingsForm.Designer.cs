namespace ZetaResourceEditor.UI.FileGroups
{
	partial class FileGroupSettingsForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose( bool disposing )
		{
			if ( disposing && (components != null) )
			{
				components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FileGroupSettingsForm));
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.optionsGroupBox = new DevExpress.XtraEditors.GroupControl();
			this.parentTextEdit = new DevExpress.XtraEditors.TextEdit();
			this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
			this.button1 = new DevExpress.XtraEditors.DropDownButton();
			this.optionsPopupMenu = new DevExpress.XtraBars.PopupMenu(this.components);
			this.openButton = new DevExpress.XtraBars.BarButtonItem();
			this.barManager = new DevExpress.XtraBars.BarManager(this.components);
			this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
			this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
			this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
			this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
			this.imageCollection1 = new DevExpress.Utils.ImageCollection(this.components);
			this.checkSumTextEdit = new DevExpress.XtraEditors.TextEdit();
			this.locationTextBox = new DevExpress.XtraEditors.TextEdit();
			this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
			this.nameTextBox = new DevExpress.XtraEditors.TextEdit();
			this.label2 = new DevExpress.XtraEditors.LabelControl();
			this.label1 = new DevExpress.XtraEditors.LabelControl();
			this.buttonCancel = new DevExpress.XtraEditors.SimpleButton();
			this.buttonOK = new DevExpress.XtraEditors.SimpleButton();
			this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
			this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
			this.imageCollection2 = new DevExpress.Utils.ImageCollection(this.components);
			this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
			this.groupControl3 = new DevExpress.XtraEditors.GroupControl();
			this.pictureBox4 = new System.Windows.Forms.PictureBox();
			this.descriptionTextBox = new DevExpress.XtraEditors.MemoEdit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.optionsGroupBox)).BeginInit();
			this.optionsGroupBox.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.parentTextEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.optionsPopupMenu)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.barManager)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.checkSumTextEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.locationTextBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.nameTextBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
			this.panelControl1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
			this.xtraTabControl1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.imageCollection2)).BeginInit();
			this.xtraTabPage1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.groupControl3)).BeginInit();
			this.groupControl3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.descriptionTextBox.Properties)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
			resources.ApplyResources(this.pictureBox1, "pictureBox1");
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.TabStop = false;
			// 
			// optionsGroupBox
			// 
			resources.ApplyResources(this.optionsGroupBox, "optionsGroupBox");
			this.optionsGroupBox.Controls.Add(this.parentTextEdit);
			this.optionsGroupBox.Controls.Add(this.labelControl2);
			this.optionsGroupBox.Controls.Add(this.button1);
			this.optionsGroupBox.Controls.Add(this.checkSumTextEdit);
			this.optionsGroupBox.Controls.Add(this.locationTextBox);
			this.optionsGroupBox.Controls.Add(this.labelControl1);
			this.optionsGroupBox.Controls.Add(this.nameTextBox);
			this.optionsGroupBox.Controls.Add(this.label2);
			this.optionsGroupBox.Controls.Add(this.label1);
			this.optionsGroupBox.Controls.Add(this.pictureBox1);
			this.optionsGroupBox.Name = "optionsGroupBox";
			// 
			// parentTextEdit
			// 
			resources.ApplyResources(this.parentTextEdit, "parentTextEdit");
			this.parentTextEdit.Name = "parentTextEdit";
			this.parentTextEdit.Properties.ReadOnly = true;
			// 
			// labelControl2
			// 
			resources.ApplyResources(this.labelControl2, "labelControl2");
			this.labelControl2.Name = "labelControl2";
			// 
			// button1
			// 
			resources.ApplyResources(this.button1, "button1");
			this.button1.DropDownControl = this.optionsPopupMenu;
			this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
			this.button1.ImageLocation = DevExpress.XtraEditors.ImageLocation.MiddleRight;
			this.button1.Name = "button1";
			this.button1.ShowArrowButton = false;
			// 
			// optionsPopupMenu
			// 
			this.optionsPopupMenu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.openButton)});
			this.optionsPopupMenu.Manager = this.barManager;
			this.optionsPopupMenu.Name = "optionsPopupMenu";
			// 
			// openButton
			// 
			resources.ApplyResources(this.openButton, "openButton");
			this.openButton.Id = 0;
			this.openButton.ImageIndex = 0;
			this.openButton.Name = "openButton";
			this.openButton.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.openButton_ItemClick);
			// 
			// barManager
			// 
			this.barManager.DockControls.Add(this.barDockControlTop);
			this.barManager.DockControls.Add(this.barDockControlBottom);
			this.barManager.DockControls.Add(this.barDockControlLeft);
			this.barManager.DockControls.Add(this.barDockControlRight);
			this.barManager.Form = this;
			this.barManager.Images = this.imageCollection1;
			this.barManager.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.openButton});
			this.barManager.MaxItemId = 3;
			// 
			// imageCollection1
			// 
			this.imageCollection1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection1.ImageStream")));
			this.imageCollection1.Images.SetKeyName(0, "folder_green.png");
			// 
			// checkSumTextEdit
			// 
			resources.ApplyResources(this.checkSumTextEdit, "checkSumTextEdit");
			this.checkSumTextEdit.Name = "checkSumTextEdit";
			this.checkSumTextEdit.Properties.ReadOnly = true;
			// 
			// locationTextBox
			// 
			resources.ApplyResources(this.locationTextBox, "locationTextBox");
			this.locationTextBox.Name = "locationTextBox";
			this.locationTextBox.Properties.ReadOnly = true;
			// 
			// labelControl1
			// 
			resources.ApplyResources(this.labelControl1, "labelControl1");
			this.labelControl1.Name = "labelControl1";
			// 
			// nameTextBox
			// 
			resources.ApplyResources(this.nameTextBox, "nameTextBox");
			this.nameTextBox.Name = "nameTextBox";
			this.nameTextBox.TextChanged += new System.EventHandler(this.nameTextBox_TextChanged);
			// 
			// label2
			// 
			resources.ApplyResources(this.label2, "label2");
			this.label2.Name = "label2";
			// 
			// label1
			// 
			resources.ApplyResources(this.label1, "label1");
			this.label1.Name = "label1";
			// 
			// buttonCancel
			// 
			resources.ApplyResources(this.buttonCancel, "buttonCancel");
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.Name = "buttonCancel";
			// 
			// buttonOK
			// 
			resources.ApplyResources(this.buttonOK, "buttonOK");
			this.buttonOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// panelControl1
			// 
			this.panelControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
			this.panelControl1.Controls.Add(this.xtraTabControl1);
			this.panelControl1.Controls.Add(this.buttonCancel);
			this.panelControl1.Controls.Add(this.buttonOK);
			resources.ApplyResources(this.panelControl1, "panelControl1");
			this.panelControl1.Name = "panelControl1";
			// 
			// xtraTabControl1
			// 
			resources.ApplyResources(this.xtraTabControl1, "xtraTabControl1");
			this.xtraTabControl1.Images = this.imageCollection2;
			this.xtraTabControl1.Name = "xtraTabControl1";
			this.xtraTabControl1.SelectedTabPage = this.xtraTabPage1;
			this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1});
			// 
			// imageCollection2
			// 
			this.imageCollection2.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection2.ImageStream")));
			this.imageCollection2.Images.SetKeyName(0, "box_edit.png");
			// 
			// xtraTabPage1
			// 
			this.xtraTabPage1.Controls.Add(this.groupControl3);
			this.xtraTabPage1.Controls.Add(this.optionsGroupBox);
			this.xtraTabPage1.ImageIndex = 0;
			this.xtraTabPage1.Name = "xtraTabPage1";
			resources.ApplyResources(this.xtraTabPage1, "xtraTabPage1");
			// 
			// groupControl3
			// 
			resources.ApplyResources(this.groupControl3, "groupControl3");
			this.groupControl3.Controls.Add(this.pictureBox4);
			this.groupControl3.Controls.Add(this.descriptionTextBox);
			this.groupControl3.Name = "groupControl3";
			// 
			// pictureBox4
			// 
			this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
			resources.ApplyResources(this.pictureBox4, "pictureBox4");
			this.pictureBox4.Name = "pictureBox4";
			this.pictureBox4.TabStop = false;
			// 
			// descriptionTextBox
			// 
			resources.ApplyResources(this.descriptionTextBox, "descriptionTextBox");
			this.descriptionTextBox.Name = "descriptionTextBox";
			// 
			// FileGroupSettingsForm
			// 
			this.AcceptButton = this.buttonOK;
			this.Appearance.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			this.Appearance.Options.UseFont = true;
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.CancelButton = this.buttonCancel;
			resources.ApplyResources(this, "$this");
			this.Controls.Add(this.panelControl1);
			this.Controls.Add(this.barDockControlLeft);
			this.Controls.Add(this.barDockControlRight);
			this.Controls.Add(this.barDockControlBottom);
			this.Controls.Add(this.barDockControlTop);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "FileGroupSettingsForm";
			this.ShowInTaskbar = false;
			this.Load += new System.EventHandler(this.FileGroupSettingsForm_Load);
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FileGroupSettingsForm_FormClosing);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.optionsGroupBox)).EndInit();
			this.optionsGroupBox.ResumeLayout(false);
			this.optionsGroupBox.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.parentTextEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.optionsPopupMenu)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.barManager)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.checkSumTextEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.locationTextBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.nameTextBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
			this.panelControl1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
			this.xtraTabControl1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.imageCollection2)).EndInit();
			this.xtraTabPage1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.groupControl3)).EndInit();
			this.groupControl3.ResumeLayout(false);
			this.groupControl3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.descriptionTextBox.Properties)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.PictureBox pictureBox1;
		private DevExpress.XtraEditors.GroupControl optionsGroupBox;
		private DevExpress.XtraEditors.SimpleButton buttonCancel;
		private DevExpress.XtraEditors.SimpleButton buttonOK;
		private DevExpress.XtraEditors.TextEdit locationTextBox;
		private DevExpress.XtraEditors.TextEdit nameTextBox;
		private DevExpress.XtraEditors.LabelControl label2;
		private DevExpress.XtraEditors.LabelControl label1;
		private DevExpress.XtraEditors.DropDownButton button1;
		private DevExpress.XtraBars.PopupMenu optionsPopupMenu;
		private DevExpress.XtraBars.BarButtonItem openButton;
		private DevExpress.XtraBars.BarManager barManager;
		private DevExpress.XtraBars.BarDockControl barDockControlTop;
		private DevExpress.XtraBars.BarDockControl barDockControlBottom;
		private DevExpress.XtraBars.BarDockControl barDockControlLeft;
		private DevExpress.XtraBars.BarDockControl barDockControlRight;
		private DevExpress.Utils.ImageCollection imageCollection1;
		private DevExpress.XtraEditors.TextEdit checkSumTextEdit;
		private DevExpress.XtraEditors.LabelControl labelControl1;
		private DevExpress.XtraEditors.PanelControl panelControl1;
		private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
		private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
		private DevExpress.XtraEditors.GroupControl groupControl3;
		private System.Windows.Forms.PictureBox pictureBox4;
		private DevExpress.XtraEditors.MemoEdit descriptionTextBox;
		private DevExpress.Utils.ImageCollection imageCollection2;
		private DevExpress.XtraEditors.TextEdit parentTextEdit;
		private DevExpress.XtraEditors.LabelControl labelControl2;
	}
}