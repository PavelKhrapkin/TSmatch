namespace ZetaResourceEditor.Code.DL
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System.Collections.Generic;
	using System.Xml;

	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// 
	/// </summary>
	public class ProjectFolderCollection :
		List<ProjectFolder>
	{
		private readonly Project _project;

		/// <summary>
		/// Initializes a new instance of the <see cref="ProjectFolderCollection"/> class.
		/// </summary>
		/// <param name="project">The project.</param>
		public ProjectFolderCollection(
			Project project )
		{
			_project = project;
		}

		/// <summary>
		/// Gets the project.
		/// </summary>
		/// <value>The project.</value>
		public Project Project
		{
			get
			{
				return _project;
			}
		}

		/// <summary>
		/// Stores to XML.
		/// </summary>
		/// <param name="parentNode">The parent node.</param>
		internal void StoreToXml(
			XmlElement parentNode )
		{
			var groupsNode =
				parentNode.OwnerDocument.CreateElement( @"projectFolders" );
			parentNode.AppendChild( groupsNode );

			foreach ( var projectFolder in this )
			{
				var projectFolderNode =
					parentNode.OwnerDocument.CreateElement( @"projectFolder" );
				groupsNode.AppendChild( projectFolderNode );

				projectFolder.StoreToXml( projectFolderNode );
			}
		}

		/// <summary>
		/// Loads from XML.
		/// </summary>
		/// <param name="parentNode">The parent node.</param>
		internal void LoadFromXml(
			XmlNode parentNode )
		{
			Clear();

			var projectFolderNodes =
				parentNode.SelectNodes( @"projectFolders/projectFolder" );

			if ( projectFolderNodes != null )
			{
				foreach ( XmlNode projectFolderNode in projectFolderNodes )
				{
					var projectFolder = new ProjectFolder( _project );
					projectFolder.LoadFromXml( projectFolderNode );

					Add(projectFolder);
				}
			}

			// --

			Sort();
		}
	}

	/////////////////////////////////////////////////////////////////////////
}