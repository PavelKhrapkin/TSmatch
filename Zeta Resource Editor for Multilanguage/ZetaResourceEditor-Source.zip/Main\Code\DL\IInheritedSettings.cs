﻿namespace ZetaResourceEditor.Code.DL
{
	public interface IInheritedSettings
	{
		IInheritedSettings ParentSettings { get; }

		int EffectiveBaseNameDotCount { get; }

		string EffectiveNeutralLanguageFileNamePattern { get; }

		string EffectiveNonNeutralLanguageFileNamePattern { get; }

		string[] EffectiveDefaultFileTypesToIgnoreArray { get; }

		string EffectiveDefaultFileTypesToIgnore { get; }

		string EffectiveNeutralLanguageCode { get; }
	}
}