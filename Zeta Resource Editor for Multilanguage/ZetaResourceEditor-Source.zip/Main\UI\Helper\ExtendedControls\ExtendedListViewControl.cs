﻿namespace ZetaResourceEditor.UI.Helper.ExtendedControls
{
	using Zeta.EnterpriseLibrary.Windows.Controls;

	public partial class ExtendedListViewControl :
		SortingListViewControl
	{
		public ExtendedListViewControl()
		{
			InitializeComponent();
		}
	}
}