﻿namespace ZetaResourceEditor.UI.Helper.Grid
{
	using System;
	using System.Collections.Generic;
	using System.ComponentModel;
	using System.IO;
	using System.Text;
	using DevExpress.Utils;
	using DevExpress.Utils.Serializing;
	using DevExpress.Utils.Serializing.Helpers;
	using DevExpress.XtraGrid.Views.Grid;
	using Zeta.EnterpriseLibrary.Common;
	using Zeta.EnterpriseLibrary.Tools.Storage;
	using Zeta.EnterpriseLibrary.Windows.Common;

	// http://www.devexpress.com/Support/Center/p/Q249609.aspx
	// http://www.devexpress.com/Support/Center/e/E600.aspx
	// http://www.devexpress.com/Support/Center/KB/p/AK9157.aspx
	// http://www.devexpress.com/Support/Center/p/Q104945.aspx

	internal abstract class LayoutSerializerBase :
		XmlXtraSerializer
	{
		public const string XtraGridAppName = @"View";
		public const string BarManagerAppName = @"BarManager";
		public const string DockManagerAppName = @"DockManager";
		public const string XtraGaugeAppName = @"IGaugeContainer";
		public const string LayoutControlAppName = @"LayoutControl";
		public const string DataLayoutControlAppName = @"DataLayoutControl";
		public const string XtraNavBarAppName = @"NavBarControl";
		public const string XtraPivotGridAppName = @"PivotGrid";
		public const string XtraTreeListAppName = @"TreeList";
		public const string VGridControlAppName = @"VGridControl";
		public const string PropertyGridControlAppName = @"PropertyGridControl";

		protected LayoutSerializerBase(
			GridView gridView,
			IPersistentPairStorage storage,
			string key)
		{
			_gridView = gridView;
			_storage = storage;
			_key = key;
		}

		private readonly GridView _gridView;
		private readonly IPersistentPairStorage _storage;
		private readonly string _key;
		private static FilterSerializationContext _instance;
		private static readonly object TypeLock =new object();

		protected override SerializeHelper CreateSerializeHelper(
			object rootObj,
			bool useRootObj)
		{
			lock (TypeLock)
			{
				_instance = new FilterSerializationContext();

				foreach (var field in Fields)
				{
					_instance.AddProperty(typeof (GridView), field);
				}

				// --

				if (useRootObj)
				{
					return new FilterSerializeHelper(rootObj);
				}
				else
				{
					return new FilterSerializeHelper();
				}
			}
		}

		protected override void DeserializeObject(
			object obj,
			IXtraPropertyCollection store,
			OptionsLayoutBase options)
		{
			if (options == null)
				options = OptionsLayoutBase.FullLayout;
			if (store == null)
				return;
			var coll = new XtraPropertyCollection();
			coll.AddRange(store);
			var helper = new DeserializeHelper(obj, false);
			helper.DeserializeObject(obj, coll, options);
		}

		public void Save()
		{
			using (var ms = new MemoryStream())
			{
				saveSettings(gridView, ms, XtraGridAppName);
				ms.Seek(0, SeekOrigin.Begin);

				string s;
				using (var sr = new StreamReader(ms, Encoding.UTF8))
				{
					s = sr.ReadToEnd();
				}

				FormHelper.SaveValue(_storage, key, s);
			}
		}

		public void Restore()
		{
			var s = ConvertHelper.ToString(FormHelper.RestoreValue(_storage, key));

			if (!string.IsNullOrEmpty(s))
			{
				using (var ms =
					new MemoryStream(Encoding.UTF8.GetBytes(s)))
				{
					loadSettings(gridView, ms, XtraGridAppName);
				}
			}
		}

		public virtual void Reset()
		{
			FormHelper.SaveValue(_storage, key, string.Empty);
		}

		protected abstract string[] Fields { get; }
		protected abstract string KeyPrefix { get; }

		private string key
		{
			get
			{
				return KeyPrefix + @"-" + _key;
			}
		}

		protected GridView gridView
		{
			get { return _gridView; }
		}

		private void saveSettings(object view, Stream stream, string appName)
		{
			SerializeObject(view, stream, appName);

			//var serializer = this;
			//serializer.Serialize(stream, serializer.getProperties(view), XtraGridAppName);
		}

		private void loadSettings(object view, Stream stream, string appName)
		{
			DeserializeObject(view, stream, appName);
			//view.RestoreLayoutFromStream(stream);
		}

		//private XtraPropertyInfoCollection getProperties(ColumnView view)
		//{
		//    var store = new XtraPropertyInfoCollection();
		//    var propList = new ArrayList();
		//    var properties = TypeDescriptor.GetProperties(view);

		//    foreach (var field in Fields)
		//    {
		//        propList.Add(properties.Find(field, false));
		//    }

		//    var mi = typeof(SerializeHelper).GetMethod(
		//        @"SerializeProperty", BindingFlags.NonPublic | BindingFlags.Instance);
		//    var helper = new SerializeHelper(view);

		//    (view as IXtraSerializable).OnStartSerializing();
		//    foreach (PropertyDescriptor prop in propList)
		//    {
		//        mi.Invoke(helper, new object[] { store, view, prop, XtraSerializationFlags.None, null });
		//    }
		//    (view as IXtraSerializable).OnEndSerializing();

		//    return store;
		//}


		private class FilterSerializeHelper : SerializeHelper
		{
			public FilterSerializeHelper()
			{
			}

			public FilterSerializeHelper(
				object rootObject)
				: base(rootObject)
			{
			}

			protected override SerializationContext CreateSerializationContext()
			{
				return _instance;
			}
		}

		private class FilterSerializationContext :
			SerializationContext
		{
			private readonly Dictionary<Type, string> _filters = new Dictionary<Type, string>();

			private bool Exclusive { get; set; }

			public void AddProperty(Type key, string propertyName)
			{
				if (!_filters.ContainsKey(key)) _filters.Add(key, @";");
				_filters[key] = string.Concat(_filters[key], propertyName, @";");
			}

			//public void AddProperties(Type key, IEnumerable<string> propertyNames)
			//{
			//    foreach (var propertyName in propertyNames) AddProperty(key, propertyName);
			//}

			//public void RemoveProperty(Type key, string propertyName)
			//{
			//    string filter;
			//    if (!_filters.TryGetValue(key, out filter)) return;

			//    _filters[key] = filter.Replace(string.Concat(propertyName, @";"), string.Empty);
			//}

			//public void RemoveProperties(Type key, IEnumerable<string> propertyNames)
			//{
			//    foreach (var propertyName in propertyNames)
			//    {
			//        RemoveProperty(key, propertyName);
			//    }
			//}

			protected override bool ShouldSerializeProperty(
				object obj,
				PropertyDescriptor prop,
				XtraSerializableProperty xtraSerializableProperty)
			{
				if (CheckFilter(obj.GetType(), prop.Name))
				{
					return false;
				}
				else
				{
					return base.ShouldSerializeProperty(obj, prop, xtraSerializableProperty);
				}
			}

			private bool CheckFilter(Type key, string propertyName)
			{
				return
					(_filters.ContainsKey(key) &&
					 _filters[key].Contains(string.Concat(@";", propertyName, @";")))
					== Exclusive;
			}
		}

	}
}