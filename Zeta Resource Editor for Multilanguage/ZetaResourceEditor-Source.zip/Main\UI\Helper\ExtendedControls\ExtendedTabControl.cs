namespace ZetaResourceEditor.UI.Helper.ExtendedControls
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System;
	using System.ComponentModel;
	using System.Windows.Forms;
	using Zeta.EnterpriseLibrary.Common.Collections;

	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// Tab control that sends an event when a tab page is displayed for
	/// the first time. Allows for delayed initialization of a tab page,
	/// until it is actually being displayed.
	/// </summary>
	public partial class ExtendedTabControl :
		TabControl
	{
		#region Public methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// Initializes a new instance of the 
		/// <see cref="ExtendedTabControl"/> class.
		/// </summary>
		public ExtendedTabControl()
		{
			InitializeComponent();

			if ( !DesignMode )
			{
				// 2007-01-27: Allow first control INSIDE the tab to get
				// focus immediately.
				TabStop = false;
			}
		}

		/// <summary>
		/// Forces an initialization event to be fired if not yet done
		/// for the current active tab.
		/// </summary>
		public void NotifyInitializeTab()
		{
			if ( !_initializedTabIndexes.Contains(
				SelectedIndex ) )
			{
				_initializedTabIndexes.Add( SelectedIndex );

				var args =
					new InitializeTabEventArgs(
					SelectedIndex,
					SelectedTab );

				OnInitializeTab( args );
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Private methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// Raises the <see cref="E:System.Windows.Forms.TabControl.SelectedIndexChanged"></see> event.
		/// </summary>
		/// <param name="e">An <see cref="T:System.EventArgs"></see> that 
		/// contains the event data.</param>
		protected override void OnSelectedIndexChanged(
			EventArgs e )
		{
			base.OnSelectedIndexChanged( e );

			NotifyInitializeTab();
		}

		/// <summary>
		/// Raises the <see cref="InitializeTab"/> event.
		/// </summary>
		/// <param name="e">The <see cref="ZetaResourceEditor.UI.Helper.ExtendedControls.InitializeTabEventArgs"/> 
		/// instance containing the event data.</param>
		protected virtual void OnInitializeTab(
			InitializeTabEventArgs e )
		{
			if ( InitializeTab != null )
			{
				InitializeTab( this, e );
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Public events.
		// ------------------------------------------------------------------

		/// <summary>
		/// Occurs when a tab is displayed for the first time.
		/// </summary>
		[
			Browsable( true ),
			Description( @"Occurs when a tab is displayed for the first time." ),
			Category( @"Behavior" )
		]
		public event EventHandler<InitializeTabEventArgs> InitializeTab;

		// ------------------------------------------------------------------
		#endregion

		#region Private variables.
		// ------------------------------------------------------------------

		private readonly Set<int> _initializedTabIndexes =
			new Set<int>();

		// ------------------------------------------------------------------
		#endregion
	}

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// Parameters for the InitializeTab event.
	/// </summary>
	public class InitializeTabEventArgs :
		EventArgs
	{
		#region Public methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// Initializes a new instance of the <see cref="InitializeTabEventArgs"/> 
		/// class.
		/// </summary>
		/// <param name="selectedIndex">Index of the selected.</param>
		/// <param name="selectedTabPage">The selected tab page.</param>
		public InitializeTabEventArgs(
			int selectedIndex,
			TabPage selectedTabPage )
		{
			_selectedIndex = selectedIndex;
			_selectedTabPage = selectedTabPage;
		}

		// ------------------------------------------------------------------
		#endregion

		#region Public properties.
		// ------------------------------------------------------------------

		/// <summary>
		/// Gets the index of the selected.
		/// </summary>
		/// <value>The index of the selected.</value>
		public int SelectedIndex
		{
			get
			{
				return _selectedIndex;
			}
		}

		/// <summary>
		/// Gets the selected tab page.
		/// </summary>
		/// <value>The selected tab page.</value>
		public TabPage SelectedTabPage
		{
			get
			{
				return _selectedTabPage;
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Private variables.
		// ------------------------------------------------------------------

		private readonly int _selectedIndex;
		private readonly TabPage _selectedTabPage;

		// ------------------------------------------------------------------
		#endregion
	}

	/////////////////////////////////////////////////////////////////////////
}