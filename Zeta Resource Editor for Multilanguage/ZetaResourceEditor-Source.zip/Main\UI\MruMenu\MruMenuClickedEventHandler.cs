namespace ZetaResourceEditor.UI.MruMenu
{
	#region Using directives.
	// ----------------------------------------------------------------------
	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// 
	/// </summary>
	public delegate void MruMenuClickedEventHandler(
		object sender,
		MruMenuClickedEventArgs e );

	/////////////////////////////////////////////////////////////////////////
}