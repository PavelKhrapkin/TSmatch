namespace ZetaResourceEditor.UI.FileGroups
{
	using System;
	using System.Collections.Generic;
	using System.ComponentModel;
	using System.Globalization;
	using System.Windows.Forms;
	using Code.DL;
	using Code.Helper;
	using DevExpress.XtraEditors;
	using Helper.Base;
	using Helper.Progress;
	using Main;
	using Properties;
	using Zeta.EnterpriseLibrary.Common;
	using Zeta.EnterpriseLibrary.Common.Collections;
	using Zeta.EnterpriseLibrary.Common.IO;
	using Zeta.EnterpriseLibrary.Windows.Common;

	public partial class CreateNewFilesForm :
		FormBase
	{
		private Project _project;
		private ProjectFolder _projectFolder;

		public CreateNewFilesForm()
		{
			InitializeComponent();
		}

		public void Initialize(
			Project project,
			ProjectFolder projectFolder)
		{
			_project = project;
			_projectFolder = projectFolder;
		}

		private Pair<string, string>[] languageCodes
		{
			get
			{
				var fgs =
					_projectFolder == null
						? _project.FileGroups
						: _projectFolder.FileGroupsDeep;

				return fgs.GetLanguageCodesExtended(
					MainForm.Current.ProjectFilesControl.Project);
			}
		}

		public override void InitiallyFillLists()
		{
			foreach (var languageCode in languageCodes)
			{
				if (!string.IsNullOrEmpty(languageCode.First))
				{
					referenceLanguageComboBox.Properties.Items.Add(
						new Pair<string, Pair<string, string>>(
							string.Format(
								@"{0} ({1})",
								CultureInfo.GetCultureInfo(languageCode.First).DisplayName,
								languageCode),
							languageCode));
				}
			}

			var items = new List<Pair<string, CultureInfo>>();

			foreach (var culture in CultureInfo.GetCultures(CultureTypes.AllCultures))
			{
				items.Add(
					new Pair<string, CultureInfo>(
						culture.DisplayName,
						culture));
			}

			items.Sort((x, y) => x.First.CompareTo(y.First));

			foreach (var item in items)
			{
				newLanguageComboBox.Properties.Items.Add(item);
			}
		}

		public override void UpdateUI()
		{
			base.UpdateUI();

			buttonOK.Enabled =
				referenceLanguageComboBox.SelectedItem != null &&
				newLanguageComboBox.SelectedItem != null &&
				string.Compare(
					((Pair<string, Pair<string, string>>) referenceLanguageComboBox.SelectedItem).Second.First,
					((Pair<string, CultureInfo>) newLanguageComboBox.SelectedItem).Second.Name,
					true) != 0 &&
				(!prefixCheckBox.Checked || prefixTextBox.Text.Trim().Length > 0);

			// --

			automaticallyTranslateCheckBox.Enabled =
				copyTextsCheckBox.Checked;

			if (!automaticallyTranslateCheckBox.Enabled)
			{
				automaticallyTranslateCheckBox.Checked = false;
			}

			if ( !automaticallyTranslateCheckBox.Checked)
			{
				prefixCheckBox.Checked = false;
			}

			prefixCheckBox.Enabled =
				automaticallyTranslateCheckBox.Checked;

			prefixTextBox.Enabled =
				buttonDefault.Enabled =
				automaticallyTranslateCheckBox.Checked &&
				prefixCheckBox.Checked;
		}

		public override void FillItemToControls()
		{
			base.FillItemToControls();

			parentElementTextBox.Text =
				_projectFolder == null
					? _project.Name
					: _projectFolder.NameIntelli;

			prefixTextBox.Text = FileGroup.DefaultTranslatedPrefix;

			// --

			var storage = 
				MainForm.Current.ProjectFilesControl.Project.DynamicSettingsGlobalHierarchical;

			referenceLanguageComboBox.SelectedIndex =
				Math.Min(
					ConvertHelper.ToInt32(
						FormHelper.RestoreValue(
							storage,
							@"CreateNewFilesForm.referenceLanguageComboBox.SelectedIndex",
							referenceLanguageComboBox.SelectedIndex)),
					referenceLanguageComboBox.Properties.Items.Count - 1);

			newLanguageComboBox.SelectedIndex =
				Math.Min(
					ConvertHelper.ToInt32(
						FormHelper.RestoreValue(
							storage,
							@"CreateNewFilesForm.newLanguageComboBox.SelectedIndex",
							newLanguageComboBox.SelectedIndex)),
					newLanguageComboBox.Properties.Items.Count - 1);

			copyTextsCheckBox.Checked =
				ConvertHelper.ToBoolean(
					FormHelper.RestoreValue(
						storage,
						@"CreateNewFilesForm.copyTextsCheckBox.Checked",
						copyTextsCheckBox.Checked));

			automaticallyTranslateCheckBox.Checked =
				ConvertHelper.ToBoolean(
					FormHelper.RestoreValue(
						storage,
						@"CreateNewFilesForm.automaticallyTranslateCheckBox.Checked",
						automaticallyTranslateCheckBox.Checked));

			prefixTextBox.Text =
				ConvertHelper.ToString(
					FormHelper.RestoreValue(
						storage,
						@"CreateNewFilesForm.prefixTextBox.Text",
						prefixTextBox.Text));

			prefixCheckBox.Checked =
				ConvertHelper.ToBoolean(
					FormHelper.RestoreValue(
						storage,
						@"CreateNewFilesForm.prefixCheckBox.Checked",
						prefixCheckBox.Checked));

			// --
			// Select defaults.

			if (referenceLanguageComboBox.SelectedIndex < 0 &&
				 referenceLanguageComboBox.Properties.Items.Count > 0)
			{
				referenceLanguageComboBox.SelectedIndex = 0;
			}
		}

		public override void FillControlsToItem()
		{
			base.FillControlsToItem();

			var storage =
				MainForm.Current.ProjectFilesControl.Project.DynamicSettingsGlobalHierarchical;

			FormHelper.SaveValue(
				storage,
				@"CreateNewFilesForm.prefixTextBox.Text",
				prefixTextBox.Text);

			FormHelper.SaveValue(
				storage,
				@"CreateNewFilesForm.prefixCheckBox.Checked",
				prefixCheckBox.Checked);

			FormHelper.SaveValue(
				storage,
				@"CreateNewFilesForm.referenceLanguageComboBox.SelectedIndex",
				referenceLanguageComboBox.SelectedIndex);

			FormHelper.SaveValue(
				storage,
				@"CreateNewFilesForm.newLanguageComboBox.SelectedIndex",
				newLanguageComboBox.SelectedIndex);

			FormHelper.SaveValue(
				storage,
				@"CreateNewFilesForm.copyTextsCheckBox.Checked",
				copyTextsCheckBox.Checked);

			FormHelper.SaveValue(
				storage,
				@"CreateNewFilesForm.automaticallyTranslateCheckBox.Checked",
				automaticallyTranslateCheckBox.Checked);
		}

		private void CreateNewFileForm_Load(object sender, EventArgs e)
		{
			FormHelper.RestoreState(this);
			CenterToParent();

			InitiallyFillLists();
			FillItemToControls();

			UpdateUI();
		}

		private void CreateNewFileForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			FormHelper.SaveState(this);
			FillControlsToItem();
		}

		private void referenceLanguageGroupBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			UpdateUI();
		}

		private void referenceLanguageComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			UpdateUI();
		}

		private void newLanguageComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			UpdateUI();
		}

		private void newLanguageComboBox_TextChanged(object sender, EventArgs e)
		{
			// Redirect.
			newLanguageComboBox_SelectedIndexChanged(null, null);
		}

		private void buttonOK_Click(object sender, EventArgs e)
		{
			using (new WaitCursor(this, WaitCursorOption.ShortSleep))
			{
				var sourceLanguageCode = ((Pair<string, Pair<string, string>>)referenceLanguageComboBox.SelectedItem).Second.First;
				var culture = ((Pair<string, CultureInfo>)newLanguageComboBox.SelectedItem).Second;
				var copyTextsFromSource = copyTextsCheckBox.Checked;
				var automaticallyTranslateTexts = automaticallyTranslateCheckBox.Checked;

				var created = 0;
				var skipped = 0;

				var prefix =
					prefixCheckBox.Checked
						? prefixTextBox.Text.Trim() + @" "
						: string.Empty;

				using (new BackgroundWorkerLongProgressGui(
					delegate(object snd, DoWorkEventArgs args)
					{
						try
						{
							var bw = (BackgroundWorker)snd;

							var fgs =
								_projectFolder == null
									? _project.FileGroups
									: _projectFolder.FileGroupsDeep;

							foreach (var fg in fgs)
							{
								if (bw.CancellationPending)
								{
									throw new CancelOperationException();
								}

								if (fg.HasLanguageCode(culture))
								{
									skipped++;
								}
								else
								{
									var sourceFile =
										fg.GetFileByLanguageCode(_project, sourceLanguageCode);

									fg.CreateAndAddNewFile(
										sourceFile.File.FullName,
										generateFileName(fg, culture),
										sourceLanguageCode,
										culture.Name,
										copyTextsFromSource,
										automaticallyTranslateTexts,
										prefix);

									created++;
								}
							}
						}
						catch (CancelOperationException)
						{
							// Ignore.
						}
					},
					Resources.SR_CreateNewFilesForm_Creating,
					BackgroundWorkerLongProgressGui.CancellationMode.Cancelable,
					this))
				{
				}

				// --

				if (created <= 0)
				{
					XtraMessageBox.Show(
						this,
						Resources.SR_CreateNewFilesForm_Finished01,
						@"Zeta Resource Editor",
						MessageBoxButtons.OK,
						MessageBoxIcon.Warning);

					UpdateUI();
				}
				else if (created > 0 && skipped > 0)
				{
					XtraMessageBox.Show(
						this,
						string.Format(
							Resources.SR_CreateNewFilesForm_Finished02,
							created,
							skipped),
						@"Zeta Resource Editor",
						MessageBoxButtons.OK,
						MessageBoxIcon.Information);
				}
				else
				{
					XtraMessageBox.Show(
						this,
						string.Format(
							Resources.SR_CreateNewFilesForm_Finished03,
							created),
						@"Zeta Resource Editor",
						MessageBoxButtons.OK,
						MessageBoxIcon.Information);
				}
			}
		}

		private static string generateFileName(
			FileGroup fileGroup,
			CultureInfo culture)
		{
			var pattern =
				new LanguageCodeDetection(fileGroup.Project).IsNeutralCulture(
					fileGroup.ParentSettings,
					culture)
					? fileGroup.Project.NeutralLanguageFileNamePattern
					: fileGroup.Project.NonNeutralLanguageFileNamePattern;

			pattern = pattern.Replace(@"[basename]", fileGroup.BaseName);
			pattern = pattern.Replace(@"[languagecode]", culture.Name);
			pattern = pattern.Replace(@"[extension]", fileGroup.BaseExtension);
			pattern = pattern.Replace(@"[optionaldefaulttypes]", fileGroup.BaseOptionalDefaultType);

			return pattern;
		}

		private void copyTextsCheckBox_CheckedChanged(object sender, EventArgs e)
		{
			UpdateUI();
		}

		private void automaticallyTranslateCheckBox_CheckedChanged(object sender, EventArgs e)
		{
			UpdateUI();
		}

		private void prefixCheckBox_CheckedChanged(object sender, EventArgs e)
		{
			UpdateUI();
		}

		private void prefixTextBox_EditValueChanged(object sender, EventArgs e)
		{
			UpdateUI();
		}

		private void buttonDefault_Click(object sender, EventArgs e)
		{
			prefixTextBox.Text = FileGroup.DefaultTranslatedPrefix;
		}
	}
}