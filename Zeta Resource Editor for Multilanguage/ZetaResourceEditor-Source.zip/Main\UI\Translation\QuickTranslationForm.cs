﻿namespace ZetaResourceEditor.UI.Translation
{
	using System;
	using System.Windows.Forms;
	using Code.AppHost;
	using Helper.Base;
	using Main;
	using Zeta.EnterpriseLibrary.Common;
	using Zeta.EnterpriseLibrary.Common.Collections;
	using Zeta.EnterpriseLibrary.Windows.Common;

	public partial class QuickTranslationForm : FormBase
	{
		public static void CheckRestoreShowForm()
		{
			if ( closedByFormOwner )
			{
				ShowTheForm();
			}
		}

		public static void ShowTheForm()
		{
			doShowTheForm( null, false );
		}

		public static void ShowTheForm(
			string textToTranslate )
		{
			doShowTheForm( textToTranslate, true );
		}

		private static void doShowTheForm(
			string textToTranslate, 
			bool applyTextToTranslate )
		{
			var isOpen = false;

			foreach ( Form form in Application.OpenForms )
			{
				if ( form is QuickTranslationForm )
				{
					isOpen = true;

					form.BringToFront();
					form.Select();

					var cf = (QuickTranslationForm)form;
					if ( applyTextToTranslate )
					{
						cf.sourceTextTextBox.Text = textToTranslate;
					}

					break;
				}
			}

			if ( !isOpen )
			{
				var form = new QuickTranslationForm();
				form.Show( MainForm.Current );
			}
		}

		public override void UpdateUI()
		{
			base.UpdateUI();

			buttonTranslate.Enabled =
				sourceLanguageComboBox.SelectedIndex >= 0 &&
				destinationLanguageComboBox.SelectedIndex >= 0 &&
				!string.IsNullOrEmpty( sourceTextTextBox.Text.Trim() );
			buttonCopyToClipboard.Enabled =
				!string.IsNullOrEmpty( destinationTextTextBox.Text.Trim() );
		}

		public override void InitiallyFillLists()
		{
			base.InitiallyFillLists();

			foreach ( var sourceLanguage in Host.TranslationHelper.GetSourceLanguages() )
			{
				sourceLanguageComboBox.Properties.Items.Add( sourceLanguage );
			}

			foreach ( var destinationLanguage in Host.TranslationHelper.GetDestinationLanguages() )
			{
				destinationLanguageComboBox.Properties.Items.Add( destinationLanguage );
			}
		}

		public QuickTranslationForm()
		{
			InitializeComponent();
		}

		public override void FillItemToControls()
		{
			base.FillItemToControls();

			sourceLanguageComboBox.SelectedIndex =
				Math.Min(
					ConvertHelper.ToInt32(
						FormHelper.RestoreValue(
							@"QuickTranslationForm.sourceLanguageComboBox.SelectedIndex",
							sourceLanguageComboBox.SelectedIndex ) ),
					sourceLanguageComboBox.Properties.Items.Count - 1 );
			destinationLanguageComboBox.SelectedIndex =
				Math.Min(
					ConvertHelper.ToInt32(
						FormHelper.RestoreValue(
							@"QuickTranslationForm.destinationLanguageComboBox.SelectedIndex",
							destinationLanguageComboBox.SelectedIndex ) ),
					destinationLanguageComboBox.Properties.Items.Count - 1 );

			sourceTextTextBox.Text =
				ConvertHelper.ToString(
					FormHelper.RestoreValue(
						@"QuickTranslationForm.sourceTextTextBox.Text",
						sourceTextTextBox.Text ) );

			copyDestinationTextToClipboardCheckBox.Checked =
				ConvertHelper.ToBoolean(
					FormHelper.RestoreValue(
						@"QuickTranslationForm.copyDestinationTextToClipboardCheckBox.Checked",
						copyDestinationTextToClipboardCheckBox.Checked ) );

			// --
			// Select defaults.

			if ( sourceLanguageComboBox.SelectedIndex < 0 &&
			     sourceLanguageComboBox.Properties.Items.Count > 0 )
			{
				sourceLanguageComboBox.SelectedIndex = 0;
			}

			if ( destinationLanguageComboBox.SelectedIndex < 0 &&
			     destinationLanguageComboBox.Properties.Items.Count > 0 )
			{
				foreach ( Pair<string, string> pair in destinationLanguageComboBox.Properties.Items )
				{
					if ( pair.Second.ToLowerInvariant() == @"en" )
					{
						destinationLanguageComboBox.SelectedItem = pair;
						break;
					}
				}

				if ( destinationLanguageComboBox.SelectedIndex < 0 )
				{
					destinationLanguageComboBox.SelectedIndex = 0;
				}
			}
		}

		public override void FillControlsToItem()
		{
			base.FillControlsToItem();

			FormHelper.SaveValue(
				@"QuickTranslationForm.sourceLanguageComboBox.SelectedIndex",
				sourceLanguageComboBox.SelectedIndex );
			FormHelper.SaveValue(
				@"QuickTranslationForm.destinationLanguageComboBox.SelectedIndex",
				destinationLanguageComboBox.SelectedIndex );

			FormHelper.SaveValue(
				@"QuickTranslationForm.sourceTextTextBox.Text",
				sourceTextTextBox.Text );

			FormHelper.SaveValue(
				@"QuickTranslationForm.copyDestinationTextToClipboardCheckBox.Checked",
				copyDestinationTextToClipboardCheckBox.Checked );
		}

		private void QuickTranslationForm_Load( object sender, EventArgs e )
		{
			FormHelper.RestoreState( this );

			InitiallyFillLists();
			FillItemToControls();

			UpdateUI();
		}

		private void QuickTranslationForm_Shown( object sender, EventArgs e )
		{
			sourceTextTextBox.Focus();
		}

		private void QuickTranslationForm_FormClosing( object sender, FormClosingEventArgs e )
		{
			closedByFormOwner = e.CloseReason == CloseReason.FormOwnerClosing;

			FormHelper.SaveState( this );
			FillControlsToItem();
		}

		private static bool closedByFormOwner
		{
			get
			{
				return ConvertHelper.ToBoolean(
					FormHelper.RestoreValue(
						@"QuickTranslationForm.closedByFormOwner" ) );
			}
			set
			{
				FormHelper.SaveValue(
					@"QuickTranslationForm.closedByFormOwner",
					value );
			}
		}

		private void sourceLanguageComboBox_SelectedIndexChanged( object sender, EventArgs e )
		{
			UpdateUI();
		}

		private void destinationLanguageComboBox_SelectedIndexChanged( object sender, EventArgs e )
		{
			UpdateUI();
		}

		private void sourceTextTextBox_TextChanged( object sender, EventArgs e )
		{
			UpdateUI();
		}

		private void copyDestinationTextToClipboardCheckBox_CheckedChanged( object sender, EventArgs e )
		{
			UpdateUI();
		}

		private void buttonCopyToClipboard_Click( object sender, EventArgs e )
		{
			Clipboard.SetText( destinationTextTextBox.Text.Trim() );
		}

		private void destinationTextTextBox_TextChanged( object sender, EventArgs e )
		{
			UpdateUI();
		}

		private void buttonTranslate_Click( object sender, EventArgs e )
		{
			using ( new WaitCursor( this, WaitCursorOption.ShortSleep ) )
			{
				destinationTextTextBox.Text =
					Host.TranslationHelper.Translate(
						sourceTextTextBox.Text.Trim(),
						((Pair<string, string>)sourceLanguageComboBox.SelectedItem).Second,
						((Pair<string, string>)destinationLanguageComboBox.SelectedItem).Second );

				if ( copyDestinationTextToClipboardCheckBox.Checked )
				{
					Clipboard.SetText( destinationTextTextBox.Text.Trim() );
				}
			}
		}

		private void sourceTextTextBox_KeyDown( object sender, KeyEventArgs e )
		{
			if ( e.KeyCode == Keys.A && e.Control )
			{
				sourceTextTextBox.SelectAll();
			}
		}

		private void destinationTextTextBox_KeyDown( object sender, KeyEventArgs e )
		{
			if ( e.KeyCode == Keys.A && e.Control )
			{
				destinationTextTextBox.SelectAll();
			}
		}

		private void buttonClose_Click( object sender, EventArgs e )
		{
			Close();
		}
	}
}