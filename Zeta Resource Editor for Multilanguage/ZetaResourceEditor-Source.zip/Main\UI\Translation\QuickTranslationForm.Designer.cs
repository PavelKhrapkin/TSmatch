namespace ZetaResourceEditor.UI.Translation
{
	partial class QuickTranslationForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose( bool disposing )
		{
			if ( disposing && (components != null) )
			{
				components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuickTranslationForm));
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.closeButton = new DevExpress.XtraEditors.SimpleButton();
			this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
			this.destinationTextTextBox = new DevExpress.XtraEditors.MemoEdit();
			this.buttonCopyToClipboard = new DevExpress.XtraEditors.SimpleButton();
			this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
			this.sourceLanguageComboBox = new DevExpress.XtraEditors.ComboBoxEdit();
			this.destinationLanguageComboBox = new DevExpress.XtraEditors.ComboBoxEdit();
			this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
			this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
			this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
			this.copyDestinationTextToClipboardCheckBox = new DevExpress.XtraEditors.CheckEdit();
			this.sourceTextTextBox = new DevExpress.XtraEditors.MemoEdit();
			this.buttonTranslate = new DevExpress.XtraEditors.SimpleButton();
			this.pictureBox3 = new System.Windows.Forms.PictureBox();
			this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
			this.groupControl1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.destinationTextTextBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
			this.groupControl2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.sourceLanguageComboBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.destinationLanguageComboBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.copyDestinationTextToClipboardCheckBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.sourceTextTextBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
			this.panelControl1.SuspendLayout();
			this.SuspendLayout();
			// 
			// pictureBox2
			// 
			this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
			resources.ApplyResources(this.pictureBox2, "pictureBox2");
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.TabStop = false;
			// 
			// closeButton
			// 
			resources.ApplyResources(this.closeButton, "closeButton");
			this.closeButton.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.closeButton.Name = "closeButton";
			this.closeButton.Click += new System.EventHandler(this.buttonClose_Click);
			// 
			// groupControl1
			// 
			resources.ApplyResources(this.groupControl1, "groupControl1");
			this.groupControl1.Controls.Add(this.destinationTextTextBox);
			this.groupControl1.Controls.Add(this.buttonCopyToClipboard);
			this.groupControl1.Controls.Add(this.pictureBox2);
			this.groupControl1.Name = "groupControl1";
			// 
			// destinationTextTextBox
			// 
			resources.ApplyResources(this.destinationTextTextBox, "destinationTextTextBox");
			this.destinationTextTextBox.Name = "destinationTextTextBox";
			this.destinationTextTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.destinationTextTextBox_KeyDown);
			this.destinationTextTextBox.TextChanged += new System.EventHandler(this.destinationTextTextBox_TextChanged);
			// 
			// buttonCopyToClipboard
			// 
			resources.ApplyResources(this.buttonCopyToClipboard, "buttonCopyToClipboard");
			this.buttonCopyToClipboard.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCopyToClipboard.Image = ((System.Drawing.Image)(resources.GetObject("buttonCopyToClipboard.Image")));
			this.buttonCopyToClipboard.Name = "buttonCopyToClipboard";
			this.buttonCopyToClipboard.Click += new System.EventHandler(this.buttonCopyToClipboard_Click);
			// 
			// groupControl2
			// 
			resources.ApplyResources(this.groupControl2, "groupControl2");
			this.groupControl2.Controls.Add(this.sourceLanguageComboBox);
			this.groupControl2.Controls.Add(this.destinationLanguageComboBox);
			this.groupControl2.Controls.Add(this.labelControl3);
			this.groupControl2.Controls.Add(this.labelControl2);
			this.groupControl2.Controls.Add(this.labelControl1);
			this.groupControl2.Controls.Add(this.copyDestinationTextToClipboardCheckBox);
			this.groupControl2.Controls.Add(this.sourceTextTextBox);
			this.groupControl2.Controls.Add(this.buttonTranslate);
			this.groupControl2.Controls.Add(this.pictureBox3);
			this.groupControl2.Name = "groupControl2";
			// 
			// sourceLanguageComboBox
			// 
			resources.ApplyResources(this.sourceLanguageComboBox, "sourceLanguageComboBox");
			this.sourceLanguageComboBox.Name = "sourceLanguageComboBox";
			this.sourceLanguageComboBox.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("sourceLanguageComboBox.Properties.Buttons"))))});
			this.sourceLanguageComboBox.Properties.DropDownRows = 20;
			this.sourceLanguageComboBox.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.sourceLanguageComboBox.SelectedIndexChanged += new System.EventHandler(this.sourceLanguageComboBox_SelectedIndexChanged);
			// 
			// destinationLanguageComboBox
			// 
			resources.ApplyResources(this.destinationLanguageComboBox, "destinationLanguageComboBox");
			this.destinationLanguageComboBox.Name = "destinationLanguageComboBox";
			this.destinationLanguageComboBox.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("destinationLanguageComboBox.Properties.Buttons"))))});
			this.destinationLanguageComboBox.Properties.DropDownRows = 20;
			this.destinationLanguageComboBox.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.destinationLanguageComboBox.SelectedIndexChanged += new System.EventHandler(this.destinationLanguageComboBox_SelectedIndexChanged);
			// 
			// labelControl3
			// 
			resources.ApplyResources(this.labelControl3, "labelControl3");
			this.labelControl3.Name = "labelControl3";
			// 
			// labelControl2
			// 
			resources.ApplyResources(this.labelControl2, "labelControl2");
			this.labelControl2.Name = "labelControl2";
			// 
			// labelControl1
			// 
			resources.ApplyResources(this.labelControl1, "labelControl1");
			this.labelControl1.Name = "labelControl1";
			// 
			// copyDestinationTextToClipboardCheckBox
			// 
			resources.ApplyResources(this.copyDestinationTextToClipboardCheckBox, "copyDestinationTextToClipboardCheckBox");
			this.copyDestinationTextToClipboardCheckBox.Name = "copyDestinationTextToClipboardCheckBox";
			this.copyDestinationTextToClipboardCheckBox.Properties.AutoWidth = true;
			this.copyDestinationTextToClipboardCheckBox.Properties.Caption = resources.GetString("copyDestinationTextToClipboardCheckBox.Properties.Caption");
			this.copyDestinationTextToClipboardCheckBox.Properties.CheckedChanged += new System.EventHandler(this.copyDestinationTextToClipboardCheckBox_CheckedChanged);
			// 
			// sourceTextTextBox
			// 
			resources.ApplyResources(this.sourceTextTextBox, "sourceTextTextBox");
			this.sourceTextTextBox.Name = "sourceTextTextBox";
			this.sourceTextTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.sourceTextTextBox_KeyDown);
			this.sourceTextTextBox.TextChanged += new System.EventHandler(this.sourceTextTextBox_TextChanged);
			// 
			// buttonTranslate
			// 
			resources.ApplyResources(this.buttonTranslate, "buttonTranslate");
			this.buttonTranslate.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
			this.buttonTranslate.Appearance.Options.UseFont = true;
			this.buttonTranslate.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonTranslate.Image = ((System.Drawing.Image)(resources.GetObject("buttonTranslate.Image")));
			this.buttonTranslate.Name = "buttonTranslate";
			this.buttonTranslate.Click += new System.EventHandler(this.buttonTranslate_Click);
			// 
			// pictureBox3
			// 
			this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
			resources.ApplyResources(this.pictureBox3, "pictureBox3");
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.TabStop = false;
			// 
			// panelControl1
			// 
			this.panelControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
			this.panelControl1.Controls.Add(this.closeButton);
			this.panelControl1.Controls.Add(this.groupControl2);
			this.panelControl1.Controls.Add(this.groupControl1);
			resources.ApplyResources(this.panelControl1, "panelControl1");
			this.panelControl1.Name = "panelControl1";
			// 
			// QuickTranslationForm
			// 
			this.AcceptButton = this.buttonTranslate;
			this.Appearance.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			this.Appearance.Options.UseFont = true;
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.CancelButton = this.closeButton;
			resources.ApplyResources(this, "$this");
			this.Controls.Add(this.panelControl1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "QuickTranslationForm";
			this.ShowInTaskbar = false;
			this.Load += new System.EventHandler(this.QuickTranslationForm_Load);
			this.Shown += new System.EventHandler(this.QuickTranslationForm_Shown);
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.QuickTranslationForm_FormClosing);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
			this.groupControl1.ResumeLayout(false);
			this.groupControl1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.destinationTextTextBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
			this.groupControl2.ResumeLayout(false);
			this.groupControl2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.sourceLanguageComboBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.destinationLanguageComboBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.copyDestinationTextToClipboardCheckBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.sourceTextTextBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
			this.panelControl1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.PictureBox pictureBox2;
		private DevExpress.XtraEditors.SimpleButton closeButton;
		private DevExpress.XtraEditors.GroupControl groupControl1;
		private DevExpress.XtraEditors.MemoEdit destinationTextTextBox;
		private DevExpress.XtraEditors.SimpleButton buttonCopyToClipboard;
		private DevExpress.XtraEditors.GroupControl groupControl2;
		private DevExpress.XtraEditors.CheckEdit copyDestinationTextToClipboardCheckBox;
		private DevExpress.XtraEditors.MemoEdit sourceTextTextBox;
		private DevExpress.XtraEditors.SimpleButton buttonTranslate;
		private System.Windows.Forms.PictureBox pictureBox3;
		private DevExpress.XtraEditors.ComboBoxEdit destinationLanguageComboBox;
		private DevExpress.XtraEditors.LabelControl labelControl3;
		private DevExpress.XtraEditors.LabelControl labelControl2;
		private DevExpress.XtraEditors.LabelControl labelControl1;
		private DevExpress.XtraEditors.ComboBoxEdit sourceLanguageComboBox;
		private DevExpress.XtraEditors.PanelControl panelControl1;
	}
}