﻿namespace ZetaResourceEditor.UI.Main
{
	using System;
	using System.Configuration;
	using Code.App;
	using Code.AppHost;
	using DevExpress.XtraEditors.Controls;
	using Helper.Base;
	using Runtime.Code.DL;
	using Zeta.EnterpriseLibrary.Common;
	using Zeta.EnterpriseLibrary.Windows.Common;

	public partial class ExitAdvertisementForm :
		FormBase
	{
		/// <summary>
		/// Checks and shows the trial version form if necessary.
		/// </summary>
		public static void CheckShow()
		{
			if (!ConvertHelper.ToBoolean(
				ConfigurationManager.AppSettings[@"disableExitAdvertisementForm"])
				/*&& !ZetaResourceEditorCommandLineInfo.Current.IsNonblockingGui*/)
			{
				if (HostSettings.Current.License.LicenseType == ZreLicenseType.Freeware)
				{
					var lastExitAdvertisementShownAt =
						ConvertHelper.ToDateTime(
							FormHelper.RestoreValue(@"ExitAdvertisement.LastShown"));

					if (lastExitAdvertisementShownAt <= DateTime.Now.AddDays(-1) ||
					    ConvertHelper.ToBoolean(
							ConfigurationManager.AppSettings[@"forceExitAdvertisementForm"]))
					{
						FormHelper.SaveValue(@"ExitAdvertisement.LastShown", DateTime.Now);

						using (var form = new ExitAdvertisementForm())
						{
							var af = ActiveForm;
							if(af!=null)
							{
								af.Visible = false;
							}
							form.ShowDialog(af);
						}
					}
				}
			}
		}

		public ExitAdvertisementForm()
		{
			InitializeComponent();
		}

		private void ExitAdvertisementForm_Load(object sender, EventArgs e)
		{
			if (ParentForm == null)
			{
				CenterToScreen();
			}
			else
			{
				CenterToParent();
			}

			UpdateUI();
		}

		private void ExitAdvertisementForm_Shown(object sender, EventArgs e)
		{
			buttonClose.Focus();
		}

		private void hyperLinkEdit1_OpenLink(object sender, OpenLinkEventArgs e)
		{
			new ShellExecuteInformation
				{
					FileName = @"http://zeta.li/zre-link--zeta-test-2"
				}
				.Execute();
		}
	}
}