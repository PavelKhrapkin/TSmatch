namespace ZetaResourceEditor.UI.Main
{
	partial class OptionsForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OptionsForm));
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.optionsGroupBox = new DevExpress.XtraEditors.GroupControl();
			this.showNewsCheckEdit = new DevExpress.XtraEditors.CheckEdit();
			this.proxyButton = new DevExpress.XtraEditors.SimpleButton();
			this.buttonCancel = new DevExpress.XtraEditors.SimpleButton();
			this.buttonOK = new DevExpress.XtraEditors.SimpleButton();
			this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
			this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
			this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
			this.xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
			this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
			this.licenseInformationLabel = new DevExpress.XtraEditors.LabelControl();
			this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
			this.purchaseLicenseButton = new DevExpress.XtraEditors.SimpleButton();
			this.licenseKeyMemoEdit = new DevExpress.XtraEditors.MemoEdit();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.optionsGroupBox)).BeginInit();
			this.optionsGroupBox.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.showNewsCheckEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
			this.panelControl1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
			this.xtraTabControl1.SuspendLayout();
			this.xtraTabPage1.SuspendLayout();
			this.xtraTabPage2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
			this.groupControl1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.licenseKeyMemoEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
			resources.ApplyResources(this.pictureBox1, "pictureBox1");
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.TabStop = false;
			// 
			// optionsGroupBox
			// 
			resources.ApplyResources(this.optionsGroupBox, "optionsGroupBox");
			this.optionsGroupBox.Controls.Add(this.showNewsCheckEdit);
			this.optionsGroupBox.Controls.Add(this.pictureBox1);
			this.optionsGroupBox.Controls.Add(this.proxyButton);
			this.optionsGroupBox.Name = "optionsGroupBox";
			// 
			// showNewsCheckEdit
			// 
			resources.ApplyResources(this.showNewsCheckEdit, "showNewsCheckEdit");
			this.showNewsCheckEdit.Name = "showNewsCheckEdit";
			this.showNewsCheckEdit.Properties.AutoWidth = true;
			this.showNewsCheckEdit.Properties.Caption = resources.GetString("showNewsCheckEdit.Properties.Caption");
			// 
			// proxyButton
			// 
			resources.ApplyResources(this.proxyButton, "proxyButton");
			this.proxyButton.Image = ((System.Drawing.Image)(resources.GetObject("proxyButton.Image")));
			this.proxyButton.Name = "proxyButton";
			this.proxyButton.Click += new System.EventHandler(this.proxyButton_Click);
			// 
			// buttonCancel
			// 
			resources.ApplyResources(this.buttonCancel, "buttonCancel");
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.Name = "buttonCancel";
			// 
			// buttonOK
			// 
			resources.ApplyResources(this.buttonOK, "buttonOK");
			this.buttonOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// panelControl1
			// 
			this.panelControl1.Appearance.BackColor = System.Drawing.Color.Transparent;
			this.panelControl1.Appearance.Options.UseBackColor = true;
			this.panelControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
			this.panelControl1.Controls.Add(this.xtraTabControl1);
			this.panelControl1.Controls.Add(this.buttonCancel);
			this.panelControl1.Controls.Add(this.buttonOK);
			resources.ApplyResources(this.panelControl1, "panelControl1");
			this.panelControl1.Name = "panelControl1";
			// 
			// xtraTabControl1
			// 
			resources.ApplyResources(this.xtraTabControl1, "xtraTabControl1");
			this.xtraTabControl1.Name = "xtraTabControl1";
			this.xtraTabControl1.SelectedTabPage = this.xtraTabPage1;
			this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1,
            this.xtraTabPage2});
			// 
			// xtraTabPage1
			// 
			this.xtraTabPage1.Controls.Add(this.optionsGroupBox);
			this.xtraTabPage1.Image = ((System.Drawing.Image)(resources.GetObject("xtraTabPage1.Image")));
			this.xtraTabPage1.Name = "xtraTabPage1";
			resources.ApplyResources(this.xtraTabPage1, "xtraTabPage1");
			// 
			// xtraTabPage2
			// 
			this.xtraTabPage2.Controls.Add(this.groupControl1);
			this.xtraTabPage2.Image = ((System.Drawing.Image)(resources.GetObject("xtraTabPage2.Image")));
			this.xtraTabPage2.Name = "xtraTabPage2";
			resources.ApplyResources(this.xtraTabPage2, "xtraTabPage2");
			// 
			// groupControl1
			// 
			resources.ApplyResources(this.groupControl1, "groupControl1");
			this.groupControl1.Controls.Add(this.licenseInformationLabel);
			this.groupControl1.Controls.Add(this.labelControl1);
			this.groupControl1.Controls.Add(this.purchaseLicenseButton);
			this.groupControl1.Controls.Add(this.licenseKeyMemoEdit);
			this.groupControl1.Controls.Add(this.pictureBox2);
			this.groupControl1.Name = "groupControl1";
			// 
			// licenseInformationLabel
			// 
			resources.ApplyResources(this.licenseInformationLabel, "licenseInformationLabel");
			this.licenseInformationLabel.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
			this.licenseInformationLabel.Appearance.Options.UseFont = true;
			this.licenseInformationLabel.Name = "licenseInformationLabel";
			// 
			// labelControl1
			// 
			resources.ApplyResources(this.labelControl1, "labelControl1");
			this.labelControl1.Name = "labelControl1";
			// 
			// purchaseLicenseButton
			// 
			resources.ApplyResources(this.purchaseLicenseButton, "purchaseLicenseButton");
			this.purchaseLicenseButton.Name = "purchaseLicenseButton";
			this.purchaseLicenseButton.Click += new System.EventHandler(this.purchaseLicenseButton_Click);
			// 
			// licenseKeyMemoEdit
			// 
			resources.ApplyResources(this.licenseKeyMemoEdit, "licenseKeyMemoEdit");
			this.licenseKeyMemoEdit.Name = "licenseKeyMemoEdit";
			this.licenseKeyMemoEdit.EditValueChanged += new System.EventHandler(this.licenseKeyMemoEdit_EditValueChanged);
			// 
			// pictureBox2
			// 
			this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
			resources.ApplyResources(this.pictureBox2, "pictureBox2");
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.TabStop = false;
			// 
			// OptionsForm
			// 
			this.AcceptButton = this.buttonOK;
			this.Appearance.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			this.Appearance.Options.UseFont = true;
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.CancelButton = this.buttonCancel;
			resources.ApplyResources(this, "$this");
			this.Controls.Add(this.panelControl1);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "OptionsForm";
			this.ShowInTaskbar = false;
			this.Load += new System.EventHandler(this.OptionsForm_Load);
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OptionsForm_FormClosing);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.optionsGroupBox)).EndInit();
			this.optionsGroupBox.ResumeLayout(false);
			this.optionsGroupBox.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.showNewsCheckEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
			this.panelControl1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
			this.xtraTabControl1.ResumeLayout(false);
			this.xtraTabPage1.ResumeLayout(false);
			this.xtraTabPage2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
			this.groupControl1.ResumeLayout(false);
			this.groupControl1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.licenseKeyMemoEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.PictureBox pictureBox1;
		private DevExpress.XtraEditors.GroupControl optionsGroupBox;
		private DevExpress.XtraEditors.SimpleButton buttonCancel;
		private DevExpress.XtraEditors.SimpleButton buttonOK;
		private DevExpress.XtraEditors.CheckEdit showNewsCheckEdit;
		private DevExpress.XtraEditors.PanelControl panelControl1;
		private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
		private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
		private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
		private DevExpress.XtraEditors.GroupControl groupControl1;
		private System.Windows.Forms.PictureBox pictureBox2;
		private DevExpress.XtraEditors.LabelControl labelControl1;
		private DevExpress.XtraEditors.MemoEdit licenseKeyMemoEdit;
		private DevExpress.XtraEditors.LabelControl licenseInformationLabel;
		private DevExpress.XtraEditors.SimpleButton purchaseLicenseButton;
		private DevExpress.XtraEditors.SimpleButton proxyButton;
	}
}