﻿namespace ZetaResourceEditor.Code.Helper
{
	#region Using directives.
    // ----------------------------------------------------------------------

    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Net;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Web;
    using App;
    using Properties;
    using TranslationService;
    using Zeta.EnterpriseLibrary.Common.Collections;

	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	public sealed class TranslationHelper
	{
		private Pair<string, string>[] _sourceLanguages;
		private Pair<string, string>[] _destinationLanguages;
		private SelfTranslationInformation _infos;
		private TranslationMode3[] _stms;
		private TranslationMode3[] _dtms;

		public Pair<string, string>[] GetSourceLanguages()
		{
			if (_sourceLanguages == null)
			{
				var result = new List<Pair<string, string>>();

				var modes = WebServiceManager.Current.TranslationWS.GetAllSourceTranslationModes();

				foreach (var mode in modes)
				{
					if (mode.LanguageCode == @"auto")
					{
						result.Add(
							new Pair<string, string>(
								Resources.SR_TranslationHelper_GetSourceLanguages_AutoDetect,
								mode.LanguageCode));
					}
					else
					{
						result.Add(
							new Pair<string, string>(
								CultureInfo.GetCultureInfo(mode.LanguageCode).DisplayName,
								mode.LanguageCode));
					}
				}

				_sourceLanguages = result.ToArray();
			}

			return _sourceLanguages;
		}

		public Pair<string, string>[] GetDestinationLanguages()
		{
			if (_destinationLanguages == null)
			{
				var result = new List<Pair<string, string>>();

                var modes = WebServiceManager.Current.TranslationWS.GetAllDestinationTranslationModes();

				foreach (var mode in modes)
				{
					result.Add(
						new Pair<string, string>(
							CultureInfo.GetCultureInfo(mode.LanguageCode).DisplayName,
							mode.LanguageCode));
				}

				_destinationLanguages = result.ToArray();
			}

			return _destinationLanguages;
		}

		public string Translate(
			string text,
			string sourceLanguageCode,
			string destinationLanguageCode)
		{
			if (_infos == null)
			{
                _infos = WebServiceManager.Current.TranslationWS.GetSelfTranslationInformation();
			}

			return doTranslate(
				text,
				sourceLanguageCode,
				destinationLanguageCode);

			/*
			var sm =
				new TranslationMode3
				{
					LanguageCode = sourceLanguageCode
				};
			var dm =
				new TranslationMode3
				{
					LanguageCode = destinationLanguageCode
				};

			return ws.Translate( sm, dm, text );
			*/
		}

		private string doTranslate(
			string textToTranslate,
			string sourceLanguageCode,
			string destinationLanguageCode)
		{
            // AJ CHANGE 
            // Replace { before translation and them replace them back
            // This is because Google replaces { with ( which we dont want
            const string leftBracket = @"LeftBracketPlaceHolder";
            const string rightBracket = @"RightBracketPlaceHolder";
            
			sourceLanguageCode = mapSourceLanguageCode(sourceLanguageCode);
			destinationLanguageCode = mapDestinationLanguageCode(destinationLanguageCode);

            textToTranslate = textToTranslate.Replace(@"{", leftBracket);
            textToTranslate = textToTranslate.Replace(@"}", rightBracket);

			var rawPageContent = getRawPageContent(
				sourceLanguageCode,
				destinationLanguageCode,
				textToTranslate);

			var translatedText = parseRawPageContent(rawPageContent);

            translatedText = translatedText.Replace(leftBracket, @"{");
            translatedText = translatedText.Replace(rightBracket, @"}");

            return translatedText;
		}

		private string mapDestinationLanguageCode(string destinationLanguageCode)
		{
			if (_dtms == null)
			{
                _dtms = WebServiceManager.Current.TranslationWS.GetAllSourceTranslationModes();
			}

			// First pass, try direct.
			foreach (var dtm in _dtms)
			{
				if (string.Compare(dtm.LanguageCode, destinationLanguageCode, true) == 0)
				{
					return destinationLanguageCode;
				}
			}

			// Second pass, try two.
			if (destinationLanguageCode.Length > 2)
			{
				var d2 = destinationLanguageCode.Substring(0, 2);

				foreach (var dtm in _dtms)
				{
					if (string.Compare(dtm.LanguageCode, d2, true) == 0)
					{
						return d2;
					}
				}
			}

			// Not found.
			return destinationLanguageCode;
		}

		private string mapSourceLanguageCode(string sourceLanguageCode)
		{
			if (_stms == null)
			{
                _stms = WebServiceManager.Current.TranslationWS.GetAllSourceTranslationModes();
			}

			// First pass, try direct.
			foreach (var stm in _stms)
			{
				if (string.Compare(stm.LanguageCode, sourceLanguageCode, true) == 0)
				{
					return sourceLanguageCode;
				}
			}

			// Second pass, try two.
			if (sourceLanguageCode.Length > 2)
			{
				var d2 = sourceLanguageCode.Substring(0, 2);

				foreach (var stm in _stms)
				{
					if (string.Compare(stm.LanguageCode, d2, true) == 0)
					{
						return d2;
					}
				}
			}

			// Not found.
			return sourceLanguageCode;
		}

		private string parseRawPageContent(
			string rawPageContent)
        {
            var reg = new Regex(
				_infos.ParseRegexPattern,
				RegexOptions.IgnoreCase);

			// --

			var matches = reg.Matches(rawPageContent);
			if (matches.Count != 1 || matches[0].Groups.Count != 2)
			{
				throw new ApplicationException(
					Resources.SR_TranslationHelper_parseRawPageContent_GoogleCodeChanged);
			}
			else
			{
                // AJ CHANGE 
                return HttpUtility.HtmlDecode(HttpUtility.HtmlDecode(removeHtmlTags(matches[0].Groups[1].Value).Trim()));
			}
		}

		private static string removeHtmlTags(string text)
		{
			if (string.IsNullOrEmpty(text) || !text.Contains(@"<"))
			{
				return text;
			}
			else
			{
				var reg = new Regex(
					@"<[^>]*?>",
					RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.Multiline);

				text = reg.Replace(text, string.Empty);
				text = text.Replace(@"  ", @" ");
				text = text.Replace(@"  ", @" ");

				return text;
			}
		}

		private string getRawPageContent(
			string sourceLanguageCode,
			string destinationLanguageCode,
			string textToTranslate)
		{
			var request = (HttpWebRequest)WebRequest.Create(_infos.GoogleUrl);
            request.Referer = _infos.GoogleRefererUrl;

		    WebServiceManager.Current.ApplyProxy(request);

			// Encode all the source data.
			var postSourceData =
				_infos.HttpPostData
					.Replace(@"{TextToTranslate}", HttpUtility.UrlEncode(textToTranslate.Trim()))
					.Replace(@"{SourceLanguageCode}", HttpUtility.UrlEncode(sourceLanguageCode.Trim()))
					.Replace(@"{DestinationLanguageCode}", HttpUtility.UrlEncode(destinationLanguageCode.Trim()));
			request.Method = @"POST";
			request.ContentType = @"application/x-www-form-urlencoded";
			request.ContentLength = postSourceData.Length;
			request.UserAgent = @"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)";

			var writeStream = request.GetRequestStream();
			var bytes = Encoding.UTF8.GetBytes(postSourceData);
			writeStream.Write(bytes, 0, bytes.Length);
			writeStream.Close();

			// --

			string page;

			// If the following fails, you must add this to web.config:
			// <configuration> 
			//		<system.net> 
			//			<settings> 
			//				<httpWebRequest useUnsafeHeaderParsing="true" /> 
			//			</settings> 
			//		</system.net> 
			// </configuration>
			using (var response = (HttpWebResponse)request.GetResponse())
			using (var responseStream = response.GetResponseStream())
			using (var readStream = new StreamReader(responseStream, Encoding.UTF8))
			{
				page = readStream.ReadToEnd();
			}

			return page;
		}

	}

	/////////////////////////////////////////////////////////////////////////
}