namespace ZetaResourceEditor.UI.Helper
{
	using System;
	using System.Windows.Forms;
	using Base;
	using Zeta.EnterpriseLibrary.Windows.Common;

	public partial class ObjectInspectorForm :
		FormBase
	{
		public ObjectInspectorForm()
		{
			InitializeComponent();
		}

		public void Initialize(
			object objectToInspect )
		{
			propertyGrid.SelectedObject = objectToInspect;
		}

		private void objectInspectorForm_Load(
			object sender,
			EventArgs e )
		{
			FormHelper.RestoreState( this );
			CenterToParent();
		}

		private void objectInspectorForm_FormClosing(
			object sender,
			FormClosingEventArgs e )
		{
			FormHelper.SaveState( this );
		}
	}
}