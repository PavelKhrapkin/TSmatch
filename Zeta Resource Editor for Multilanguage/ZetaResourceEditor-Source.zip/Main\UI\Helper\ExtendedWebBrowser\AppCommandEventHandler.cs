namespace ZetaResourceEditor.UI.Helper.ExtendedWebBrowser
{
	#region Using directives.
	// ----------------------------------------------------------------------
	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// Used by the HTML control.
	/// </summary>
	public delegate void AppCommandEventHandler(
		object sender,
		AppCommandEventArgs e );

	/////////////////////////////////////////////////////////////////////////
}