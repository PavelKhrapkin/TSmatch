﻿namespace ZetaResourceEditor.UI.Helper
{
	using System.Collections.Generic;
	using DevExpress.XtraEditors;
	using Zeta.EnterpriseLibrary.Tools.Storage;
	using Zeta.EnterpriseLibrary.Windows.Common;

	internal static class DevExpressExtensionMethods
	{
		public static void PersistSettings(
			CheckedListBoxControl c,
			IPersistentPairStorage storage,
			string key )
		{
			var indexes = new List<string>();

			for ( var i = 0; i < c.Items.Count; ++i )
			{
				if ( c.GetItemChecked( i ) )
				{
					indexes.Add( i.ToString() );
				}
			}

			FormHelper.SaveValue( storage, key, string.Join( @";", indexes.ToArray() ) );
		}

		public static void RestoreSettings(
			CheckedListBoxControl c,
			IPersistentPairStorage storage,
			string key )
		{
			var indexes = new List<string>();

			for ( var i = 0; i < c.Items.Count; ++i )
			{
				if ( c.GetItemChecked( i ) )
				{
					indexes.Add( i.ToString() );
				}
			}

			var def = string.Join( @";", indexes.ToArray() );

			// --

			var s = FormHelper.RestoreValue(
				storage,
				key,
				def ) as string;

			if ( string.IsNullOrEmpty( s ) )
			{
				for ( var i = 0; i < c.Items.Count; ++i )
				{
					c.SetItemChecked( i, false );
				}
			}
			else
			{
				var splitted = new List<string>( s.Split( ';' ) );

				var ris = new List<int>();
				splitted.ForEach( x => ris.Add( int.Parse( x ) ) );

				for ( var i = 0; i < c.Items.Count; ++i )
				{
					c.SetItemChecked( i, ris.Contains( i ) );
				}
			}
		}
	}
}