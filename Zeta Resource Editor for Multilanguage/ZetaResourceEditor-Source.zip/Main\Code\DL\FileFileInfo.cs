﻿namespace ZetaResourceEditor.Code.DL
{
	using System;
	using System.IO;
	using System.Xml;
	using Zeta.EnterpriseLibrary.Common;

	public class FileFileInfo :
		ITranslationStateInformation,
		IComparable,
		IComparable<FileFileInfo>,
		IUniqueID
	{
		private readonly FileGroup _fileGroup;
		private FileInfo _file;
		private Guid _uniqueID;

		public FileFileInfo(
			FileGroup fileGroup )
		{
			_fileGroup = fileGroup;
		}

		public FileGroup FileGroup
		{
			get
			{
				return _fileGroup;
			}
		}

		public FileGroupStateColor TranslationStateColor
		{
			get
			{
				// Same as parent.
				return _fileGroup.TranslationStateColor;
			}
		}

		public FileInfo File
		{
			get
			{
				return _file;
			}
			set
			{
				_file = value;
			}
		}

		public int CompareTo( object obj )
		{
			return CompareTo( (FileFileInfo)obj );
		}

		public int CompareTo( FileFileInfo other )
		{
			var x = Path.GetFileNameWithoutExtension( File.FullName );
			var y = Path.GetFileNameWithoutExtension( other.File.FullName );

			if ( (x.Contains( @"." ) && y.Contains( @"." )) ||
				(!x.Contains( @"." ) && !y.Contains( @"." )) )
			{
				return x.CompareTo( y );
			}
			else
			{
				if ( x.Contains( @"." ) )
				{
					if ( x.StartsWith( y, StringComparison.InvariantCultureIgnoreCase ) )
					{
						return +1;
					}
					else
					{
						return x.CompareTo( y );
					}
				}
				else
				{
					if ( y.StartsWith( x, StringComparison.InvariantCultureIgnoreCase ) )
					{
						return -1;
					}
					else
					{
						return x.CompareTo( y );
					}
				}
			}
		}

		public void StoreToXml( Project project, XmlElement parentNode )
		{
			var a = parentNode.OwnerDocument.CreateAttribute( @"filePath" );
			a.Value = project.MakeRelativeFilePath( _file.FullName );
			parentNode.Attributes.Append( a );

			a = parentNode.OwnerDocument.CreateAttribute( @"absoluteFilePath" );
			a.Value = _file.FullName;
			parentNode.Attributes.Append( a );

			a = parentNode.OwnerDocument.CreateAttribute( @"uniqueID" );
			a.Value = _uniqueID.ToString();
			parentNode.Attributes.Append( a );
		}

		public bool LoadFromXml( Project project, XmlNode parentNode )
		{
			XmlHelper.ReadAttribute(
				out _uniqueID,
				parentNode.Attributes[@"uniqueID"] );

			if ( _uniqueID == Guid.Empty )
			{
				_uniqueID = Guid.NewGuid();
			}

			// --

			string filePath;
			XmlHelper.ReadAttribute(
				out filePath,
				parentNode.Attributes[@"filePath"] );

			filePath = project.MakeAbsoluteFilePath( filePath );

			if ( !string.IsNullOrEmpty( filePath ) && System.IO.File.Exists( filePath ) )
			{
				_file = new FileInfo( filePath );
				return true;
			}
			else
			{
				// Try absolute file path if relative one fails.
				XmlHelper.ReadAttribute(
					out filePath,
					parentNode.Attributes[@"absoluteFilePath"] );

				if ( !string.IsNullOrEmpty( filePath ) && System.IO.File.Exists( filePath ) )
				{
					_file = new FileInfo( filePath );
					return true;
				}
				else
				{
					return false;
				}
			}
		}

		public Guid UniqueID
		{
			get
			{
				return _uniqueID;
			}
		}
	}
}