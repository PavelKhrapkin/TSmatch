﻿namespace ZetaResourceEditor.UI.Projects
{
	using System;
	using System.Diagnostics;
	using System.IO;
	using System.Windows.Forms;
	using Code.App;
	using Code.DL;
	using DevExpress.XtraBars;
	using DevExpress.XtraEditors;
	using DevExpress.XtraEditors.Controls;
	using Helper.Base;
	using Zeta.EnterpriseLibrary.Tools;
	using Zeta.EnterpriseLibrary.Windows.Common;

	public partial class ProjectSettingsForm : FormBase
	{
		private Project _project;

		public ProjectSettingsForm()
		{
			InitializeComponent();
		}

		internal void Initialize(
			Project project)
		{
			_project = project;
		}

		private class ReadOnlyHelper
		{
			public ReadOnlyFileOverwriteBehaviour Behaviour { get; private set; }

			public ReadOnlyHelper(ReadOnlyFileOverwriteBehaviour behaviour)
			{
				Behaviour = behaviour;
			}

			public override string ToString()
			{
				return StringHelper.GetEnumDescription(Behaviour);
			}
		}

		private void projectSettingsForm_Load(
			object sender,
			EventArgs e)
		{
			FormHelper.RestoreState(this);
			CenterToParent();

			foreach (ReadOnlyFileOverwriteBehaviour rob in
				Enum.GetValues(typeof(ReadOnlyFileOverwriteBehaviour)))
			{
				readOnlySaveBehaviourComboBox.Properties.Items.Add(
					new ReadOnlyHelper(rob));
			}

			selectReadOnlyBehaviour(
				readOnlySaveBehaviourComboBox,
				_project.ReadOnlyFileOverwriteBehaviour);

			nameTextBox.Text = Path.GetFileNameWithoutExtension(
				_project.ProjectConfigurationFilePath.Name);
			locationTextBox.Text = _project.ProjectConfigurationFilePath.DirectoryName;
			neutralLanguageCodeTextEdit.Text = _project.NeutralLanguageCode;
			useSpellCheckingCheckEdit.Checked = _project.UseSpellChecker;
			createBackupsCheckBox.Checked = _project.CreateBackupFiles;
			omitEmptyItemsCheckBox.Checked = _project.OmitEmptyItems;
			hideEmptyRowsCheck.Checked = _project.HideEmptyRows;
			showCommentsColumnInGridCheckEdit.Checked = _project.ShowCommentsColumnInGrid;
			descriptionTextBox.Text = _project.Description;
			ignoreWindowsFormsDesignerFiles.Checked =
				_project.IgnoreWindowsFormsResourcesWithDesignerFiles;
			hideInternalDesignerRowsCheckEdit.Checked =
				_project.HideInternalDesignerRows;
			shallowCumulationCheckEdit.Checked =
				_project.UseShallowGridDataCumulation;

			neutralLanguageFileNamePatternTextEdit.Text = _project.NeutralLanguageFileNamePattern;
			nonNeutralLanguageFileNamePatternTextEdit.Text = _project.NonNeutralLanguageFileNamePattern;
			baseNameDotCountSpinEdit.Value = _project.BaseNameDotCount;
			defaultTypesTextEdit.Text = _project.DefaultFileTypesToIgnore;
			useCrypticExcelExportSheetNamesCheckEdit.Checked = _project.UseCrypticWorkSheetNamesForExcelExport;
            persistGridSettingsCheckEdit.Checked = _project.PersistGridSettings;
			colorifyNullCellsCheckEdit.Checked = _project.ColorifyNullCells;
		}

		private static void selectReadOnlyBehaviour(
			ComboBoxEdit comboBoxEdit,
			ReadOnlyFileOverwriteBehaviour behaviour)
		{
			foreach (ReadOnlyHelper roh in comboBoxEdit.Properties.Items)
			{
				if (roh.Behaviour == behaviour)
				{
					comboBoxEdit.SelectedItem = roh;
					break;
				}
			}
		}

		private void projectSettingsForm_FormClosing(
			object sender,
			FormClosingEventArgs e)
		{
			FormHelper.SaveState(this);
		}

		private void buttonOK_Click(object sender, EventArgs e)
		{
			_project.ReadOnlyFileOverwriteBehaviour =
				((ReadOnlyHelper) readOnlySaveBehaviourComboBox.SelectedItem).Behaviour;

			_project.CreateBackupFiles = createBackupsCheckBox.Checked;
			_project.OmitEmptyItems = omitEmptyItemsCheckBox.Checked;
			_project.Description = descriptionTextBox.Text.Trim();
			_project.NeutralLanguageCode = neutralLanguageCodeTextEdit.Text.Trim();
			_project.UseSpellChecker = useSpellCheckingCheckEdit.Checked;
			_project.HideEmptyRows = hideEmptyRowsCheck.Checked;
			_project.ShowCommentsColumnInGrid = showCommentsColumnInGridCheckEdit.Checked;
			_project.IgnoreWindowsFormsResourcesWithDesignerFiles =
				ignoreWindowsFormsDesignerFiles.Checked;
			_project.HideInternalDesignerRows =
				hideInternalDesignerRowsCheckEdit.Checked;
			_project.UseShallowGridDataCumulation = shallowCumulationCheckEdit.Checked;

			_project.NeutralLanguageFileNamePattern = neutralLanguageFileNamePatternTextEdit.Text.Trim();
			_project.NonNeutralLanguageFileNamePattern = nonNeutralLanguageFileNamePatternTextEdit.Text.Trim();
			_project.BaseNameDotCount = (int) baseNameDotCountSpinEdit.Value;
			_project.DefaultFileTypesToIgnore = defaultTypesTextEdit.Text.Trim();
			_project.UseCrypticWorkSheetNamesForExcelExport = useCrypticExcelExportSheetNamesCheckEdit.Checked;
		    _project.PersistGridSettings = persistGridSettingsCheckEdit.Checked;
			_project.ColorifyNullCells = colorifyNullCellsCheckEdit.Checked;

			_project.MarkAsModified();
		}

		private void openButton_ItemClick(object sender, ItemClickEventArgs e)
		{
			if (!string.IsNullOrEmpty(locationTextBox.Text) &&
				Directory.Exists(locationTextBox.Text))
			{
				var sei =
					new ShellExecuteInformation
					{
						FileName = locationTextBox.Text
					};

				sei.Execute();
			}
		}

		private void hyperLinkEdit1_OpenLink(object sender, OpenLinkEventArgs e)
		{
			Process.Start(
				@"http://extensions.services.openoffice.org/dictionary");
		}
	}
}
