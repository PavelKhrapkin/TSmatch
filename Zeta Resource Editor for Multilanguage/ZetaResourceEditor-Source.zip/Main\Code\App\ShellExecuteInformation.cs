﻿namespace ZetaResourceEditor.Code.App
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System.Diagnostics;
	using System.IO;
	using Zeta.EnterpriseLibrary.Logging;

	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// Information for passing to the ShellExecute method.
	/// </summary>
	public class ShellExecuteInformation
	{
		#region Public methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// Executes this instance.
		/// </summary>
		public void Execute()
		{
			//string file = _fileName.ToLowerInvariant();

			//if ( _useHttpPostIfApplicable &&
			//    (
			//    file.IndexOf( @"http://" ) == 0 ||
			//    file.IndexOf( @"https://" ) == 0
			//    ) &&
			//    (
			//    file.Length >= _httpGetLengthLimit ||
			//    file.IndexOf( @"{postfile:" ) >= 0
			//    )
			//    )
			//{
			//    // A HTTP GET can only handle URLs up to 1024 characters
			//    // length. Do a POST otherwise.

			//    Post( _fileName );
			//}
			//else
			{
				LogCentral.Current.LogDebug(
					string.Format(
					@"About to shell-execute the command '{0}'.",
					_fileName ) );

				checkSplitFileName();

				// Do 'normal' ShellExecute.
				var info =
					new ProcessStartInfo
						{
							UseShellExecute = true,
							Verb = _verb,
							FileName = _fileName,
							Arguments = _arguments,
							WorkingDirectory = _workingDirectory,
							WindowStyle = _windowStyle
						};

				Process.Start( info );
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Public properties.
		// ------------------------------------------------------------------

		/// <summary>
		/// Gets or sets the name of the file.
		/// </summary>
		/// <value>The name of the file.</value>
		public string FileName
		{
			get
			{
				return _fileName;
			}
			set
			{
				_fileName = value;
			}
		}

		/// <summary>
		/// Gets or sets the arguments.
		/// </summary>
		/// <value>The arguments.</value>
		public string Arguments
		{
			get
			{
				return _arguments;
			}
			set
			{
				_arguments = value;
			}
		}

		/// <summary>
		/// Gets or sets the working directory.
		/// </summary>
		/// <value>The working directory.</value>
		public string WorkingDirectory
		{
			get
			{
				return _workingDirectory;
			}
			set
			{
				_workingDirectory = value;
			}
		}

		/// <summary>
		/// Gets or sets the window style.
		/// </summary>
		/// <value>The window style.</value>
		public ProcessWindowStyle WindowStyle
		{
			get
			{
				return _windowStyle;
			}
			set
			{
				_windowStyle = value;
			}
		}

		/// <summary>
		/// Gets or sets the verb.
		/// </summary>
		/// <value>The verb.</value>
		public string Verb
		{
			get
			{
				return _verb;
			}
			set
			{
				_verb = value;
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether [use HTTP post if applicable].
		/// </summary>
		/// <value>
		/// 	<c>true</c> if [use HTTP post if applicable]; otherwise, <c>false</c>.
		/// </value>
		public bool UseHttpPostIfApplicable
		{
			get
			{
				return _useHttpPostIfApplicable;
			}
			set
			{
				_useHttpPostIfApplicable = value;
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Private methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// Splits the file name if it contains an executable AND an argument.
		/// </summary>
		private void checkSplitFileName()
		{
			if ( !string.IsNullOrEmpty( _fileName ) )
			{
				if ( _fileName.IndexOf( @"http://" ) == 0 ||
					_fileName.IndexOf( @"https://" ) == 0 )
				{
					// Already a full path, do nothing.
					return;
				}
				else if ( File.Exists( _fileName ) )
				{
					// Already a full path, do nothing.
					return;
				}
				else if ( Directory.Exists( _fileName ) )
				{
					// Already a full path, do nothing.
					return;
				}
				else
				{
					// Remember.
					var originalFileName = _fileName;

					if ( !string.IsNullOrEmpty( _fileName ) )
					{
						_fileName = _fileName.Trim();
					}

					if ( !string.IsNullOrEmpty( _arguments ) )
					{
						_arguments = _arguments.Trim();
					}

					// --

					if ( string.IsNullOrEmpty( _arguments ) &&
						!string.IsNullOrEmpty( _fileName ) && _fileName.Length > 2 )
					{
						if ( _fileName.StartsWith( @"""" ) )
						{
							int pos = _fileName.IndexOf( @"""", 1 );

							if ( pos > 0 && _fileName.Length > pos + 1 )
							{
								_arguments = _fileName.Substring( pos + 1 ).Trim();
								_fileName = _fileName.Substring( 0, pos + 1 ).Trim();
							}
						}
						else
						{
							int pos = _fileName.IndexOf( @" " );
							if ( pos > 0 && _fileName.Length > pos + 1 )
							{
								_arguments = _fileName.Substring( pos + 1 ).Trim();
								_fileName = _fileName.Substring( 0, pos + 1 ).Trim();
							}
						}
					}

					// --
					// Possibly revert back.

					if ( !string.IsNullOrEmpty( _fileName ) )
					{
						string s = _fileName.Trim( '"' );
						if ( !File.Exists( s ) && !Directory.Exists( s ) )
						{
							_fileName = originalFileName;
						}
					}
				}
			}
		}

		/*
		/// <summary>
		/// Posts the specified raw URL.
		/// </summary>
		/// <param name="rawUrl">The raw URL.</param>
		private static void Post(
			string rawUrl )
		{
			LogCentral.Current.LogDebug(
				string.Format(
				@"About post shell execute URL '{0}'.",
				rawUrl ) );

			// --
			// Build a temporary html fileAsset.

			UrlParser uri = new UrlParser( rawUrl );

			string html =
				Host.Current.ReadHtmlResourceFile(
				@"ShellExecuteHttpPoster.html" );

			html = BackendHelper.ExpandDispatchUrlPlaceholder( html );

			html = html.Replace( @"{PostUrl}", uri.BeforeUrl );
			html = html.Replace( @"{ServerName}", uri.Uri.Host );
			html = html.Replace( @"{ServiceType}", uri.Uri.Scheme );

			string htmlHiddenFields = string.Empty;

			// Build the hidden fields.
			foreach ( string key in uri.Parameters.Keys )
			{
				string hiddenName =
					PathHelper.HtmlEncode( key );
				string hiddenValue =
					PathHelper.HtmlEncode( uri.Parameters[key] );

				const string postFileStart = @"{PostFile:";

				// Must read-in the fileAsset content and store it 
				// in an ASCII-encoded string.
				if ( hiddenValue.StartsWith( postFileStart ) )
				{
					string filePath =
						hiddenValue.Substring(
						postFileStart.Length );
					filePath = filePath.TrimEnd( '}' );

					// --

					using ( FileStream fs = new FileStream(
						filePath,
						FileMode.Open,
						FileAccess.Read ) )
					using ( BinaryReader br = new BinaryReader( fs ) )
					{
						byte[] buffer = new byte[fs.Length];
						br.Read( buffer, 0, (int)fs.Length );

						hiddenValue = Convert.ToBase64String( buffer );
					}
				}
				else
				{
					// Translate back and forth.
					hiddenValue = PathHelper.UrlDecode( hiddenValue );
					hiddenValue = PathHelper.HtmlEncode( hiddenValue );

					// Escape multilines, since they are not allowed.
					hiddenValue = hiddenValue.Replace( "\r", @"\r" );
					hiddenValue = hiddenValue.Replace( "\n", @"\n" );

					// Escape quotes, as Microsoft FrontPage does.
					hiddenName = hiddenName.Replace( @"'", @"&#039;" );
					hiddenValue = hiddenValue.Replace( @"'", @"&#039;" );
					hiddenName = hiddenName.Replace( @"""", @"&quot;" );
					hiddenValue = hiddenValue.Replace( @"""", @"&quot;" );
				}

				if ( !string.IsNullOrEmpty( htmlHiddenFields ) )
				{
					htmlHiddenFields += Environment.NewLine;
				}

				htmlHiddenFields +=
					string.Format(
					@"<input type=""hidden"" name=""{0}"" value=""{1}"" />",
					hiddenName,
					hiddenValue );
			}

			html = html.Replace( @"{Parameters}", htmlHiddenFields );

			// --
			// Write the temporary file.

			// Only three extension characters!
			FileInfo theFilePath = PathHelper.GetTempFileName( @"htm" );
			RuntimeBaseConfiguration.Current.AddTempFileToDelete(
				theFilePath.FullName );

			UnicodeString.WriteTextFile(
				theFilePath,
				html );

			// --
			// Shell-execute the created fileAsset.

			ProcessStartInfo info = new ProcessStartInfo();

			info.UseShellExecute = true;
			info.FileName = theFilePath.FullName;

			Process.Start( info );
		}
		*/

		// ------------------------------------------------------------------
		#endregion

		#region Private variables.
		// ------------------------------------------------------------------

		/// <summary>
		/// The maximum number of characters allowed without POSTing.
		/// </summary>
		//private static readonly int _httpGetLengthLimit = 1000;

		private string _fileName;
		private string _arguments;
		private string _workingDirectory;
		private ProcessWindowStyle _windowStyle;
		private string _verb;
		private bool _useHttpPostIfApplicable = true;

		// ------------------------------------------------------------------
		#endregion
	}

	/////////////////////////////////////////////////////////////////////////
}