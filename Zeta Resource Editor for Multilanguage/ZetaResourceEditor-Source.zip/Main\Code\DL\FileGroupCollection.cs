namespace ZetaResourceEditor.Code.DL
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System.Collections.Generic;
	using System.Xml;
	using Zeta.EnterpriseLibrary.Common.Collections;

	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// 
	/// </summary>
	public class FileGroupCollection :
		List<FileGroup>
	{
		private readonly Project _project;

		/// <summary>
		/// Initializes a new instance of the <see cref="FileGroupCollection"/> class.
		/// </summary>
		/// <param name="project">The project.</param>
		public FileGroupCollection(
			Project project)
		{
			_project = project;
		}

		/// <summary>
		/// Gets the project.
		/// </summary>
		/// <value>The project.</value>
		public Project Project
		{
			get
			{
				return _project;
			}
		}

		/// <summary>
		/// Stores to XML.
		/// </summary>
		/// <param name="parentNode">The parent node.</param>
		internal void StoreToXml(
			XmlElement parentNode)
		{
			var groupsNode =
				parentNode.OwnerDocument.CreateElement(@"fileGroups");
			parentNode.AppendChild(groupsNode);

			foreach (var fileGroup in this)
			{
				var fileGroupNode =
					parentNode.OwnerDocument.CreateElement(@"fileGroup");
				groupsNode.AppendChild(fileGroupNode);

				fileGroup.StoreToXml(_project, fileGroupNode);
			}
		}

		/// <summary>
		/// Loads from XML.
		/// </summary>
		/// <param name="parentNode">The parent node.</param>
		internal void LoadFromXml(
			XmlNode parentNode)
		{
			Clear();

			var fileGroupNodes =
				parentNode.SelectNodes(@"fileGroups/fileGroup");

			if (fileGroupNodes != null)
			{
				foreach (XmlNode fileGroupNode in fileGroupNodes)
				{
					var fileGroup = new FileGroup(_project);
					fileGroup.LoadFromXml(_project, fileGroupNode);

					// Do not add orphans.
					if (fileGroup.Count > 0)
					{
						Add(fileGroup);
					}
				}
			}

			// --

			Sort(
				/*delegate(FileGroup a, FileGroup b)
					{
						if (a.Count <= 0)
						{
							return +1;
						}
						else if (b.Count <= 0)
						{
							return -1;
						}
						else
						{
							return string.Compare(
								a.GetNameIntelligent(_project),
								b.GetNameIntelligent(_project),
								true);
						}
					}*/
					   );
		}

		/// <summary>
		/// Determines whether [has file group with checksum] [the specified checksum].
		/// </summary>
		/// <param name="checksum">The checksum.</param>
		/// <returns>
		/// 	<c>true</c> if [has file group with checksum] [the specified checksum]; otherwise, <c>false</c>.
		/// </returns>
		public bool HasFileGroupWithChecksum(
			long checksum)
		{
			foreach (var fileGroup in this)
			{
				if (fileGroup.GetChecksum(_project) == checksum)
				{
					return true;
				}
			}

			return false;
		}

		public Pair<string, string>[] GetLanguageCodesExtended(
			Project project)
		{
			var result = new Set<Pair<string, string>>();

			foreach (var fg in this)
			{
				foreach (var f in fg.GetLanguageCodesExtended(project))
				{
					Pair<string, string> p;
					if (!result.Find(out p, x => string.Compare(x.First, f.First, true) == 0))
					{
						result.Add(f);
					}
				}
			}

			return result.ToArray();
		}
	}

	/////////////////////////////////////////////////////////////////////////
}