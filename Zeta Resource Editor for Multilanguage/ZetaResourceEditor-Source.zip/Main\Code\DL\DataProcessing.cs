using ZetaResourceEditor.Code.Helper;

namespace ZetaResourceEditor.Code.DL
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System;
	using System.Collections.Generic;
	using System.Data;
	using System.Diagnostics;
	using System.IO;
	using System.Text;
	using System.Xml;
	using Properties;
	using UI.Main;
	using Zeta.EnterpriseLibrary.Common.IO;

	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	public enum AskOverwriteResult
	{
		Overwrite,
		Skip,
		Fail
	}

	public delegate AskOverwriteResult AskOverwriteDelegate<T>(T obj);

	/// <summary>
	/// 
	/// </summary>
	internal sealed class DataProcessing
	{
		#region Private variables.
		// ------------------------------------------------------------------

		private List<ResxFile> _documentList;
		private readonly IGridEditableData _gridEditableData;

		public static event AskOverwriteDelegate<FileInfo> CanOverwrite;

		// ------------------------------------------------------------------
		#endregion

		#region Private methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// Load files from FileSystem
		/// </summary>
		private void loadFiles()
		{
			_documentList = new List<ResxFile>();

			foreach (var item in _gridEditableData.GetFileFileInfosSorted())
			{
				using (var reader = XmlReader.Create(item.File.FullName))
				{
					var doc = new XmlDocument();
					doc.Load(reader);
					doc.Normalize();

					var file =
						new ResxFile
						{
							FilePath = item.File,
							Document = doc
						};

					_documentList.Add(file);
				}
			}
		}

		/// <summary>
		/// Store files to FileSystem
		/// </summary>
		private void storeFiles()
		{
			foreach (var item in _documentList)
			{
				if (item.FilePath.Exists)
				{
					if ((File.GetAttributes(item.FilePath.FullName) &
						FileAttributes.ReadOnly) != 0)
					{
						if (_gridEditableData != null && _gridEditableData.Project != null)
						{
							switch (_gridEditableData.Project.ReadOnlyFileOverwriteBehaviour)
							{
								case ReadOnlyFileOverwriteBehaviour.Overwrite:
									// Simply continue to code below.
									break;
								case ReadOnlyFileOverwriteBehaviour.Ask:
									var h = CanOverwrite;
									item.FilePath.Refresh();
									switch (h(item.FilePath))
									{
										case AskOverwriteResult.Overwrite:
											// Simply continue to code below.
											break;
										case AskOverwriteResult.Skip:
											continue;
										case AskOverwriteResult.Fail:
											throw new Exception(
												string.Format(
													Resources.SR_DataProcessing_storeFiles_Save_operation_was_cancelled_at_file,
													item.FilePath.Name));

										default:
											throw new ArgumentOutOfRangeException();
									}
									break;
								case ReadOnlyFileOverwriteBehaviour.Skip:
									continue;
								case ReadOnlyFileOverwriteBehaviour.Fail:
									throw new Exception(
										string.Format(
											Resources.SR_DataProcessing_storeFiles_Saving_failed_because_of_read_only_file,
											item.FilePath.Name));

								default:
									throw new ArgumentOutOfRangeException();
							}
						}
					}

					removeReadOnlyAttributes(item.FilePath);
					SafeFileOperations.SafeDeleteFile(item.FilePath);
				}

				var settings =
					new XmlWriterSettings
					{
						Indent = true,
						IndentChars = '\t'.ToString(),
						Encoding = Encoding.UTF8
					};

				using (var sw = new StreamWriter(
					item.FilePath.FullName,
					false,
					new UTF8Encoding(false)))
				using (var write = XmlWriter.Create(sw, settings))
				{
					if (write != null)
					{
						var doc = item.Document;
						doc.Save(write);
					}
				}
			}
		}

		public static bool ShowCommentColumn
		{
			get
			{
				var project = MainForm.Current.ProjectFilesControl.Project;
				return project != null && project.ShowCommentsColumnInGrid;
			}
		}

		// AJ CHANGE
		// Checks if the Column Comment is visible in the row
		public static bool CommentsAreVisible(DataTable table)
		{
			if (ShowCommentColumn)
			{
				var colName = table.Columns[table.Columns.Count - 1].ColumnName;

				// Sometimes the comment column gets the prefix col, depends on the visibility state
				if (colName == @"colComment" ||
					colName == @"Comment" ||
					colName == @"col" + Resources.SR_ColumnCaption_Comment ||
					colName == Resources.SR_ColumnCaption_Comment)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		}

		public static bool CommentsAreVisible(DataRow row)
		{
			return CommentsAreVisible(row.Table);
		}

		/// <summary>
		/// Create the data table for the grid
		/// </summary>
		/// <returns></returns>
		private DataTable getTable()
		{
			// Load File from filesystem
			loadFiles();

			var view = new DataTable();

			// Add Primary Key Column
			view.Columns.Add(
				new DataColumn
					{
						ColumnName = @"Name",
						Caption = Resources.SR_ColumnCaption_Name
					});
			view.PrimaryKey = new[] { view.Columns[@"Name"] };

			// AJ CHANGE

			// Add a Column for each filename
			foreach (var item in _documentList)
			{
				var cn = item.FilePath.Name;

				var culture =
					new LanguageCodeDetection(
						_gridEditableData.Project)
						.DetectCultureFromFileName(
							_gridEditableData.ParentSettings,
							cn);

				var cultureCaption =
					string.Format(
						@"{0} ({1})",
						culture.DisplayName,
						culture.Name);

				if (!containsCaption(view.Columns,cultureCaption))
				{
					var column =
						new DataColumn(cn)
							{
								Caption = cultureCaption
							};
					view.Columns.Add(column);
				}
			}

			if (ShowCommentColumn)
			{
				view.Columns.Add(
					new DataColumn
						{
							ColumnName = @"Comment",
							Caption = Resources.SR_ColumnCaption_Comment
						});
			}

			// --

			// Add rows and fill them with data
			foreach (var item in _documentList)
			{
				var cn = item.FilePath.Name;

				var culture =
					new LanguageCodeDetection(
						_gridEditableData.Project)
						.DetectCultureFromFileName(
							_gridEditableData.ParentSettings,
							cn);

				var cultureCaption =
					string.Format(
						@"{0} ({1})",
						culture.DisplayName,
						culture.Name);

				var doc = item.Document;
				var data = doc.GetElementsByTagName(@"data");

				// Each "data" node of the XML document is processed
				foreach (XmlNode node in data)
				{
					var process = true;

					//Check if this is a non string data tag
					if (node.Attributes[@"type"] != null)
					{
						process = false;
					}

					//skip mimetype like application/x-microsoft.net.object.binary.base64
					// http://www.codeproject.com/KB/aspnet/ZetaResourceEditor.aspx?msg=3367544#xx3367544xx
					if (node.Attributes[@"mimetype"] != null)
					{
						process = false;
					}

					if (process)
					{
						// Get value of the "name" attribute 
						// and look for it in the datatable
						var name = node.Attributes[@"name"].Value;
						var rows = view.Select(string.Format(
							@"Name='{0}'",
							escapeQuotes(name)));

						// Fixes the "value of second file displayed in first column" bug_.
						if (rows.Length == 0)
						{
							view.Rows.Add(name);
							rows = view.Select(string.Format(
								@"Name='{0}'",
								escapeQuotes(name)));

							// AJ CHANGE
							if (ShowCommentColumn)
							{
								var comment = node.SelectSingleNode(@"comment");
								if (comment != null)
								{
									rows[0][@"Comment"] =
										string.IsNullOrEmpty(comment.InnerText)
											? string.Empty
											: AdjustLineBreaks(comment.InnerText);
									rows[0].AcceptChanges();
								}
							}
						}

						var value = node.SelectSingleNode(@"value");

						if (value != null)
						{
							setAtCultureCaption(
								view.Columns,
								rows[0],
								cultureCaption,
								string.IsNullOrEmpty(value.InnerText)
									? string.Empty
									: AdjustLineBreaks(value.InnerText));
							rows[0].AcceptChanges();
						}
					}
				}
			}

			return view;
		}

		private static bool containsCaption(
			DataColumnCollection columns, 
			string cultureCaption)
		{
			foreach (DataColumn column in columns)
			{
				if(string.Compare(column.Caption, cultureCaption, true)==0)
				{
					return true;
				}
			}

			return false;
		}

		private static void setAtCultureCaption(
			DataColumnCollection columns,
			DataRow row, 
			string cultureCaption, 
			string text)
		{
			var index = 0;
			foreach (DataColumn dataColumn in columns)
			{
				if (index > 0)
				{
					if (string.Compare(dataColumn.Caption, cultureCaption, true) == 0)
					{
						row[dataColumn] = text;
						return;
					}
				}

				index++;
			}
		}

		private static string escapeQuotes(string name)
		{
			if (string.IsNullOrEmpty(name))
			{
				return name;
			}
			else
			{
				return name.Replace(@"'", @"''");
			}
		}

		public static string AdjustLineBreaks(string text)
		{
			if (string.IsNullOrEmpty(text))
			{
				return text;
			}
			else
			{
				// ReSharper disable LocalizableElement
				text = text.Replace("\r\n", "\n");
				text = text.Replace("\r", "\n");
				text = text.Replace("\n", Environment.NewLine);
				// ReSharper restore LocalizableElement

				return text;
			}
		}

		/// <summary>
		/// Store the changes in the data table back to the .RESX files
		/// </summary>
		/// <param name="table">The table.</param>
		/// <param name="wantBackupFiles">if set to <c>true</c> [want backup files].</param>
		/// <param name="omitEmptyStrings">if set to <c>true</c> [omit empty strings].</param>
		private void saveTable(
			DataTable table,
			bool wantBackupFiles,
			bool omitEmptyStrings)
		{
			var index = 0;
			foreach (var item in _documentList)
			{
				var document = item.Document;
				var fileName = item.FilePath.Name;

				foreach (DataRow row in table.Rows)
				{
					if (row.RowState != DataRowState.Deleted)
					{
						var tagName = (string)row[@"Name"];

						var xpathQuery =
							string.Format(
								@"child::data[attribute::name='{0}']",
								escapeXsltChars(tagName));

						if (document.DocumentElement != null)
						{
							var node = document.DocumentElement.SelectSingleNode(xpathQuery);
							var found = node != null;

							var textToSet =
								row[fileName] == DBNull.Value
									? string.Empty
									: (string)row[fileName];

							// AJ CHANGE
							var commentToSet =
								CommentsAreVisible(row)
									? row[@"Comment"] == DBNull.Value
										? string.Empty
										: (string)row[@"Comment"]
									: null;

							if (found)
							{
								var n = node.SelectSingleNode(@"value");

								if (!string.IsNullOrEmpty(textToSet) ||
									 !omitEmptyStrings)
								{
									// If not present (for whatever reason, e.g. 
									// manually edited and therefore misformed).
									if (n == null)
									{
										n = document.CreateElement(@"value");
										node.AppendChild(n);
									}

									n.InnerText = textToSet;

									// AJ CHANGE
									// Only write the comment to the main resx file
									if (CommentsAreVisible(row))
									{
										if (item == _documentList[0])
										{
											n = node.SelectSingleNode(@"comment");
											// If not present (for whatever reason, e.g. 
											// manually edited and therefore misformed).
											if (n == null)
											{
												n = document.CreateElement(@"comment");
												node.AppendChild(n);
											}

											n.InnerText = commentToSet;
										}
									}
								}
								else
								{
									if (n != null)
									{
										node.RemoveChild(n);
									}

									node.ParentNode.RemoveChild(node);
								}
							}
							else
							{
								if (!string.IsNullOrEmpty(textToSet) || !omitEmptyStrings)
								{
									//Create the new Node
									XmlNode newData = document.CreateElement(@"data");
									var newName = document.CreateAttribute(@"name");
									var newSpace = document.CreateAttribute(@"xml:space");
									XmlNode newValue = document.CreateElement(@"value");

									// Set the Values
									newName.Value = (string)row[@"Name"];
									newSpace.Value = @"preserve";
									newValue.InnerText = textToSet;

									// Get them together
									newData.Attributes.Append(newName);
									newData.Attributes.Append(newSpace);
									newData.AppendChild(newValue);

									// AJ CHANGE
									// Only write the comment to the main resx file
									if (CommentsAreVisible(row) && index == 0)
									{
										XmlNode newComment = document.CreateElement(@"comment");
										newComment.InnerText = commentToSet;
										newData.AppendChild(newComment);
									}

									XmlNode root = document.DocumentElement;
									if (root != null)
									{
										root.InsertAfter(newData, root.LastChild);
									}
								}
							}
						}
					}
				}

				index++;
			}

			if (wantBackupFiles)
			{
				backupFiles();
			}

			// Store files back to filesystem
			storeFiles();
		}

		/// <summary>
		/// Escapes the XSLT chars.
		/// </summary>
		/// <param name="query">The query.</param>
		/// <returns></returns>
		private static string escapeXsltChars(
			string query)
		{
			if (string.IsNullOrEmpty(query))
			{
				return query;
			}
			else
			{
				return query.
				   Replace(@"'", @"&acute;").
				   Replace(@"""", @"&quot;");
			}
		}

		/// <summary>
		/// Create backup
		/// </summary>
		private void backupFiles()
		{
			foreach (var item in _documentList)
			{
				var bak = item.FilePath;

				// Delete old bak files
				if (File.Exists(bak.FullName + @".bak"))
				{
					// Remove ReadOnly-attribute.
					removeReadOnlyAttributes(
						new FileInfo(bak.FullName + @".bak"));
					SafeFileOperations.SafeDeleteFile(bak + @".bak");
				}

				item.FilePath.CopyTo(bak.FullName + @".bak");
			}
		}

		/// <summary>
		/// Removes the read only attributes.
		/// </summary>
		/// <param name="path">The path.</param>
		private static void removeReadOnlyAttributes(
			FileSystemInfo path)
		{
			File.SetAttributes(
				path.FullName,
				path.Attributes & ~FileAttributes.ReadOnly);
		}

		/// <summary>
		/// Renames the specified old name.
		/// </summary>
		/// <param name="oldName">The old name.</param>
		/// <param name="newName">The new name.</param>
		private void rename(
			string oldName,
			string newName)
		{
			foreach (var item in _documentList)
			{
				var tmp = item.Document;

				var xpathQuery = string.Format(
					@"child::data[attribute::name='{0}']",
					escapeXsltChars(oldName));

				if (tmp.DocumentElement != null)
				{
					var target =
						tmp.DocumentElement.SelectSingleNode(
							xpathQuery);

					// Can be NULL if not yet written.
					// http://www.codeproject.com/Messages/3107527/Re-more-bugs.aspx
					if (target != null)
					{
						target.Attributes[@"name"].Value = newName;
					}
				}
			}
		}

		/// <summary>
		/// Adds the specified tag.
		/// </summary>
		/// <param name="tag">The tag.</param>
		private void add(
			string tag)
		{
			foreach (var item in _documentList)
			{
				var tmp = item.Document;

				XmlNode newData = tmp.CreateElement(@"data");
				var newName = tmp.CreateAttribute(@"name");
				var newSpace = tmp.CreateAttribute(@"xml:space");
				XmlNode newValue = tmp.CreateElement(@"value");

				// Set the Values
				newName.Value = tag;
				newSpace.Value = @"preserve";
				newValue.InnerText = string.Empty;

				// Get them together
				newData.Attributes.Append(newName);
				newData.Attributes.Append(newSpace);
				newData.AppendChild(newValue);

				XmlNode root = tmp.DocumentElement;

				if (root != null)
				{
					root.InsertAfter(
						newData,
						root.LastChild);
				}
			}
		}

		/// <summary>
		/// Deletes the specified tag.
		/// </summary>
		/// <param name="tag">The tag.</param>
		private void delete(
			string tag)
		{
			foreach (var item in _documentList)
			{
				var tmp = item.Document;

				var xpathQuery =
					string.Format(
					@"child::data[attribute::name='{0}']",
					escapeXsltChars(tag));

				if (tmp.DocumentElement != null)
				{
					var target = tmp.DocumentElement.SelectSingleNode(
						xpathQuery);

					if (target != null)
					{
						tmp.DocumentElement.RemoveChild(target);
					}
				}
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Public methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// Initializes a new instance of the <see cref="DataProcessing"/> class.
		/// </summary>
		/// <param name="gridEditableData">The file group.</param>
		public DataProcessing(
			IGridEditableData gridEditableData)
		{
			_gridEditableData = gridEditableData;
		}

		/// <summary>
		/// Creates the data source for the grid as "<see cref="DataTable"/>".
		/// </summary>
		/// <returns></returns>
		public DataTable GetDataTableFromResxFiles()
		{
			return getTable();
		}

		/// <summary>
		/// Stores the changes made in the grid back to the .RESX files
		/// </summary>
		/// <param name="table">The table.</param>
		/// <param name="project">The project.</param>
		public void SaveDataTableToResxFiles(
			DataTable table,
			Project project)
		{
			var createBackups = project != null && project.CreateBackupFiles;
			var omitEmptyStrings = project != null && project.OmitEmptyItems;

			SaveDataTableToResxFiles(table, createBackups, omitEmptyStrings);
		}

		/// <summary>
		/// Stores the changes made in the grid back to the .RESX files
		/// </summary>
		/// <param name="table">The table.</param>
		/// <param name="backupFiles">if set to <c>true</c> [backup files].</param>
		/// <param name="omitEmptyStrings">if set to <c>true</c> [omit empty strings].</param>
		public void SaveDataTableToResxFiles(
			DataTable table,
			bool backupFiles,
			bool omitEmptyStrings)
		{
			saveTable(table, backupFiles, omitEmptyStrings);
		}

		/// <summary>
		/// Rename existing tag
		/// </summary>
		/// <param name="oldName"></param>
		/// <param name="newName"></param>
		public void RenameTag(
			string oldName,
			string newName)
		{
			rename(oldName, newName);
		}

		/// <summary>
		/// Delete existing tag
		/// </summary>
		/// <param name="tag"></param>
		public void DeleteTag(
			string tag)
		{
			delete(tag);
		}

		/// <summary>
		/// Add new tag
		/// </summary>
		/// <param name="tag"></param>
		public void AddTag(
			string tag)
		{
			add(tag);
		}

		// ------------------------------------------------------------------
		#endregion

		#region Internal helper class.
		// ------------------------------------------------------------------

		/// <summary>
		/// Helper class for one .RESX file.
		/// </summary>
		[DebuggerDisplay(@"{FilePath.Name}")]
		private class ResxFile
		{
			/// <summary>
			/// XML content
			/// </summary>
			public XmlDocument Document
			{
				get;
				set;
			}

			/// <summary>
			/// Full path file name.
			/// </summary>
			public FileInfo FilePath
			{
				get;
				set;
			}
		}

		// ------------------------------------------------------------------
		#endregion
	}

	/////////////////////////////////////////////////////////////////////////
}