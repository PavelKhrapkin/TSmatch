namespace ZetaResourceEditor.UI.Main.LeftTree
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System;
	using System.Collections.Generic;
	using System.ComponentModel;
	using System.Drawing;
	using System.IO;
	using System.Text.RegularExpressions;
	using System.Windows.Forms;
	using System.Xml;
	using Code.AppHost;
	using Code.DL;
	using DevExpress.Utils;
	using DevExpress.XtraBars;
	using DevExpress.XtraEditors;
	using DevExpress.XtraTreeList;
	using DevExpress.XtraTreeList.Nodes;
	using DevExpress.XtraTreeList.ViewInfo;
	using FileGroups;
	using Helper;
	using Helper.Base;
	using Helper.Progress;
	using Projects;
	using Properties;
	using Zeta.EnterpriseLibrary.Common;
	using Zeta.EnterpriseLibrary.Common.IO;
	using Zeta.EnterpriseLibrary.Logging;
	using Zeta.EnterpriseLibrary.Windows.Common;
	using Zeta.EnterpriseLibrary.Windows.Controls;
	using Zeta.EnterpriseLibrary.Windows.Dialogs;

	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	public partial class ProjectFilesUserControl :
		UserControlBase
	{
		private Project _project;

		public ProjectFilesUserControl()
		{
			InitializeComponent();
		}

		private static void updateNodeInfo(
			TreeListNode node)
		{
			if (node != null && node.TreeList != null && node.Tag != null)
			{
				LogCentral.Current.LogInfo(
					string.Format(
					@"Updating node info of node '{0}'.",
					node[0]));

				updateNodeStateImage(node);
			}
		}

		public static bool CanOpenProjectFile
		{
			get
			{
				return true;
			}
		}

		public bool CanSaveProjectFile
		{
			get
			{
				return _project != null;
			}
		}

		public bool CanCloseProjectFile
		{
			get
			{
				return _project != null;
			}
		}

		/*
				public bool CanAddResourceFiles
				{
					get
					{
						return _project != null;
					}
				}
		*/

		/*
				public bool CanRemoveResourceFiles
				{
					get
					{
						return _project != null &&
		 *					treeView.Selection.Count>0 &&
							treeView.SelectedNode != null &&
								treeView.SelectedNode.Tag is FileGroup;
					}
				}
		*/

		public bool CanEditFileGroupSettings
		{
			get
			{
				return _project != null &&
					treeView.SelectedNode != null &&
						treeView.SelectedNode.Tag is FileGroup;
			}
		}

		public bool CanEditProjectFolderSettings
		{
			get
			{
				return _project != null &&
					treeView.SelectedNode != null &&
						treeView.SelectedNode.Tag is ProjectFolder;
			}
		}

		/// <summary>
		/// Adds the resource files with dialog.
		/// </summary>
		public void AddResourceFilesWithDialog()
		{
			using (var ofd = new OpenFileDialog())
			{
				ofd.Multiselect = true;
				ofd.Filter = string.Format(@"{0} (*.resx)|*.resx",
					Resources.SR_MainForm_openToolStripMenuItemClick_ResourceFiles);
				ofd.RestoreDirectory = true;

				var initialDir =
					ConvertHelper.ToString(
						FormHelper.RestoreValue(
							MainForm.UserStorageIntelligent,
							@"filesInitialDir"));
				ofd.InitialDirectory = initialDir;

				if (ofd.ShowDialog(this) == DialogResult.OK)
				{
					FormHelper.SaveValue(
						MainForm.UserStorageIntelligent,
						@"filesInitialDir",
						Path.GetDirectoryName(ofd.FileName));

					// --

					var fileGroup = new FileGroup(_project);

					foreach (var filePath in ofd.FileNames)
					{
						fileGroup.Add(new FileFileInfo(fileGroup)
						{
							File = new FileInfo(filePath)
						});
					}

					// Look for same entries.
					if (_project.FileGroups.HasFileGroupWithChecksum(
						fileGroup.GetChecksum(_project)))
					{
						throw new MessageBoxException(
							this,
							Resources.SR_ProjectFilesUserControl_AddResourceFilesWithDialog_ExistsInTheProject,
							MessageBoxIcon.Information);
					}
					else
					{
						var parentProjectFolder =
							treeView.SelectedNode.Tag as ProjectFolder;

						if (parentProjectFolder != null)
						{
							fileGroup.ProjectFolder = parentProjectFolder;
						}

						_project.FileGroups.Add(fileGroup);
						_project.MarkAsModified();

						var node = addFileGroupToTree(treeView.SelectedNode, fileGroup);

						// --

						sortTree();

						treeView.SelectedNode = node;

						// Immediately open for editing.
						editResourceFiles();

						UpdateUI();
					}
				}
			}
		}

		/// <summary>
		/// Automatically adds multiple resource files with dialog.
		/// </summary>
		public void AutomaticallyAddAddResourceFilesWithDialog()
		{
			using (var dialog = new ExtendedFolderBrowserDialog())
			{
				dialog.Description =
					Resources.SR_ProjectFilesUserControl_AutomaticallyAddAddResourceFilesWithDialog_AddedAutomatically;

				var initialDir =
					ConvertHelper.ToString(
						FormHelper.RestoreValue(
						MainForm.UserStorageIntelligent,
						@"filesInitialDir"));

				if (string.IsNullOrEmpty(initialDir) || !Directory.Exists(initialDir))
				{
					var d = _project.ProjectConfigurationFilePath.Directory;
					if (d != null)
					{
						initialDir = d.FullName;
					}
				}

				dialog.SelectedPath = initialDir;
				dialog.ShowEditBox = true;

				if (dialog.ShowDialog(this) == DialogResult.OK)
				{
					FormHelper.SaveValue(
						MainForm.UserStorageIntelligent,
						@"filesInitialDir",
						dialog.SelectedPath);

					var folderPath =
						dialog.SelectedPath == null
							? null
							: new DirectoryInfo(dialog.SelectedPath);

					var parentProjectFolder =
						treeView.SelectedNode.Tag as ProjectFolder;

					// --

					var fileGroupCount = 0;
					var fileCount = 0;

					var enabled = guiRefreshTimer.Enabled;
					guiRefreshTimer.Enabled = false;

					using (new BackgroundWorkerLongProgressGui(
						delegate(object sender, DoWorkEventArgs args)
						{
							try
							{
								doAutomaticallyAddResourceFiles(
									(BackgroundWorker)sender,
									parentProjectFolder,
									ref fileGroupCount,
									ref fileCount,
									folderPath);
							}
							catch (CancelOperationException)
							{
								// Ignore.
							}
						},
						Resources.SR_ProjectFilesUserControl_AutomaticallyAddAddResourceFilesWithDialog_WillBeAdded,
						BackgroundWorkerLongProgressGui.CancellationMode.Cancelable,
						this))
					{
					}

					guiRefreshTimer.Enabled = enabled;

					if (fileGroupCount <= 0)
					{
						XtraMessageBox.Show(
							this,
							Resources.SR_ProjectFilesUserControl_AutomaticallyAddAddResourceFilesWithDialog_WereAdded,
							@"Zeta Resource Editor",
							MessageBoxButtons.OK,
							MessageBoxIcon.Warning);

						UpdateUI();
					}
					else
					{
						XtraMessageBox.Show(
							this,
							string.Format(
								Resources.SR_ProjectFilesUserControl_AutomaticallyAddAddResourceFilesWithDialog_OfFilesWereAdded,
								fileGroupCount,
								fileCount),
							@"Zeta Resource Editor",
							MessageBoxButtons.OK,
							MessageBoxIcon.Information);

						// Reload from in-memory project.
						fillFromProject();
						new TreeListViewState(treeView).RestoreState(@"projectsTree");

						_project.MarkAsModified();

						sortTree();
						UpdateUI();
					}
				}
			}
		}

		/*
		/// <summary>
		/// Does the automatically add resource files.
		/// </summary>
		/// <param name="backgroundWorker">The background worker.</param>
		/// <param name="parentProjectFolder">The parent project folder.</param>
		/// <param name="fileGroupCount">The file group count.</param>
		/// <param name="fileCount">The file count.</param>
		/// <param name="folderPath">The folder path.</param>
		private void doAutomaticallyAddResourceFiles(
			BackgroundWorker backgroundWorker,
			ProjectFolder parentProjectFolder,
			ref int fileGroupCount,
			ref int fileCount,
			DirectoryInfo folderPath)
		{
			if (backgroundWorker.CancellationPending)
			{
				throw new CancelOperationException();
			}

			// Omit hidden or system folders.
			if ((folderPath.Attributes & FileAttributes.Hidden) == 0 &&
				(folderPath.Attributes & FileAttributes.System) == 0)
			{
				var filePaths = folderPath.GetFiles(@"*.resx");

				if (filePaths.Length > 0)
				{
					FileGroup fileGroup = null;
					string previousBaseFileName = null;

					foreach (var filePath in filePaths)
					{
						if (backgroundWorker.CancellationPending)
						{
							throw new CancelOperationException();
						}

						var baseFileName =
							filePath.Name.Substring(0, filePath.Name.IndexOf('.'));

						var wantAddResourceFile =
							checkWantAddResourceFile(filePath);

						if (wantAddResourceFile)
						{
							if (fileGroup == null ||
								previousBaseFileName == null ||
								string.Compare(baseFileName, previousBaseFileName, true) != 0)
							{
								if (fileGroup != null && fileGroup.Count > 0)
								{
									// Look for same entries.
									if (!_project.FileGroups.HasFileGroupWithChecksum(
											fileGroup.GetChecksum(_project)))
									{
										_project.FileGroups.Add(fileGroup);

										fileGroupCount++;
										fileCount += fileGroup.Count;
									}
								}

								fileGroup =
									new FileGroup(_project)
									{
										ProjectFolder = parentProjectFolder
									};
							}

							fileGroup.Add(
								new FileFileInfo(fileGroup)
									{
										File = filePath
									});

							previousBaseFileName = baseFileName;
						}
					}

					// Add remaining.
					if (fileGroup != null && fileGroup.Count > 0)
					{
						// Look for same entries.
						if (!_project.FileGroups.HasFileGroupWithChecksum(
								fileGroup.GetChecksum(_project)))
						{
							_project.FileGroups.Add(fileGroup);

							fileGroupCount++;
							fileCount += fileGroup.Count;
						}
					}
				}
			}

			// Recurse childs.
			foreach (var childFolderPath in folderPath.GetDirectories())
			{
				doAutomaticallyAddResourceFiles(
					backgroundWorker,
					parentProjectFolder,
					ref fileGroupCount,
					ref fileCount,
					childFolderPath);
			}
		}
		*/

		private void doAutomaticallyAddResourceFiles(
			BackgroundWorker backgroundWorker,
			ProjectFolder parentProjectFolder,
			ref int fileGroupCount,
			ref int fileCount,
			DirectoryInfo folderPath)
		{
			if (backgroundWorker.CancellationPending)
			{
				throw new CancelOperationException();
			}

			// Omit hidden or system folders.
			if ((folderPath.Attributes & FileAttributes.Hidden) == 0 &&
				(folderPath.Attributes & FileAttributes.System) == 0)
			{
				//CHANGED use comon method to look load new files:

				var filePaths = new List<FileInfo>(folderPath.GetFiles(@"*.resx"));
				doAutomaticallyAddResourceFilesFromList(
					backgroundWorker,
					parentProjectFolder,
					ref fileGroupCount,
					ref fileCount,
					filePaths);
			}

			// Recurse childs.
			foreach (var childFolderPath in folderPath.GetDirectories())
			{
				doAutomaticallyAddResourceFiles(
					backgroundWorker,
					parentProjectFolder,
					ref fileGroupCount,
					ref fileCount,
					childFolderPath);
			}
		}

		//ADDED. TO DO: Add a Button and call this method. You can change 
		// dialog form to something else to accord common ui
		public void AutomaticallyAddResourceFilesFromSolutionWithDialog()
		{
			using (var dialog = new OpenFileDialog())
			{
				dialog.Title = Resources.SR_VSDialogTitle;

				var initialDir =
					ConvertHelper.ToString(
						FormHelper.RestoreValue(
						MainForm.UserStorageIntelligent,
						@"filesInitialDir"));

				if (string.IsNullOrEmpty(initialDir) ||
					!Directory.Exists(initialDir))
				{
					var d = _project.ProjectConfigurationFilePath.Directory;
					if (d != null)
					{
						initialDir = d.FullName;
					}
				}

				dialog.InitialDirectory = initialDir;
				dialog.Filter =
					string.Format(
						@"{0}|*.csproj;*.sln",
						Resources.SR_SlnNames);

				if (dialog.ShowDialog(this) == DialogResult.OK)
				{
					var proj = new FileInfo(dialog.FileName);

					var parentProjectFolder =
						treeView.SelectedNode.Tag as ProjectFolder;

					// --

					var fileGroupCount = 0;
					var fileCount = 0;

					var enabled = guiRefreshTimer.Enabled;
					guiRefreshTimer.Enabled = false;

					using (new BackgroundWorkerLongProgressGui(
						delegate(object sender, DoWorkEventArgs args)
						{
							try
							{
								doAutomaticallyAddResourceFilesFromVsProject(
									(BackgroundWorker)sender,
									parentProjectFolder,
									ref fileGroupCount,
									ref fileCount,
									proj);
							}
							catch (CancelOperationException)
							{
								// Ignore.
							}
						},
						Resources.SR_ProjectFilesUserControl_AutomaticallyAddAddResourceFilesWithDialog_WillBeAdded,
						BackgroundWorkerLongProgressGui.CancellationMode.Cancelable,
						this))
					{
					}

					guiRefreshTimer.Enabled = enabled;

					if (fileGroupCount <= 0)
					{
						XtraMessageBox.Show(
							this,
							Resources.SR_ProjectFilesUserControl_AutomaticallyAddAddResourceFilesWithDialog_WereAdded,
							@"Zeta Resource Editor",
							MessageBoxButtons.OK,
							MessageBoxIcon.Warning);

						UpdateUI();
					}
					else
					{
						XtraMessageBox.Show(
							this,
							string.Format(
								Resources.SR_ProjectFilesUserControl_AutomaticallyAddAddResourceFilesWithDialog_OfFilesWereAdded,
								fileGroupCount,
								fileCount),
							@"Zeta Resource Editor",
							MessageBoxButtons.OK,
							MessageBoxIcon.Information);

						// Reload from in-memory project.
						fillFromProject();
						new TreeListViewState(treeView).RestoreState(@"projectsTree");

						_project.MarkAsModified();

						sortTree();
						UpdateUI();

						var node = treeView.SelectedNode;
						if (node != null)
						{
							node.Expanded = true;
						}
					}
				}
			}
		}

		//ADDED: add resx files from solution
		private void doAutomaticallyAddResourceFilesFromVSSolution(
			BackgroundWorker backgroundWorker,
			ProjectFolder parentProjectFolder,
			ref int fileGroupCount,
			ref int fileCount,
			FileInfo vsSolutionPath)
		{
			if (vsSolutionPath != null && vsSolutionPath.Exists)
			{
				string solutionText;
				using (var sr = vsSolutionPath.OpenText())
				{
					//we can read it line by line to reduce memory usage, but solution files are not very big
					solutionText = sr.ReadToEnd();
				}
				//solution files looks like:
				//Project("{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}") = "ZetaResourceEditor", "Main\ZetaResourceEditor.csproj", "{367758E7-0435-440A-AC76-1F30ABBA3ED8}"
				//EndProject
				//known projectTypes:
				//c#: FAE04EC0-301F-11D3-BF4B-00C04F79EFBC, VB: F184B08F-C81C-45F6-A57F-5ABD9991F28F
				//@see http://msdn.microsoft.com/en-us/library/hb23x61k%28VS.80%29.aspx
				//TODO: support virtual folders
				var supportedProjectTypes =
					new[]
						{
							@"FAE04EC0-301F-11D3-BF4B-00C04F79EFBC",
							@"F184B08F-C81C-45F6-A57F-5ABD9991F28F"
						};

				//we need some regular expression to find required info:
				const string pattern =
					@"Project\(""{(?<projectType>[^}]*)}""\)\s*=\s*""(?<projectName>[^""]*)"",\s*""(?<projectRelPath>[^""]*)"",\s*""{(?<projectID>[^}]*)}""";

				foreach (Match m in Regex.Matches(solutionText, pattern))
				{
					if (!m.Success)
					{
						continue;
					}

					var g = m.Groups[@"projectType"];
					if (g == null || !g.Success)
					{
						continue;
					}
					var projectType = g.Value;

					//compare with known project types. 
					// Currently only CS Projects are supported. 
					// But other types like VB can be simply added.
					if (!Array.Exists(supportedProjectTypes, a => a == projectType))
					{
						continue;
					}

					var projectRelPath = m.Groups[@"projectRelPath"].Value;
					var projectFile = new FileInfo(Path.Combine(vsSolutionPath.Directory.FullName, projectRelPath));

					//add all files from project
					//we can add each using separate sub folder
					var projectName = m.Groups[@"projectName"].Value;
					//look in subfolders only 
					var subFolders = _project.ProjectFolders;
					if (parentProjectFolder != null)
					{
						subFolders = parentProjectFolder.ChildProjectFolders;
					}
					var pf = subFolders.Find(f => f.Name == projectName);
					if (pf == null)
					{
						pf =
							new ProjectFolder(_project)
								{
									Name = projectName,
									Parent = parentProjectFolder
								};
						_project.ProjectFolders.Add(pf);
					}

					_project.MarkAsModified();

					doAutomaticallyAddResourceFilesFromVsProject(
						backgroundWorker,
						pf,
						ref fileGroupCount,
						ref fileCount,
						projectFile);
				}
			}
		}

		//ADDED: add from project or solution
		private void doAutomaticallyAddResourceFilesFromVsProject(
			BackgroundWorker backgroundWorker,
			ProjectFolder parentProjectFolder,
			ref int fileGroupCount,
			ref int fileCount,
			FileInfo vsProjectPath)
		{
			if (backgroundWorker.CancellationPending)
			{
				throw new CancelOperationException();
			}
			else if (vsProjectPath != null && vsProjectPath.Exists)
			{
				if (@".sln" == vsProjectPath.Extension.ToLowerInvariant())
				{
					//file is solution, so add all projects from solution
					doAutomaticallyAddResourceFilesFromVSSolution(
						backgroundWorker,
						parentProjectFolder,
						ref fileGroupCount,
						ref fileCount,
						vsProjectPath);
				}
				else
				{
					//load fom solution
					var pdoc = new XmlDocument();
					using (var fs = vsProjectPath.OpenRead())
					{
						pdoc.Load(fs);
					}

					var nameMgr = new XmlNamespaceManager(pdoc.NameTable);
					nameMgr.AddNamespace(@"mb", @"http://schemas.microsoft.com/developer/msbuild/2003");
					const string xpath = @"/mb:Project/mb:ItemGroup/mb:EmbeddedResource/@Include";
					var resNodes = pdoc.SelectNodes(xpath, nameMgr);

					var filePaths = new List<FileInfo>(); //get all files
					if (resNodes != null)
					{
						foreach (XmlNode node in resNodes)
						{
							var include = node.Value;

							if (!string.IsNullOrEmpty(include) &&
								include.ToLowerInvariant().EndsWith(@".resx"))
							{
								var fullPath = Path.Combine(vsProjectPath.DirectoryName, include);
								filePaths.Add(new FileInfo(fullPath));
							}
						}
					}

					//add all files from list
					doAutomaticallyAddResourceFilesFromList(
						backgroundWorker,
						parentProjectFolder,
						ref fileGroupCount,
						ref fileCount,
						filePaths);
				}
			}
		}

		// ADDED: adds resources from file Info lists.
		// I have changed a method doAutomaticallyAddResourceFiles to fill file groups. 
		// You can use same method if you call this method from there. 
		// ATTENTION: LanguageCodeDetection was modified a bit to support variable amount 
		// of point in base name. New method GetBaseName(IInheritedSettings settings, string fileName) 
		// was added to get same base name FileGroup gets.
		private void doAutomaticallyAddResourceFilesFromList(
			BackgroundWorker backgroundWorker,
			ProjectFolder parentProjectFolder,
			ref int fileGroupCount,
			ref int fileCount,
			ICollection<FileInfo> fileList)
		{
			if (backgroundWorker.CancellationPending)
			{
				throw new CancelOperationException();
			}
			else if (fileList != null && fileList.Count > 0)
			{
				var lcd = new Code.Helper.LanguageCodeDetection(Project);

				FileGroup fileGroup;
				var fileGroups = _project.FileGroups;
				//if (parentProjectFolder != null)
				//{
				//    fileGroups = parentProjectFolder.ChildFileGroups;
				//}
				foreach (var filePath in fileList)
				{
					if (backgroundWorker.CancellationPending)
					{
						throw new CancelOperationException();
					}
					//other algorithm to determine base name to allow multiple points inside name
					var baseFileName = lcd.GetBaseName(_project, filePath.Name);

					var wantAddResourceFile =
						checkWantAddResourceFile(filePath);

					if (wantAddResourceFile)
					{
						//find right file group

						var path = filePath;
						fileGroup =
							fileGroups.Find(
								g =>
								string.Compare(g.BaseName, baseFileName, true) == 0 &&
								path.Directory != null &&
								string.Compare(g.FolderPath.FullName, path.Directory.FullName, true) == 0);

						if (fileGroup == null)
						{
							fileGroup =
								new FileGroup(_project)
									{
										ProjectFolder = parentProjectFolder
									};

							// Look for same entries.
							if (!_project.FileGroups.HasFileGroupWithChecksum(
								fileGroup.GetChecksum(_project)))
							{
								fileGroups.Add(fileGroup);

								fileGroupCount++;
							}
						}

						fileGroup.Add(
							new FileFileInfo(fileGroup)
								{
									File = filePath
								});

						fileCount++;
					}
				}
			}
		}

		private bool checkWantAddResourceFile(
			FileInfo filePath)
		{
			if (filePath == null || filePath.Directory == null)
			{
				return false;
			}
			else
			{
				if (string.Compare(@"Properties", filePath.Directory.Name, true) == 0)
				{
					return true;
				}
				else
				{
					// If a "*.Designer.*" companion file exists, assume it 
					// is a Windows Forms resource file and do NOT add the file
					// since it can be translated directly from within VS.NET.

					if (_project.IgnoreWindowsFormsResourcesWithDesignerFiles)
					{
						var baseFileName =
							filePath.Name.Substring(0, filePath.Name.IndexOf('.'));

						var files =
							filePath.Directory.GetFiles(
								string.Format(@"{0}.Designer.*", baseFileName));

						return files.Length <= 0;
					}
					else
					{
						return true;
					}
				}
			}
		}

		/// <summary>
		/// Removes the resource files with dialog.
		/// </summary>
		public void RemoveResourceFilesWithDialog()
		{
			var dr = XtraMessageBox.Show(
				this,
				Resources.SR_ProjectFilesUserControl_RemoveResourceFilesWithDialog_FromTheProject,
				@"Zeta Resource Editor",
				MessageBoxButtons.YesNo,
				MessageBoxIcon.Question,
				MessageBoxDefaultButton.Button2);

			if (dr == DialogResult.Yes)
			{
				var node = treeView.SelectedNode;

				while (node != null && !(node.Tag is FileGroup))
				{
					node = node.ParentNode;
				}

				if (node != null && node.Tag is FileGroup)
				{
					_project.FileGroups.Remove((FileGroup)node.Tag);
					_project.MarkAsModified();

					node.ParentNode.Nodes.Remove(node);
				}
			}
		}

		/// <summary>
		/// Edits the resource files.
		/// </summary>
		private void editResourceFiles()
		{
			MainForm.Current.GroupFilesControl.EditResourceFiles(
				(IGridEditableData)treeView.SelectedNode.Tag);
		}

		/// <summary>
		/// Gets the project.
		/// </summary>
		/// <value>The project.</value>
		internal Project Project
		{
			get
			{
				return _project;
			}
		}

		public bool CanAddResourceFilesToProject
		{
			get
			{
				return
					_project != null &&
					treeView.SelectedNode != null &&
					(
						treeView.SelectedNode.Tag is Project ||
						treeView.SelectedNode.Tag is ProjectFolder
					);
			}
		}

		public bool CanRemoveResourceFilesFromProject
		{
			get
			{
				return
					_project != null &&
					treeView.SelectedNode != null &&
					treeView.SelectedNode.Tag is FileGroup;
			}
		}

		public bool CanRemoveProjectFolder
		{
			get
			{
				return
					_project != null &&
					treeView.SelectedNode != null &&
						treeView.SelectedNode != null &&
							treeView.SelectedNode.Tag is ProjectFolder;
			}
		}

		public bool CanEditProjectSettings
		{
			get
			{
				return _project != null;
			}
		}

		public bool CanRefresh
		{
			get
			{
				return _project != null;
			}
		}

		public static bool CanCreateNewProject
		{
			get
			{
				return true;
			}
		}

		/// <summary>
		/// Gets a value indicating whether this instance can edit resource files.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if this instance can edit resource files; otherwise, <c>false</c>.
		/// </value>
		private bool CanEditResourceFiles
		{
			get
			{
				return
					_project != null &&
					treeView.SelectedNode != null &&
						treeView.SelectedNode != null &&
							treeView.SelectedNode.Tag is IGridEditableData;
			}
		}

		public bool CanAddFilesToFileGroup
		{
			get
			{
				return
					_project != null &&
					treeView.SelectedNode != null &&
						treeView.SelectedNode != null &&
							treeView.SelectedNode.Tag is FileGroup;
			}
		}

		public bool CanCreateNewFile
		{
			get
			{
				if (_project != null &&
					treeView.SelectedNode != null &&
						treeView.SelectedNode != null &&
							treeView.SelectedNode.Tag is FileGroup)
				{
					// To add a new one, we must clone an existing one.
					var fg = (FileGroup)treeView.SelectedNode.Tag;
					return fg.FilePaths.Length > 0;
				}
				else
				{
					return false;
				}
			}
		}

		public bool CanCreateNewFiles
		{
			get
			{
				return
					_project != null &&
					treeView.SelectedNode != null &&
					(
						treeView.SelectedNode.Tag is Project ||
						treeView.SelectedNode.Tag is ProjectFolder
					);
			}
		}

		public bool CanAddProjectFolder
		{
			get
			{
				return
					_project != null &&
					treeView.SelectedNode != null &&
					(
						treeView.SelectedNode.Tag is Project ||
						treeView.SelectedNode.Tag is ProjectFolder
					);
			}
		}

		public bool CanMoveUp
		{
			get
			{
				return
					_project != null &&
					treeView.SelectedNode != null &&
					treeView.SelectedNode.ParentNode != null &&
					treeView.SelectedNode.ParentNode.Nodes.Count > 1 &&
					(
						treeView.SelectedNode.Tag is IOrderPosition
					);
			}
		}

		public bool CanMoveDown
		{
			get
			{
				return
					_project != null &&
					treeView.SelectedNode != null &&
					treeView.SelectedNode.ParentNode != null &&
					treeView.SelectedNode.ParentNode.Nodes.Count > 1 &&
					(
						treeView.SelectedNode.Tag is IOrderPosition
					);
			}
		}

		public bool CanRemoveFileFromFileGroup
		{
			get
			{
				return
					_project != null &&
						treeView.SelectedNode != null &&
							treeView.SelectedNode.Tag is FileFileInfo;
			}
		}

		internal void DoLoadProject(
			FileInfo projectFilePath)
		{
			var r = DoSaveFile(
				SaveOptions.OnlyIfModified | SaveOptions.AskConfirm);

			if (r == DialogResult.OK)
			{
				doLoadProjectFile(projectFilePath);

				addToMru(projectFilePath);
			}
		}

		/// <summary>
		/// Adds to MRU.
		/// </summary>
		private void addToMru()
		{
			if (_project != null)
			{
				addToMru(_project.ProjectConfigurationFilePath);
			}
		}

		/// <summary>
		/// Adds to MRU.
		/// </summary>
		/// <param name="projectFilePath">The project file path.</param>
		private static void addToMru(
			FileSystemInfo projectFilePath)
		{
			MainForm.AddMruProject(
				projectFilePath.FullName);
		}

		private void doLoadProjectFile(
			FileInfo projectFilePath)
		{
			closeProject();

			var project = new Project();
			project.Load(projectFilePath);

			// Only assign if successfully loaded.
			_project = project;
			_project.ModifyStateChanged += project_ModifyStateChanged;

			fillFromProject();
			new TreeListViewState(treeView).RestoreState(@"projectsTree");

			// Instruct right pane to load the recent files.
			MainForm.Current.GroupFilesControl.LoadRecentFiles(project);
		}

		private void closeProject()
		{
			// Store the dynamic user settings separately.
			if (_project != null &&
				!_project.IsModified &&
				_project.DynamicSettingsUser.IsModified)
			{
				_project.Store();
			}

			_project = null;
			treeView.Nodes.Clear();

			MainForm.Current.Text = @"Zeta Resource Editor";
		}

		/// <summary>
		/// Fills from project.
		/// </summary>
		private void fillFromProject()
		{
			treeView.Nodes.Clear();

			if (_project == null)
			{
				closeProject();
			}
			else
			{
				MainForm.Current.Text = string.Format(
					@"{0} - Zeta Resource Editor",
					_project.Name);

				var rootNode =
					treeView.AppendNode(
						new object[]
							{
								null,
							},
						null);

				rootNode[0] = _project.Name;
				rootNode.ImageIndex = rootNode.SelectImageIndex = getImageIndex(@"root");
				rootNode.Tag = _project;
				rootNode.StateImageIndex = (int)_project.TranslationStateColor;

				// --

				foreach (var fileGroup in _project.GetRootProjectFolders())
				{
					addProjectFolderToTree(rootNode, fileGroup);
				}

				foreach (var fileGroup in _project.GetRootFileGroups())
				{
					addFileGroupToTree(rootNode, fileGroup);
				}

				// --

				rootNode.Expanded = true;
			}

			sortTree();
		}

		/// <summary>
		/// Adds the file group to tree.
		/// </summary>
		/// <param name="parentNode">The parent node.</param>
		/// <param name="fileGroup">The file group.</param>
		/// <returns></returns>
		private TreeListNode addFileGroupToTree(
			TreeListNode parentNode,
			FileGroup fileGroup)
		{
			var fileGroupNode =
				treeView.AppendNode(
					new object[]
						{
							null,
						},
					parentNode);

			// --

			updateFileGroupInTree(
				fileGroupNode,
				fileGroup);

			// --

			addFileGroupFilesToTree(fileGroupNode);

			// --

			return fileGroupNode;
		}

		private void addFileGroupFilesToTree(
			TreeListNode fileGroupNode)
		{
			fileGroupNode.Nodes.Clear();

			if (!_project.HideFileGroupFilesInTree)
			{
				var ffis = ((FileGroup)fileGroupNode.Tag).ToArray();
				foreach (var filePath in ffis)
				{
					addFileToTree(fileGroupNode, filePath);
				}
			}
		}

		/// <summary>
		/// Updates the file group in tree.
		/// </summary>
		/// <param name="fileGroupNode">The file group node.</param>
		/// <param name="fileGroup">The file group.</param>
		private void updateFileGroupInTree(
			TreeListNode fileGroupNode,
			FileGroup fileGroup)
		{
			fileGroupNode[0] = fileGroup.GetNameIntelligent(_project);
			fileGroupNode.ImageIndex = fileGroupNode.SelectImageIndex = getImageIndex(@"group");
			fileGroupNode.Tag = fileGroup;
			fileGroupNode.StateImageIndex = (int)fileGroup.TranslationStateColor;

			updateNodeStateImage(fileGroupNode);

			UpdateUI();
		}

		//private void updateNodeStateImage(
		//    FileGroup fileGroup,
		//    FileGroupStates state )
		//{
		//    if ( treeView.Nodes.Count > 0 )
		//    {
		//        // For now, FileGroups are always in level 1.
		//        // This changes later.
		//        foreach ( TreeListNode node in treeView.Nodes[0].Nodes )
		//        {
		//            var fg = (FileGroup)node.Tag;

		//            if ( fg.GetChecksum( _project ) == fileGroup.GetChecksum( _project ) )
		//            {
		//                updateNodeStateImage( node, state );
		//                break;
		//            }
		//        }
		//    }
		//}

		private static void updateNodeStateImage(
			TreeListNode node)
		{
			if (node != null)
			{
				var si = node.Tag as ITranslationStateInformation;

				if (si != null)
				{
					var stateImageIndex = (int)si.TranslationStateColor;

					if (node.StateImageIndex != stateImageIndex)
					{
						node.StateImageIndex = stateImageIndex;

						if (si is FileGroup)
						{
							foreach (TreeListNode childNode in node.Nodes)
							{
								childNode.StateImageIndex = stateImageIndex;
							}
						}
					}
				}

				// --

				// Update parents.
				updateNodeStateImage(node.ParentNode);
			}
		}

		//private void updateRootStateImage()
		//{
		//    var rootNode = treeView.Nodes[0];

		//    var cumulatedIndex = 0;

		//    foreach ( TreeListNode node in rootNode.Nodes )
		//    {
		//        var breakLoop = false;
		//        var stateIndex = node.StateImageIndex;

		//        switch ( stateIndex )
		//        {
		//            case 0:
		//                switch ( cumulatedIndex )
		//                {
		//                    case 0:
		//                        cumulatedIndex = 0;
		//                        break;
		//                    case 1:
		//                        cumulatedIndex = 1;
		//                        break;
		//                    case 2:
		//                        cumulatedIndex = 2;
		//                        break;
		//                    case 3:
		//                        cumulatedIndex = 3;
		//                        break;

		//                    default:
		//                        throw new ArgumentException();
		//                }
		//                break;

		//            case 1:
		//                switch ( cumulatedIndex )
		//                {
		//                    case 0:
		//                        cumulatedIndex = 1;
		//                        break;
		//                    case 1:
		//                        cumulatedIndex = 1;
		//                        break;
		//                    case 2:
		//                        cumulatedIndex = 2;
		//                        break;
		//                    case 3:
		//                        cumulatedIndex = 3;
		//                        break;

		//                    default:
		//                        throw new ArgumentException();
		//                }
		//                break;

		//            case 2:
		//                switch ( cumulatedIndex )
		//                {
		//                    case 0:
		//                        cumulatedIndex = 2;
		//                        break;
		//                    case 1:
		//                        cumulatedIndex = 2;
		//                        break;
		//                    case 2:
		//                        cumulatedIndex = 2;
		//                        break;
		//                    case 3:
		//                        cumulatedIndex = 3;
		//                        break;

		//                    default:
		//                        throw new ArgumentException();
		//                }
		//                break;

		//            case 3:
		//                switch ( cumulatedIndex )
		//                {
		//                    case 0:
		//                        cumulatedIndex = 3;
		//                        break;
		//                    case 1:
		//                        cumulatedIndex = 3;
		//                        break;
		//                    case 2:
		//                        cumulatedIndex = 3;
		//                        break;
		//                    case 3:
		//                        cumulatedIndex = 3;
		//                        break;

		//                    default:
		//                        throw new ArgumentException();
		//                }
		//                breakLoop = true;
		//                break;

		//            default:
		//                throw new ArgumentException();
		//        }

		//        if ( breakLoop )
		//        {
		//            break;
		//        }
		//    }

		//    rootNode.StateImageIndex = cumulatedIndex;
		//}

		/// <summary>
		/// Adds the file to tree.
		/// </summary>
		/// <param name="fileGroupNode">The file group node.</param>
		/// <param name="filePath">The file path.</param>
		/// <returns></returns>
		private TreeListNode addFileToTree(
			TreeListNode fileGroupNode,
			FileFileInfo filePath)
		{
			var fileNode =
				treeView.AppendNode(
					new object[]
						{
							null,
						},
					fileGroupNode);

			fileNode[0] = filePath.File.Name;

			fileNode.ImageIndex = fileNode.SelectImageIndex = getImageIndex(@"file");
			fileNode.Tag = filePath;
			fileNode.StateImageIndex = (int)filePath.TranslationStateColor;

			return fileNode;
		}

		private static int getImageIndex(string key)
		{
			switch (key)
			{
				case @"root":
					return 0;
				case @"group":
					return 1;
				case @"file":
					return 2;
				case @"projectfolder":
					return 3;

				default:
					throw new ArgumentException();
			}
		}

		private TreeListNode addProjectFolderToTree(
			TreeListNode parentNode,
			ProjectFolder projectFolder)
		{
			var projectFolderNode =
				treeView.AppendNode(
					new object[]
						{
							null,
						},
					parentNode);

			// --

			updateProjectFolderInTree(
				projectFolderNode,
				projectFolder);

			// --

			foreach (var childProjectFolder in projectFolder.ChildProjectFolders)
			{
				addProjectFolderToTree(projectFolderNode, childProjectFolder);
			}

			foreach (var fileGroup in projectFolder.ChildFileGroups)
			{
				addFileGroupToTree(projectFolderNode, fileGroup);
			}

			// --

			return projectFolderNode;
		}

		private static void updateProjectFolderInTree(
			TreeListNode projectFolderNode,
			ProjectFolder projectFolder)
		{
			projectFolderNode[0] = projectFolder.Name;
			projectFolderNode.ImageIndex = projectFolderNode.SelectImageIndex = getImageIndex(@"projectfolder");
			projectFolderNode.Tag = projectFolder;
			projectFolderNode.StateImageIndex = (int)projectFolder.TranslationStateColor;

			updateNodeStateImage(projectFolderNode);
		}

		/// <summary>
		/// Opens the with dialog.
		/// </summary>
		internal void OpenWithDialog()
		{
			using (var ofd = new OpenFileDialog())
			{
				ofd.Multiselect = false;
				ofd.Filter = string.Format(@"{0} (*{1})|*{1}",
					Resources.SR_ProjectFilesUserControl_OpenWithDialog_EditorProjectFiles,
					Project.ProjectFileExtension);
				ofd.RestoreDirectory = true;

				var initialDir =
					ConvertHelper.ToString(
						FormHelper.RestoreValue(
						@"zreprojInitialDir"));
				ofd.InitialDirectory = initialDir;

				if (ofd.ShowDialog(this) == DialogResult.OK)
				{
					FormHelper.SaveValue(
						@"zreprojInitialDir",
						Path.GetDirectoryName(ofd.FileName));

					DoLoadProject(new FileInfo(ofd.FileName));
				}
			}
		}

		/// <summary>
		/// Does the save file.
		/// </summary>
		/// <param name="options">The options.</param>
		/// <returns></returns>
		internal DialogResult DoSaveFile(
			SaveOptions options)
		{
			if (_project == null)
			{
				return DialogResult.OK;
			}
			else
			{
				if ((options & SaveOptions.OnlyIfModified) == 0 ||
					_project.IsModified)
				{
					using (new WaitCursor(this, WaitCursorOption.ShortSleep))
					{
						if ((options & SaveOptions.AskConfirm) == 0)
						{
							addToMru();
							_project.Store();

							return DialogResult.OK;
						}
						else
						{
							var r2 =
								XtraMessageBox.Show(
									Resources.SR_ProjectFilesUserControl_DoSaveFile_SaveChangesToTheProjectFile,
									@"Zeta Resource Editor",
									MessageBoxButtons.YesNoCancel,
									MessageBoxIcon.Question);

							if (r2 == DialogResult.Yes)
							{
								addToMru();
								_project.Store();

								return DialogResult.OK;
							}
							else if (r2 == DialogResult.No)
							{
								return DialogResult.OK;
							}
							else
							{
								return DialogResult.Cancel;
							}
						}
					}
				}
				else
				{
					return DialogResult.OK;
				}
			}
		}

		/// <summary>
		/// Closes the and save project.
		/// </summary>
		internal void CloseAndSaveProject()
		{
			if (DoSaveFile(
				SaveOptions.OnlyIfModified |
					SaveOptions.AskConfirm) == DialogResult.OK)
			{
				closeProject();
			}
		}

		public void CloseProject()
		{
			if (_project != null)
			{
				closeProject();
			}
		}

		/// <summary>
		/// Edits the project settings with dialog.
		/// </summary>
		public void EditProjectSettingsWithDialog()
		{
			using (var form = new ProjectSettingsForm())
			{
				form.Initialize(_project);
				if (form.ShowDialog(this) == DialogResult.OK)
				{
					_project.MarkAsModified();
				}
			}
		}

		/// <summary>
		/// Edits the resource file settings with dialog.
		/// </summary>
		public void EditFileGroupSettingsWithDialog()
		{
			using (var form = new FileGroupSettingsForm())
			{
				form.Initialize((FileGroup)treeView.SelectedNode.Tag);
				if (form.ShowDialog(this) == DialogResult.OK)
				{
					_project.MarkAsModified();

					updateFileGroupInTree(
						treeView.SelectedNode,
						(FileGroup)treeView.SelectedNode.Tag);
				}
			}
		}

		public void CreateNewFileWithDialog()
		{
			using (var form = new CreateNewFileForm())
			{
				form.Initialize((FileGroup)treeView.SelectedNode.Tag);
				if (form.ShowDialog(this) == DialogResult.OK)
				{
					_project.MarkAsModified();

					addFileGroupFilesToTree(
						treeView.SelectedNode);

					updateFileGroupInTree(
						treeView.SelectedNode,
						(FileGroup)treeView.SelectedNode.Tag);

					UpdateUI();
				}
			}
		}

		public void CreateNewFilesWithDialog()
		{
			using (var form = new CreateNewFilesForm())
			{
				var p = treeView.SelectedNode.Tag as ProjectFolder;

				form.Initialize(_project, p);

				if (form.ShowDialog(this) == DialogResult.OK)
				{
					// Reload from in-memory project.
					fillFromProject();
					new TreeListViewState(treeView).RestoreState(@"projectsTree");

					_project.MarkAsModified();

					sortTree();
					UpdateUI();
				}
			}
		}

		/// <summary>
		/// Updates the UI.
		/// </summary>
		public override void UpdateUI()
		{
			base.UpdateUI();

			buttonEditResourceFiles.Enabled =
				CanEditResourceFiles;
			buttonAddFileGroupToProject.Enabled =
				CanAddResourceFilesToProject;
			buttonRemoveFileGroupFromProject.Enabled =
				CanRemoveResourceFilesFromProject;
			buttonEditProjectSettings.Enabled =
				CanEditProjectSettings;
			buttonAutomaticallyAddMultipleFileGroupsToProject.Enabled =
				CanAddResourceFilesToProject;
			buttonAutomaticallyAddFileGroupsFromVisualStudioSolution.Enabled =
				CanAddResourceFilesToProject;

			buttonAddFilesToFileGroup.Enabled =
				CanAddFilesToFileGroup;

			buttonEditFileGroupSettings.Enabled =
				CanEditFileGroupSettings;

			buttonRemoveFileFromFileGroup.Enabled =
				CanRemoveFileFromFileGroup;

			buttonCreateNewFile.Enabled =
				buttonCreateNewFiles.Enabled =
				CanCreateNewFile;

			// --

			buttonRemoveProjectFolder.Enabled =
				CanRemoveProjectFolder;
			buttonAddProjectFolder.Enabled =
				CanAddProjectFolder;
			buttonEditProjectFolder.Enabled =
				CanEditProjectFolderSettings;

			buttonMoveUp.Enabled =
				CanMoveUp;
			buttonMoveDown.Enabled =
				CanMoveDown;
		}

		/// <summary>
		/// Creates the new project.
		/// </summary>
		public void CreateNewProject()
		{
			using (var form = new CreateNewProjectForm())
			{
				if (form.ShowDialog(this) == DialogResult.OK)
				{
					var r = DoSaveFile(
						SaveOptions.OnlyIfModified |
							SaveOptions.AskConfirm);

					if (r == DialogResult.OK)
					{
						closeProject();

						// Only assign if successfully loaded.
						_project = Project.CreateNew(
							form.ProjectConfigurationFilePath);
						_project.ModifyStateChanged += project_ModifyStateChanged;

						fillFromProject();
					}
				}
			}
		}

		private void protectDoubleClickOnNode(
			BeforeExpandEventArgs e)
		{
			// Avoid expanding/collapsing upon double click.

			if (treeView.WasDoubleClick)
			{
				if (e.Node.Level > 0)
				{
					e.CanExpand = false;
					treeView.WasDoubleClick = false;
				}
			}
		}

		private void protectDoubleClickOnNode(
			BeforeCollapseEventArgs e)
		{
			// Avoid expanding/collapsing upon double click.

			if (treeView.WasDoubleClick)
			{
				e.CanCollapse = false;
				treeView.WasDoubleClick = false;
			}
		}

		/// <summary>
		/// Saves the state.
		/// </summary>
		/// <returns></returns>
		internal bool SaveState(
			SaveOptions options)
		{
			FormBase.SaveState(resourceEditorProjectFilesSplitContainer);
			new TreeListViewState(treeView).PersistsState(@"projectsTree");

			if (_project == null)
			{
				return true;
			}
			else
			{
				var r = DoSaveFile(options);

				if (r == DialogResult.OK)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}

		/// <summary>
		/// Saves the state.
		/// </summary>
		/// <returns></returns>
		public bool SaveState()
		{
			return SaveState(
				SaveOptions.OnlyIfModified |
					SaveOptions.AskConfirm);
		}

		/// <summary>
		/// Loads the recent project.
		/// </summary>
		public void LoadRecentProject()
		{
			var filePath =
				FormHelper.RestoreValue(@"RecentProject") as string;

			if (!string.IsNullOrEmpty(filePath) &&
				File.Exists(filePath))
			{
				DoLoadProject(new FileInfo(filePath));
			}
		}

		/// <summary>
		/// Saves the recent project info.
		/// </summary>
		public void SaveRecentProjectInfo()
		{
			string filePath;

			if (_project == null)
			{
				filePath = string.Empty;
			}
			else
			{
				filePath = _project.ProjectConfigurationFilePath.FullName;
			}

			FormHelper.SaveValue(@"RecentProject", filePath);
		}

		/// <summary>
		/// Adds the files to file group with dialog.
		/// </summary>
		public void AddFilesToFileGroupWithDialog()
		{
			using (var ofd = new OpenFileDialog())
			{
				ofd.Multiselect = true;
				ofd.Filter = string.Format(@"{0} (*.resx)|*.resx",
					Resources.SR_MainForm_openToolStripMenuItemClick_ResourceFiles);
				ofd.RestoreDirectory = true;

				var fileGroup = (FileGroup)treeView.SelectedNode.Tag;

				ofd.InitialDirectory = fileGroup.FolderPath.FullName;

				if (ofd.ShowDialog(this) == DialogResult.OK)
				{
					foreach (var fileName in ofd.FileNames)
					{
						var filePath = new FileInfo(fileName);

						if (filePath.Directory != null)
						{
							if (string.Compare(
									filePath.Directory.FullName,
									fileGroup.FolderPath.FullName, true) != 0)
							{
								throw new MessageBoxException(
									this,
									Resources.SR_ProjectFilesUserControl_AddFilesToFileGroupWithDialog_AlreadyPresent,
									MessageBoxIcon.Error);
							}
						}
					}

					// --

					var parentNode = treeView.SelectedNode;

					foreach (var fileName in ofd.FileNames)
					{
						var fileInfo =
							new FileFileInfo(fileGroup)
								{
									File = new FileInfo(fileName)
								};

						if (!fileGroup.Contains(fileInfo))
						{
							fileGroup.Add(fileInfo);

							if (!_project.HideFileGroupFilesInTree)
							{
								var node = addFileToTree(parentNode, fileInfo);
								treeView.SelectedNode = node;
							}
						}
					}

					sortTree();

					_project.MarkAsModified();
					UpdateUI();
				}
			}
		}

		/// <summary>
		/// Removes the file from file group with dialog.
		/// </summary>
		public void RemoveFileFromFileGroupWithDialog()
		{
			var dr = XtraMessageBox.Show(
				this,
				Resources.SR_ProjectFilesUserControl_RemoveFileFromFileGroupWithDialog_FromTheFileGroup,
				@"Zeta Resource Editor",
				MessageBoxButtons.YesNo,
				MessageBoxIcon.Question,
				MessageBoxDefaultButton.Button2);

			if (dr == DialogResult.Yes)
			{
				var node = treeView.SelectedNode;

				if (node != null && node.Tag is FileFileInfo)
				{
					var parentNode = node.ParentNode;

					var fileGroup = (FileGroup)node.ParentNode.Tag;

					fileGroup.Remove((FileFileInfo)node.Tag);
					_project.MarkAsModified();

					if (parentNode != null)
					{
						treeView.SelectedNode = parentNode;
					}

					node.ParentNode.Nodes.Remove(node);
				}
			}
		}

		private static void sortTree()
		{
			//treeView.TreeViewNodeSorter = new NodeSorter();
			//treeView.Sort();
			//treeView.TreeViewNodeSorter = null;
		}

		public void RefreshItems()
		{
			new TreeListViewState(treeView).PersistsState(@"projectsTree");
			fillFromProject();
			new TreeListViewState(treeView).RestoreState(@"projectsTree");
		}

		#region Event handler.
		// ------------------------------------------------------------------

		private void treeView_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Enter &&
				!e.Alt &&
				!e.Control &&
				!e.Shift)
			{
				if (CanEditResourceFiles)
				{
					editResourceFiles();

					e.Handled = true;
				}
			}
		}

		private void treeView_BeforeCollapse(object sender, BeforeCollapseEventArgs e)
		{
			// Never allow the root to be collapsed.
			if (e.Node.ParentNode == null)
			{
				e.CanCollapse = false;
			}
			else
			{
				protectDoubleClickOnNode(e);
			}
		}

		private void treeView_BeforeExpand(object sender, BeforeExpandEventArgs e)
		{
			protectDoubleClickOnNode(e);
		}

		private void projectFilesUserControlNew_Load(object sender, EventArgs e)
		{
			if (!Zeta.EnterpriseLibrary.Windows.Base.UserControlBase.IsDesignMode(this))
			{
				// Restore but ignore visibility.
				var vis = resourceEditorProjectFilesSplitContainer.PanelVisibility;
				FormBase.RestoreState(resourceEditorProjectFilesSplitContainer);
				resourceEditorProjectFilesSplitContainer.PanelVisibility = vis;

				new TreeListViewState(treeView).RestoreState(@"projectsTree");

				var form = FindForm();
				if (form != null)
				{
					form.Shown +=
						delegate
						{
							_formShown = true;
							/*guiRefreshTimer.Start();*/
						};
				}

				_nodeUpdateIterator = new StepwiseTreeIterator(
					treeView,
					NodeUpdateInterval,
					updateNodeInfo,
					1);

				MainForm.Current.FileGroupStateChanged.Add(
					(s, args) => updateNodeStateImage(locateNode(args.GridEditableData)));

				newsBrowserControl.WebBrowser.Navigate(
					Resources.SR_InlineNewsUrl);

				if (!HostSettings.Current.ShowNewsInMainWindow)
				{
					resourceEditorProjectFilesSplitContainer.PanelVisibility =
						SplitPanelVisibility.Panel1;
				}
			}
		}

		private TreeListNode locateNode(IGridEditableData fileGroup)
		{
			TreeListNode result = null;

			treeView.NodesIterator.DoOperation(
				n =>
				{
					if (result == null)
					{
						var fg = n.Tag as IGridEditableData;

						if (fg != null && fg.GetChecksum(_project) == fileGroup.GetChecksum(_project))
						{
							result = n;
						}
					}
				});

			return result;
		}

		private void optionsPopupMenu_BeforePopup(object sender, CancelEventArgs e)
		{
			UpdateUI();
		}

		private static readonly TimeSpan NodeUpdateInterval =
			new TimeSpan(0, 0, 1);

		private StepwiseTreeIterator _nodeUpdateIterator;
		private bool _formShown;
		private Font _boldFont;

		private void guiRefreshTimer_Tick(object sender, EventArgs e)
		{
			if (_formShown)
			{
				// Update one node each idle tick.
				_nodeUpdateIterator.Step();
				UpdateUI();
			}
		}

		private void buttonEditResourceFiles_ItemClick(object sender, ItemClickEventArgs e)
		{
			editResourceFiles();
		}

		private void buttonAutomaticallyAddMultipleFileGroupsToProject_ItemClick(object sender, ItemClickEventArgs e)
		{
			AutomaticallyAddAddResourceFilesWithDialog();
			UpdateUI();
		}

		private void buttonAddFileGroupToProject_ItemClick(object sender, ItemClickEventArgs e)
		{
			AddResourceFilesWithDialog();
			UpdateUI();
		}

		private void buttonRemoveFileGroupFromProject_ItemClick(object sender, ItemClickEventArgs e)
		{
			RemoveResourceFilesWithDialog();
			UpdateUI();
		}

		private void buttonEditFileGroupSettings_ItemClick(object sender, ItemClickEventArgs e)
		{
			EditFileGroupSettingsWithDialog();
			Update();
		}

		private void buttonAddFilesToFileGroup_ItemClick(object sender, ItemClickEventArgs e)
		{
			AddFilesToFileGroupWithDialog();
			UpdateUI();
		}

		private void buttonRemoveFileFromFileGroup_ItemClick(object sender, ItemClickEventArgs e)
		{
			RemoveFileFromFileGroupWithDialog();
			UpdateUI();
		}

		private void buttonEditProjectSettings_ItemClick(object sender, ItemClickEventArgs e)
		{
			EditProjectSettingsWithDialog();
			UpdateUI();
		}

		private void project_ModifyStateChanged(
			object sender,
			EventArgs e)
		{
			FormHelper.SyncInvoke(
				treeView,
				delegate
				{
					var project = (Project)sender;
					var text = project.Name;

					if (project.IsModified)
					{
						text += @" " + Project.ModifiedChar;
					}

					if (ConvertHelper.ToString(treeView.Nodes[0]) != text)
					{
						treeView.Nodes[0][0] = text;
					}
				});
		}

		private void treeView_MouseUp(object sender, MouseEventArgs e)
		{
			// http://www.devexpress.com/Support/Center/KB/p/A915.aspx.
			var tree = (TreeList)sender;

			if (e.Button == MouseButtons.Right &&
				ModifierKeys == Keys.None &&
				tree.State == TreeListState.Regular)
			{
				var pt = tree.PointToClient(MousePosition);
				var info = tree.CalcHitInfo(pt);

				switch (info.HitInfoType)
				{
					case HitInfoType.Row:
					case HitInfoType.Cell:
					case HitInfoType.Button:
					case HitInfoType.StateImage:
					case HitInfoType.SelectImage:
						if (info.Node != null)
						{
							treeView.SelectedNode = info.Node;
						}
						break;
				}

				UpdateUI();

				optionsPopupMenu.ShowPopup(MousePosition);
			}
		}

		private void treeView_DoubleClick(object sender, EventArgs e)
		{
			if (CanEditResourceFiles)
			{
				editResourceFiles();
			}
		}

		private void treeView_CompareNodeValues(
			object sender,
			CompareNodeValuesEventArgs e)
		{
			var tx = e.Node1;
			var ty = e.Node2;

			if (tx.Tag is FileFileInfo && ty.Tag is FileFileInfo)
			{
				var u = (FileFileInfo)tx.Tag;
				var v = (FileFileInfo)ty.Tag;

				e.Result = u.CompareTo(v);
			}
			else
			{
				// If they are the same length, call Compare.
				e.Result = string.Compare(
					ConvertHelper.ToString(tx[0]),
					ConvertHelper.ToString(ty[0]));
			}
		}

		private void toolTipController1_GetActiveObjectInfo(
			object sender,
			ToolTipControllerGetActiveObjectInfoEventArgs e)
		{
			// http://www.devexpress.com/Support/Center/KB/p/A474.aspx

			if (e.SelectedControl is TreeList)
			{
				var tree = (TreeList)e.SelectedControl;
				var hit = tree.CalcHitInfo(e.ControlMousePosition);

				if (hit.HitInfoType == HitInfoType.Cell)
				{
					var cellInfo = new TreeListCellToolTipInfo(hit.Node, hit.Column, null);

					var fg = hit.Node.Tag as FileGroup;
					var fsi = hit.Node.Tag as FileSystemInfo;

					string tt;
					if (fg != null)
					{
						tt = fg.GetFullNameIntelligent(_project);
					}
					else if (fsi != null)
					{
						tt = fsi.FullName;
					}
					else
					{
						tt = null;
					}

					if (tt != null)
					{
						e.Info = new ToolTipControlInfo(cellInfo, tt);
					}
				}
			}
		}

		private void buttonAddProjectFolder_ItemClick(object sender, ItemClickEventArgs e)
		{
			using (var form = new ProjectFolderEditForm())
			{
				var pf =
					new ProjectFolder(_project)
						{
							Name = Resources.SR_ProjectFilesUserControl_buttonAddProjectFolderItemClick_NewProjectFolder
						};

				form.Initialize(pf);

				if (form.ShowDialog(this) == DialogResult.OK)
				{
					var parentProjectFolder =
						treeView.SelectedNode.Tag as ProjectFolder;

					if (parentProjectFolder != null)
					{
						pf.Parent = parentProjectFolder;
					}

					_project.ProjectFolders.Add(pf);
					_project.MarkAsModified();

					var node = addProjectFolderToTree(treeView.SelectedNode, pf);

					// --

					sortTree();

					treeView.SelectedNode = node;

					UpdateUI();
				}
			}
		}

		private void buttonEditProjectFolder_ItemClick(object sender, ItemClickEventArgs e)
		{
			using (var form = new ProjectFolderEditForm())
			{
				form.Initialize((ProjectFolder)treeView.SelectedNode.Tag);
				if (form.ShowDialog(this) == DialogResult.OK)
				{
					_project.MarkAsModified();

					updateProjectFolderInTree(
						treeView.SelectedNode,
						(ProjectFolder)treeView.SelectedNode.Tag);

					UpdateUI();
				}
			}
		}

		private void buttonRemoveProjectFolder_ItemClick(object sender, ItemClickEventArgs e)
		{
			var dr = XtraMessageBox.Show(
				this,
				Resources.SR_ProjectFilesUserControl_buttonRemoveProjectFolder_ItemClick,
				@"Zeta Resource Editor",
				MessageBoxButtons.YesNo,
				MessageBoxIcon.Question,
				MessageBoxDefaultButton.Button2);

			if (dr == DialogResult.Yes)
			{
				var node = treeView.SelectedNode;

				removeNodeAndchilds(node);
				UpdateUI();
			}
		}

		private void removeNodeAndchilds(TreeListNode node)
		{
			if (node != null)
			{
				if (node.Tag is ProjectFolder)
				{
					// Recurse children.
					foreach (TreeListNode childNode in node.Nodes)
					{
						removeNodeAndchilds(childNode);
					}

					_project.ProjectFolders.Remove((ProjectFolder)node.Tag);
					_project.MarkAsModified();

					node.ParentNode.Nodes.Remove(node);

				}
				else if (node.Tag is FileGroup)
				{
					_project.FileGroups.Remove((FileGroup)node.Tag);
					_project.MarkAsModified();

					node.ParentNode.Nodes.Remove(node);
				}
				else
				{
					throw new Exception(
						string.Format(
							Resources.SR_ProjectFilesUserControl_removeNodeAndchilds_Unexpected_node_type,
							node.Tag == null ? @"null" : node.Tag.GetType().Name));
				}
			}
		}

		private void buttonMoveUp_ItemClick(object sender, ItemClickEventArgs e)
		{
			MoveUp();
		}

		private void buttonMoveDown_ItemClick(object sender, ItemClickEventArgs e)
		{
			MoveDown();
		}

		public void MoveUp()
		{
			treeView.EnsureItemsOrderPositionsSet(
				treeView.SelectedNode.ParentNode,
				AsynchronousMode.Synchronous);
			treeView.MoveItemUpByOne(treeView.SelectedNode);
			treeView.EnsureItemsOrderPositionsSet(
				treeView.SelectedNode.ParentNode,
				AsynchronousMode.Synchronous);

			_project.MarkAsModified();
			UpdateUI();
		}

		public void MoveDown()
		{
			treeView.EnsureItemsOrderPositionsSet(
				treeView.SelectedNode.ParentNode,
				AsynchronousMode.Synchronous);
			treeView.MoveItemDownByOne(treeView.SelectedNode);
			treeView.EnsureItemsOrderPositionsSet(
				treeView.SelectedNode.ParentNode,
				AsynchronousMode.Synchronous);

			_project.MarkAsModified();
			UpdateUI();
		}

		private static DragDropEffects getDragDropEffect(
			TreeList tl,
			TreeListNode dragNode)
		{
			var p = tl.PointToClient(MousePosition);
			var targetNode = tl.CalcHitInfo(p).Node;

			if (dragNode != null && targetNode != null &&
				dragNode != targetNode &&
				!ZetaResourceEditorTreeListControl.IsNodeChildNodeOf(targetNode, dragNode))
			{
				if (dragNode.Tag is FileGroup || dragNode.Tag is ProjectFolder)
				{
					if (targetNode.Tag is ProjectFolder || targetNode.Tag is Project)
					{
						return DragDropEffects.Move;
					}
					else
					{
						return DragDropEffects.None;
					}
				}
				else
				{
					return DragDropEffects.None;
				}
			}
			else
			{
				return DragDropEffects.None;
			}
		}

		// http://www.devexpress.com/Support/Center/KB/p/A342.aspx
		private void treeView_DragOver(
			object sender,
			DragEventArgs e)
		{
			var dragNode = (TreeListNode)e.Data.GetData(typeof(TreeListNode));
			e.Effect = getDragDropEffect((TreeList)sender, dragNode);
		}

		private void treeView_DragDrop(
			object sender,
			DragEventArgs e)
		{
			var tree = (TreeList)sender;
			var p = tree.PointToClient(new Point(e.X, e.Y));

			var dragNode = (TreeListNode)e.Data.GetData(typeof(TreeListNode));
			var targetNode = tree.CalcHitInfo(p).Node;

			// --

			var oldParent = dragNode.ParentNode;

			tree.MoveNode(dragNode, targetNode, true);
			tree.SetNodeIndex(dragNode, targetNode.Nodes.Count);
			//tl.SetNodeIndex( dragNode, tl.GetNodeIndex( targetNode ) );

			var newParentProjectFolder = targetNode.Tag as ProjectFolder;

			if (dragNode.Tag is FileGroup)
			{
				((FileGroup)dragNode.Tag).ProjectFolder = newParentProjectFolder;
			}
			else if (dragNode.Tag is ProjectFolder)
			{
				((ProjectFolder)dragNode.Tag).Parent = newParentProjectFolder;
			}
			else
			{
				throw new ArgumentException();
			}

			// --

			updateNodeStateImage(oldParent);
			updateNodeStateImage(dragNode);

			treeView.EnsureItemsOrderPositionsSet(
				treeView.SelectedNode.ParentNode,
				AsynchronousMode.Synchronous);
			_project.MarkAsModified();
			UpdateUI();

			// --

			// Handled.
			e.Effect = DragDropEffects.None;
		}

		private void treeView_CalcNodeDragImageIndex(
			object sender,
			CalcNodeDragImageIndexEventArgs e)
		{
			var tree = (TreeList)sender;
			if (getDragDropEffect(tree, tree.FocusedNode) == DragDropEffects.None)
			{
				e.ImageIndex = -1;  // no icon
			}
			else
			{
				e.ImageIndex = 1;  // the reorder icon (a curved arrow)		
			}
		}

		private void buttonCreateNewFile_ItemClick(object sender, ItemClickEventArgs e)
		{
			CreateNewFileWithDialog();
		}

		private void buttonCreateNewFiles_ItemClick(object sender, ItemClickEventArgs e)
		{
			CreateNewFilesWithDialog();
		}

		private Font boldFont
		{
			get
			{
				// ReSharper disable ConvertIfStatementToNullCoalescingExpression
				if (_boldFont == null)
				// ReSharper restore ConvertIfStatementToNullCoalescingExpression
				{
					_boldFont = new Font(Appearance.Font, FontStyle.Bold);
				}

				return _boldFont;
			}
		}

		private void treeView_NodeCellStyle(object sender, GetCustomNodeCellStyleEventArgs e)
		{
			if (e.Node.Tag is ProjectFolder)
			{
				e.Appearance.Font = boldFont;
			}
		}

		private void buttonAutomaticallyAddFileGroupsFromVisualStudioSolution_ItemClick(
			object sender,
			ItemClickEventArgs e)
		{
			AutomaticallyAddResourceFilesFromSolutionWithDialog();
			UpdateUI();
		}

		// ------------------------------------------------------------------
		#endregion
	}

	/////////////////////////////////////////////////////////////////////////
}