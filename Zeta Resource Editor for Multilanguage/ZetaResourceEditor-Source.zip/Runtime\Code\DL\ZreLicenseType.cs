namespace ZetaResourceEditor.Runtime.Code.DL
{
	using Misc.Localization;
	using Properties;

	public enum ZreLicenseType
	{
		[LocalizableDescription(@"SR_LicenseType_Freeware", typeof(Resources))]
		Freeware
	}
}