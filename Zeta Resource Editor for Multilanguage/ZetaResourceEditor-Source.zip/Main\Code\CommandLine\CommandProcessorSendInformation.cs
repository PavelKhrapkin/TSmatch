namespace ZetaResourceEditor.Code.CommandLine
{
	using DL;

	internal class CommandProcessorSendInformation
	{
		public Project Project
		{
			get;
			set;
		}

		public FileGroup[] FileGroups
		{
			get;
			set;
		}

		public string ReferenceLanguageCode
		{
			get;
			set;
		}

		public string[] DestinationLanguageCodes
		{
			get;
			set;
		}

		public string DestinationFilePath
		{
			get;
			set;
		}

		public bool EliminateDuplicateRows
		{
			get;
			set;
		}

		public bool OnlyExportRowsWithNoTranslation
		{
			get;
			set;
		}

		public bool ExportAllGroupsIntoOneWorksheet
		{
			get;
			set;
		}

		public bool ExportLanguageColumnsOnly
		{
			get; 
			set;
		}
	}
}