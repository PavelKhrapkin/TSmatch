﻿namespace ZetaResourceEditor.Code.DL
{
	using Properties;
	using Runtime.Code.Misc.Localization;

	public enum ReadOnlyFileOverwriteBehaviour
	{
		[LocalizableDescription(@"SR_ReadOnlyFileOverwriteBehaviour_Overwrite", typeof(Resources))]
		Overwrite,

		[LocalizableDescription(@"SR_ReadOnlyFileOverwriteBehaviour_Ask", typeof(Resources))]
		Ask,

		[LocalizableDescription(@"SR_ReadOnlyFileOverwriteBehaviour_Skip", typeof(Resources))]
		Skip,

		[LocalizableDescription(@"SR_ReadOnlyFileOverwriteBehaviour_Fail", typeof(Resources))]
		Fail
	}
}