namespace ZetaResourceEditor.UI.Main.LeftTree
{
	partial class ProjectFilesUserControl
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose( bool disposing )
		{
			if ( disposing && (components != null) )
			{
				components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProjectFilesUserControl));
			this.resourceEditorProjectFilesSplitContainer = new DevExpress.XtraEditors.SplitContainerControl();
			this.treeView = new ZetaResourceEditor.UI.Helper.ZetaResourceEditorTreeListControl(this.components);
			this.treeListColumn1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
			this.treeImageList = new DevExpress.Utils.ImageCollection(this.components);
			this.stateImageList = new DevExpress.Utils.ImageCollection(this.components);
			this.toolTipController1 = new DevExpress.Utils.ToolTipController(this.components);
			this.newsBrowserControl = new ZetaResourceEditor.UI.Helper.ExtendedWebBrowser.ExtendedWebBrowserUserControl();
			this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
			this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
			this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
			this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
			this.guiRefreshTimer = new System.Windows.Forms.Timer(this.components);
			this.barManager = new DevExpress.XtraBars.BarManager(this.components);
			this.popupBarImageCollection = new DevExpress.Utils.ImageCollection(this.components);
			this.buttonEditResourceFiles = new DevExpress.XtraBars.BarButtonItem();
			this.buttonAutomaticallyAddMultipleFileGroupsToProject = new DevExpress.XtraBars.BarButtonItem();
			this.buttonAddFileGroupToProject = new DevExpress.XtraBars.BarButtonItem();
			this.buttonRemoveFileGroupFromProject = new DevExpress.XtraBars.BarButtonItem();
			this.buttonEditFileGroupSettings = new DevExpress.XtraBars.BarButtonItem();
			this.buttonAddFilesToFileGroup = new DevExpress.XtraBars.BarButtonItem();
			this.buttonRemoveFileFromFileGroup = new DevExpress.XtraBars.BarButtonItem();
			this.buttonEditProjectSettings = new DevExpress.XtraBars.BarButtonItem();
			this.buttonAddProjectFolder = new DevExpress.XtraBars.BarButtonItem();
			this.buttonRemoveProjectFolder = new DevExpress.XtraBars.BarButtonItem();
			this.buttonEditProjectFolder = new DevExpress.XtraBars.BarButtonItem();
			this.buttonMoveUp = new DevExpress.XtraBars.BarButtonItem();
			this.buttonMoveDown = new DevExpress.XtraBars.BarButtonItem();
			this.buttonCreateNewFile = new DevExpress.XtraBars.BarButtonItem();
			this.buttonCreateNewFiles = new DevExpress.XtraBars.BarButtonItem();
			this.buttonAutomaticallyAddFileGroupsFromVisualStudioSolution = new DevExpress.XtraBars.BarButtonItem();
			this.optionsPopupMenu = new DevExpress.XtraBars.PopupMenu(this.components);
			((System.ComponentModel.ISupportInitialize)(this.resourceEditorProjectFilesSplitContainer)).BeginInit();
			this.resourceEditorProjectFilesSplitContainer.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.treeView)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.treeImageList)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.stateImageList)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.barManager)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.popupBarImageCollection)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.optionsPopupMenu)).BeginInit();
			this.SuspendLayout();
			// 
			// resourceEditorProjectFilesSplitContainer
			// 
			resources.ApplyResources(this.resourceEditorProjectFilesSplitContainer, "resourceEditorProjectFilesSplitContainer");
			this.resourceEditorProjectFilesSplitContainer.FixedPanel = DevExpress.XtraEditors.SplitFixedPanel.Panel2;
			this.resourceEditorProjectFilesSplitContainer.Horizontal = false;
			this.resourceEditorProjectFilesSplitContainer.Name = "resourceEditorProjectFilesSplitContainer";
			this.resourceEditorProjectFilesSplitContainer.Panel1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Default;
			this.resourceEditorProjectFilesSplitContainer.Panel1.Controls.Add(this.treeView);
			this.resourceEditorProjectFilesSplitContainer.Panel1.ShowCaption = true;
			resources.ApplyResources(this.resourceEditorProjectFilesSplitContainer.Panel1, "resourceEditorProjectFilesSplitContainer.Panel1");
			this.resourceEditorProjectFilesSplitContainer.Panel2.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Default;
			this.resourceEditorProjectFilesSplitContainer.Panel2.Controls.Add(this.newsBrowserControl);
			this.resourceEditorProjectFilesSplitContainer.Panel2.MinSize = 128;
			this.resourceEditorProjectFilesSplitContainer.Panel2.ShowCaption = true;
			resources.ApplyResources(this.resourceEditorProjectFilesSplitContainer.Panel2, "resourceEditorProjectFilesSplitContainer.Panel2");
			this.resourceEditorProjectFilesSplitContainer.SplitterPosition = 64;
			// 
			// treeView
			// 
			this.treeView.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn1});
			resources.ApplyResources(this.treeView, "treeView");
			this.treeView.Name = "treeView";
			this.treeView.OptionsBehavior.AllowExpandOnDblClick = false;
			this.treeView.OptionsBehavior.AllowIncrementalSearch = true;
			this.treeView.OptionsBehavior.DragNodes = true;
			this.treeView.OptionsBehavior.ImmediateEditor = false;
			this.treeView.OptionsSelection.EnableAppearanceFocusedCell = false;
			this.treeView.OptionsView.ShowColumns = false;
			this.treeView.OptionsView.ShowFocusedFrame = false;
			this.treeView.OptionsView.ShowHorzLines = false;
			this.treeView.OptionsView.ShowIndicator = false;
			this.treeView.OptionsView.ShowRoot = false;
			this.treeView.OptionsView.ShowVertLines = false;
			this.treeView.SelectedNode = null;
			this.treeView.SelectImageList = this.treeImageList;
			this.treeView.StateImageList = this.stateImageList;
			this.treeView.ToolTipController = this.toolTipController1;
			this.treeView.WasDoubleClick = false;
			this.treeView.NodeCellStyle += new DevExpress.XtraTreeList.GetCustomNodeCellStyleEventHandler(this.treeView_NodeCellStyle);
			this.treeView.CompareNodeValues += new DevExpress.XtraTreeList.CompareNodeValuesEventHandler(this.treeView_CompareNodeValues);
			this.treeView.CalcNodeDragImageIndex += new DevExpress.XtraTreeList.CalcNodeDragImageIndexEventHandler(this.treeView_CalcNodeDragImageIndex);
			this.treeView.MouseUp += new System.Windows.Forms.MouseEventHandler(this.treeView_MouseUp);
			this.treeView.KeyDown += new System.Windows.Forms.KeyEventHandler(this.treeView_KeyDown);
			this.treeView.DragOver += new System.Windows.Forms.DragEventHandler(this.treeView_DragOver);
			this.treeView.BeforeCollapse += new DevExpress.XtraTreeList.BeforeCollapseEventHandler(this.treeView_BeforeCollapse);
			this.treeView.BeforeExpand += new DevExpress.XtraTreeList.BeforeExpandEventHandler(this.treeView_BeforeExpand);
			this.treeView.DoubleClick += new System.EventHandler(this.treeView_DoubleClick);
			this.treeView.DragDrop += new System.Windows.Forms.DragEventHandler(this.treeView_DragDrop);
			// 
			// treeListColumn1
			// 
			resources.ApplyResources(this.treeListColumn1, "treeListColumn1");
			this.treeListColumn1.FieldName = "Name";
			this.treeListColumn1.Name = "treeListColumn1";
			this.treeListColumn1.OptionsColumn.AllowEdit = false;
			this.treeListColumn1.OptionsColumn.AllowMove = false;
			this.treeListColumn1.OptionsColumn.AllowSort = false;
			this.treeListColumn1.OptionsColumn.ReadOnly = true;
			// 
			// treeImageList
			// 
			this.treeImageList.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("treeImageList.ImageStream")));
			this.treeImageList.Images.SetKeyName(0, "root");
			this.treeImageList.Images.SetKeyName(1, "group");
			this.treeImageList.Images.SetKeyName(2, "file");
			this.treeImageList.Images.SetKeyName(3, "projectfolder");
			// 
			// stateImageList
			// 
			this.stateImageList.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("stateImageList.ImageStream")));
			this.stateImageList.Images.SetKeyName(0, "grey");
			this.stateImageList.Images.SetKeyName(1, "green");
			this.stateImageList.Images.SetKeyName(2, "yellow");
			this.stateImageList.Images.SetKeyName(3, "red");
			this.stateImageList.Images.SetKeyName(4, "blue");
			// 
			// toolTipController1
			// 
			this.toolTipController1.GetActiveObjectInfo += new DevExpress.Utils.ToolTipControllerGetActiveObjectInfoEventHandler(this.toolTipController1_GetActiveObjectInfo);
			// 
			// newsBrowserControl
			// 
			this.newsBrowserControl.Appearance.BackColor = System.Drawing.SystemColors.ControlDark;
			this.newsBrowserControl.Appearance.Options.UseBackColor = true;
			resources.ApplyResources(this.newsBrowserControl, "newsBrowserControl");
			this.newsBrowserControl.Name = "newsBrowserControl";
			// 
			// guiRefreshTimer
			// 
			this.guiRefreshTimer.Interval = 500;
			this.guiRefreshTimer.Tick += new System.EventHandler(this.guiRefreshTimer_Tick);
			// 
			// barManager
			// 
			this.barManager.DockControls.Add(this.barDockControlTop);
			this.barManager.DockControls.Add(this.barDockControlBottom);
			this.barManager.DockControls.Add(this.barDockControlLeft);
			this.barManager.DockControls.Add(this.barDockControlRight);
			this.barManager.Form = this;
			this.barManager.Images = this.popupBarImageCollection;
			this.barManager.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.buttonEditResourceFiles,
            this.buttonAutomaticallyAddMultipleFileGroupsToProject,
            this.buttonAddFileGroupToProject,
            this.buttonRemoveFileGroupFromProject,
            this.buttonEditFileGroupSettings,
            this.buttonAddFilesToFileGroup,
            this.buttonRemoveFileFromFileGroup,
            this.buttonEditProjectSettings,
            this.buttonAddProjectFolder,
            this.buttonRemoveProjectFolder,
            this.buttonEditProjectFolder,
            this.buttonMoveUp,
            this.buttonMoveDown,
            this.buttonCreateNewFile,
            this.buttonCreateNewFiles,
            this.buttonAutomaticallyAddFileGroupsFromVisualStudioSolution});
			this.barManager.MaxItemId = 19;
			// 
			// popupBarImageCollection
			// 
			this.popupBarImageCollection.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("popupBarImageCollection.ImageStream")));
			this.popupBarImageCollection.Images.SetKeyName(0, "pencil2.png");
			this.popupBarImageCollection.Images.SetKeyName(1, "magician.png");
			this.popupBarImageCollection.Images.SetKeyName(2, "box_add.png");
			this.popupBarImageCollection.Images.SetKeyName(3, "box_delete.png");
			this.popupBarImageCollection.Images.SetKeyName(4, "box_edit.png");
			this.popupBarImageCollection.Images.SetKeyName(5, "document_add.png");
			this.popupBarImageCollection.Images.SetKeyName(6, "document_delete.png");
			this.popupBarImageCollection.Images.SetKeyName(7, "earth_edit.png");
			this.popupBarImageCollection.Images.SetKeyName(8, "arrow_up_green.png");
			this.popupBarImageCollection.Images.SetKeyName(9, "arrow_down_green.png");
			this.popupBarImageCollection.Images.SetKeyName(10, "folder_blue_new.png");
			this.popupBarImageCollection.Images.SetKeyName(11, "folder_blue_edit.png");
			this.popupBarImageCollection.Images.SetKeyName(12, "folder_blue_delete.png");
			this.popupBarImageCollection.Images.SetKeyName(13, "document_new.png");
			// 
			// buttonEditResourceFiles
			// 
			resources.ApplyResources(this.buttonEditResourceFiles, "buttonEditResourceFiles");
			this.buttonEditResourceFiles.Id = 3;
			this.buttonEditResourceFiles.ImageIndex = 0;
			this.buttonEditResourceFiles.Name = "buttonEditResourceFiles";
			this.buttonEditResourceFiles.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.buttonEditResourceFiles_ItemClick);
			// 
			// buttonAutomaticallyAddMultipleFileGroupsToProject
			// 
			resources.ApplyResources(this.buttonAutomaticallyAddMultipleFileGroupsToProject, "buttonAutomaticallyAddMultipleFileGroupsToProject");
			this.buttonAutomaticallyAddMultipleFileGroupsToProject.Id = 4;
			this.buttonAutomaticallyAddMultipleFileGroupsToProject.ImageIndex = 1;
			this.buttonAutomaticallyAddMultipleFileGroupsToProject.Name = "buttonAutomaticallyAddMultipleFileGroupsToProject";
			this.buttonAutomaticallyAddMultipleFileGroupsToProject.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.buttonAutomaticallyAddMultipleFileGroupsToProject_ItemClick);
			// 
			// buttonAddFileGroupToProject
			// 
			resources.ApplyResources(this.buttonAddFileGroupToProject, "buttonAddFileGroupToProject");
			this.buttonAddFileGroupToProject.Id = 5;
			this.buttonAddFileGroupToProject.ImageIndex = 2;
			this.buttonAddFileGroupToProject.Name = "buttonAddFileGroupToProject";
			this.buttonAddFileGroupToProject.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.buttonAddFileGroupToProject_ItemClick);
			// 
			// buttonRemoveFileGroupFromProject
			// 
			resources.ApplyResources(this.buttonRemoveFileGroupFromProject, "buttonRemoveFileGroupFromProject");
			this.buttonRemoveFileGroupFromProject.Id = 6;
			this.buttonRemoveFileGroupFromProject.ImageIndex = 3;
			this.buttonRemoveFileGroupFromProject.Name = "buttonRemoveFileGroupFromProject";
			this.buttonRemoveFileGroupFromProject.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.buttonRemoveFileGroupFromProject_ItemClick);
			// 
			// buttonEditFileGroupSettings
			// 
			resources.ApplyResources(this.buttonEditFileGroupSettings, "buttonEditFileGroupSettings");
			this.buttonEditFileGroupSettings.Id = 7;
			this.buttonEditFileGroupSettings.ImageIndex = 4;
			this.buttonEditFileGroupSettings.Name = "buttonEditFileGroupSettings";
			this.buttonEditFileGroupSettings.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.buttonEditFileGroupSettings_ItemClick);
			// 
			// buttonAddFilesToFileGroup
			// 
			resources.ApplyResources(this.buttonAddFilesToFileGroup, "buttonAddFilesToFileGroup");
			this.buttonAddFilesToFileGroup.Id = 8;
			this.buttonAddFilesToFileGroup.ImageIndex = 5;
			this.buttonAddFilesToFileGroup.Name = "buttonAddFilesToFileGroup";
			this.buttonAddFilesToFileGroup.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.buttonAddFilesToFileGroup_ItemClick);
			// 
			// buttonRemoveFileFromFileGroup
			// 
			resources.ApplyResources(this.buttonRemoveFileFromFileGroup, "buttonRemoveFileFromFileGroup");
			this.buttonRemoveFileFromFileGroup.Id = 9;
			this.buttonRemoveFileFromFileGroup.ImageIndex = 6;
			this.buttonRemoveFileFromFileGroup.Name = "buttonRemoveFileFromFileGroup";
			this.buttonRemoveFileFromFileGroup.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.buttonRemoveFileFromFileGroup_ItemClick);
			// 
			// buttonEditProjectSettings
			// 
			resources.ApplyResources(this.buttonEditProjectSettings, "buttonEditProjectSettings");
			this.buttonEditProjectSettings.Id = 10;
			this.buttonEditProjectSettings.ImageIndex = 7;
			this.buttonEditProjectSettings.Name = "buttonEditProjectSettings";
			this.buttonEditProjectSettings.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.buttonEditProjectSettings_ItemClick);
			// 
			// buttonAddProjectFolder
			// 
			resources.ApplyResources(this.buttonAddProjectFolder, "buttonAddProjectFolder");
			this.buttonAddProjectFolder.Id = 11;
			this.buttonAddProjectFolder.ImageIndex = 10;
			this.buttonAddProjectFolder.Name = "buttonAddProjectFolder";
			this.buttonAddProjectFolder.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.buttonAddProjectFolder_ItemClick);
			// 
			// buttonRemoveProjectFolder
			// 
			resources.ApplyResources(this.buttonRemoveProjectFolder, "buttonRemoveProjectFolder");
			this.buttonRemoveProjectFolder.Id = 12;
			this.buttonRemoveProjectFolder.ImageIndex = 12;
			this.buttonRemoveProjectFolder.Name = "buttonRemoveProjectFolder";
			this.buttonRemoveProjectFolder.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.buttonRemoveProjectFolder_ItemClick);
			// 
			// buttonEditProjectFolder
			// 
			resources.ApplyResources(this.buttonEditProjectFolder, "buttonEditProjectFolder");
			this.buttonEditProjectFolder.Id = 13;
			this.buttonEditProjectFolder.ImageIndex = 11;
			this.buttonEditProjectFolder.Name = "buttonEditProjectFolder";
			this.buttonEditProjectFolder.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.buttonEditProjectFolder_ItemClick);
			// 
			// buttonMoveUp
			// 
			resources.ApplyResources(this.buttonMoveUp, "buttonMoveUp");
			this.buttonMoveUp.Id = 14;
			this.buttonMoveUp.ImageIndex = 8;
			this.buttonMoveUp.Name = "buttonMoveUp";
			this.buttonMoveUp.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.buttonMoveUp_ItemClick);
			// 
			// buttonMoveDown
			// 
			resources.ApplyResources(this.buttonMoveDown, "buttonMoveDown");
			this.buttonMoveDown.Id = 15;
			this.buttonMoveDown.ImageIndex = 9;
			this.buttonMoveDown.Name = "buttonMoveDown";
			this.buttonMoveDown.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.buttonMoveDown_ItemClick);
			// 
			// buttonCreateNewFile
			// 
			resources.ApplyResources(this.buttonCreateNewFile, "buttonCreateNewFile");
			this.buttonCreateNewFile.Id = 16;
			this.buttonCreateNewFile.ImageIndex = 13;
			this.buttonCreateNewFile.Name = "buttonCreateNewFile";
			this.buttonCreateNewFile.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.buttonCreateNewFile_ItemClick);
			// 
			// buttonCreateNewFiles
			// 
			resources.ApplyResources(this.buttonCreateNewFiles, "buttonCreateNewFiles");
			this.buttonCreateNewFiles.Glyph = ((System.Drawing.Image)(resources.GetObject("buttonCreateNewFiles.Glyph")));
			this.buttonCreateNewFiles.Id = 17;
			this.buttonCreateNewFiles.Name = "buttonCreateNewFiles";
			this.buttonCreateNewFiles.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.buttonCreateNewFiles_ItemClick);
			// 
			// buttonAutomaticallyAddFileGroupsFromVisualStudioSolution
			// 
			resources.ApplyResources(this.buttonAutomaticallyAddFileGroupsFromVisualStudioSolution, "buttonAutomaticallyAddFileGroupsFromVisualStudioSolution");
			this.buttonAutomaticallyAddFileGroupsFromVisualStudioSolution.Glyph = ((System.Drawing.Image)(resources.GetObject("buttonAutomaticallyAddFileGroupsFromVisualStudioSolution.Glyph")));
			this.buttonAutomaticallyAddFileGroupsFromVisualStudioSolution.Id = 18;
			this.buttonAutomaticallyAddFileGroupsFromVisualStudioSolution.Name = "buttonAutomaticallyAddFileGroupsFromVisualStudioSolution";
			this.buttonAutomaticallyAddFileGroupsFromVisualStudioSolution.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.buttonAutomaticallyAddFileGroupsFromVisualStudioSolution_ItemClick);
			// 
			// optionsPopupMenu
			// 
			this.optionsPopupMenu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.buttonEditResourceFiles),
            new DevExpress.XtraBars.LinkPersistInfo(this.buttonAutomaticallyAddMultipleFileGroupsToProject, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.buttonAutomaticallyAddFileGroupsFromVisualStudioSolution),
            new DevExpress.XtraBars.LinkPersistInfo(this.buttonAddFileGroupToProject, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.buttonRemoveFileGroupFromProject),
            new DevExpress.XtraBars.LinkPersistInfo(this.buttonEditFileGroupSettings),
            new DevExpress.XtraBars.LinkPersistInfo(this.buttonAddFilesToFileGroup, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.buttonCreateNewFile),
            new DevExpress.XtraBars.LinkPersistInfo(this.buttonCreateNewFiles),
            new DevExpress.XtraBars.LinkPersistInfo(this.buttonRemoveFileFromFileGroup),
            new DevExpress.XtraBars.LinkPersistInfo(this.buttonAddProjectFolder, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.buttonRemoveProjectFolder),
            new DevExpress.XtraBars.LinkPersistInfo(this.buttonEditProjectFolder),
            new DevExpress.XtraBars.LinkPersistInfo(this.buttonEditProjectSettings, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.buttonMoveUp, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.buttonMoveDown)});
			this.optionsPopupMenu.Manager = this.barManager;
			this.optionsPopupMenu.Name = "optionsPopupMenu";
			this.optionsPopupMenu.BeforePopup += new System.ComponentModel.CancelEventHandler(this.optionsPopupMenu_BeforePopup);
			// 
			// ProjectFilesUserControl
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.Controls.Add(this.resourceEditorProjectFilesSplitContainer);
			this.Controls.Add(this.barDockControlLeft);
			this.Controls.Add(this.barDockControlRight);
			this.Controls.Add(this.barDockControlBottom);
			this.Controls.Add(this.barDockControlTop);
			this.Name = "ProjectFilesUserControl";
			resources.ApplyResources(this, "$this");
			this.Load += new System.EventHandler(this.projectFilesUserControlNew_Load);
			((System.ComponentModel.ISupportInitialize)(this.resourceEditorProjectFilesSplitContainer)).EndInit();
			this.resourceEditorProjectFilesSplitContainer.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.treeView)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.treeImageList)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.stateImageList)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.barManager)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.popupBarImageCollection)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.optionsPopupMenu)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Timer guiRefreshTimer;
		private DevExpress.Utils.ImageCollection treeImageList;
		private DevExpress.Utils.ImageCollection stateImageList;
		private ZetaResourceEditor.UI.Helper.ZetaResourceEditorTreeListControl treeView;
		private DevExpress.XtraBars.BarManager barManager;
		private DevExpress.XtraBars.BarDockControl barDockControlTop;
		private DevExpress.XtraBars.BarDockControl barDockControlBottom;
		private DevExpress.XtraBars.BarDockControl barDockControlLeft;
		private DevExpress.XtraBars.BarDockControl barDockControlRight;
		private DevExpress.Utils.ImageCollection popupBarImageCollection;
		private DevExpress.XtraBars.PopupMenu optionsPopupMenu;
		private DevExpress.XtraBars.BarButtonItem buttonEditResourceFiles;
		private DevExpress.XtraBars.BarButtonItem buttonAutomaticallyAddMultipleFileGroupsToProject;
		private DevExpress.XtraBars.BarButtonItem buttonAddFileGroupToProject;
		private DevExpress.XtraBars.BarButtonItem buttonRemoveFileGroupFromProject;
		private DevExpress.XtraBars.BarButtonItem buttonEditFileGroupSettings;
		private DevExpress.XtraBars.BarButtonItem buttonAddFilesToFileGroup;
		private DevExpress.XtraBars.BarButtonItem buttonRemoveFileFromFileGroup;
		private DevExpress.XtraBars.BarButtonItem buttonEditProjectSettings;
		private DevExpress.XtraEditors.SplitContainerControl resourceEditorProjectFilesSplitContainer;
		private ZetaResourceEditor.UI.Helper.ExtendedWebBrowser.ExtendedWebBrowserUserControl newsBrowserControl;
		private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn1;
		private DevExpress.Utils.ToolTipController toolTipController1;
		private DevExpress.XtraBars.BarButtonItem buttonAddProjectFolder;
		private DevExpress.XtraBars.BarButtonItem buttonRemoveProjectFolder;
		private DevExpress.XtraBars.BarButtonItem buttonEditProjectFolder;
		private DevExpress.XtraBars.BarButtonItem buttonMoveUp;
		private DevExpress.XtraBars.BarButtonItem buttonMoveDown;
		private DevExpress.XtraBars.BarButtonItem buttonCreateNewFile;
		private DevExpress.XtraBars.BarButtonItem buttonCreateNewFiles;
		private DevExpress.XtraBars.BarButtonItem buttonAutomaticallyAddFileGroupsFromVisualStudioSolution;
	}
}
