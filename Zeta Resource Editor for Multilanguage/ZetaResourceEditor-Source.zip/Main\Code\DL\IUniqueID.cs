﻿namespace ZetaResourceEditor.Code.DL
{
	using System;

	public interface IUniqueID
	{
		Guid UniqueID
		{
			get;
		}
	}
}