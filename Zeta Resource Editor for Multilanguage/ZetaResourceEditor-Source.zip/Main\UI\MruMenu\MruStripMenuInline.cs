namespace ZetaResourceEditor.UI.MruMenu
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System.Windows.Forms;
	using Zeta.EnterpriseLibrary.Tools.Storage;

	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	// See http://www.codeproject.com/csharp/mrutoolstripmenu.asp.

	/// <summary>
	/// Represents an inline most recently used (MRU) menu.
	/// </summary>
	/// <remarks>
	/// This class shows the MRU list "inline". To display
	/// the MRU list as a pop-up menu use <see cref="MruMenu"/>.
	/// </remarks>
	public class MruStripMenuInline :
		MruStripMenuBase
	{
		#region Construction.
		// ------------------------------------------------------------------

		/// <summary>
		/// Initializes a new instance of the <see cref="MruStripMenuInline"/> class.
		/// </summary>
		/// <param name="owningMenu">The owning menu.</param>
		/// <param name="recentFileMenuItem">The recent file menu item.</param>
		/// <param name="clickedHandler">The clicked handler.</param>
		public MruStripMenuInline(
			ToolStripMenuItem owningMenu,
			ToolStripMenuItem recentFileMenuItem,
			MruMenuClickedEventHandler clickedHandler )
			:
			this(
			owningMenu,
			recentFileMenuItem,
			clickedHandler,
			null,
			_defaultStorageKey,
			_defaultMaxEntries )
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="MruStripMenuInline"/> class.
		/// </summary>
		/// <param name="owningMenu">The owning menu.</param>
		/// <param name="recentFileMenuItem">The recent file menu item.</param>
		/// <param name="clickedHandler">The clicked handler.</param>
		/// <param name="maxEntries">The max entries.</param>
		public MruStripMenuInline(
			ToolStripMenuItem owningMenu,
			ToolStripMenuItem recentFileMenuItem,
			MruMenuClickedEventHandler clickedHandler,
			int maxEntries )
			:
			this(
			owningMenu,
			recentFileMenuItem,
			clickedHandler,
			null,
			_defaultStorageKey,
			maxEntries )
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="MruStripMenuInline"/> class.
		/// </summary>
		/// <param name="owningMenu">The owning menu.</param>
		/// <param name="recentFileMenuItem">The recent file menu item.</param>
		/// <param name="clickedHandler">The clicked handler.</param>
		/// <param name="storage">The storage.</param>
		/// <param name="storageKey">The storage key.</param>
		public MruStripMenuInline(
			ToolStripMenuItem owningMenu,
			ToolStripMenuItem recentFileMenuItem,
			MruMenuClickedEventHandler clickedHandler,
			IPersistentPairStorage storage,
			string storageKey )
			:
			this(
			owningMenu,
			recentFileMenuItem,
			clickedHandler,
			storage,
			storageKey,
			_defaultMaxEntries )
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="MruStripMenuInline"/> class.
		/// </summary>
		/// <param name="owningMenu">The owning menu.</param>
		/// <param name="recentFileMenuItem">The recent file menu item.</param>
		/// <param name="clickedHandler">The clicked handler.</param>
		/// <param name="storage">The storage.</param>
		/// <param name="storageKey">The storage key.</param>
		/// <param name="maxEntries">The max entries.</param>
		public MruStripMenuInline(
			ToolStripMenuItem owningMenu,
			ToolStripMenuItem recentFileMenuItem,
			MruMenuClickedEventHandler clickedHandler,
			IPersistentPairStorage storage,
			string storageKey,
			int maxEntries )
		{
			MaxShortenPathLength = 250;
			_owningMenu = owningMenu;
			_firstMenuItem = recentFileMenuItem;

			Init(
				recentFileMenuItem,
				clickedHandler,
				storage,
				storageKey,
				maxEntries );
		}

		// ------------------------------------------------------------------
		#endregion

		#region Overridden properties.
		// ------------------------------------------------------------------

		/// <summary>
		/// Gets the menu items.
		/// </summary>
		/// <value>The menu items.</value>
		public override ToolStripItemCollection MenuItems
		{
			get
			{
				return _owningMenu.DropDownItems;
			}
		}

		/// <summary>
		/// Gets the start index.
		/// </summary>
		/// <value>The start index.</value>
		public override int StartIndex
		{
			get
			{
				return MenuItems.IndexOf( _firstMenuItem );
			}
		}

		/// <summary>
		/// Gets the end index.
		/// </summary>
		/// <value>The end index.</value>
		public override int EndIndex
		{
			get
			{
				return StartIndex + NumEntries;
			}
		}

		/// <summary>
		/// Gets a value indicating whether this instance is inline.
		/// </summary>
		/// <value><c>true</c> if this instance is inline; otherwise, <c>false</c>.</value>
		public override bool IsInline
		{
			get
			{
				return true;
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Overridden methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// Enables this instance.
		/// </summary>
		protected override void Enable()
		{
			MenuItems.Remove( RecentFileMenuItem );
		}

		/// <summary>
		/// Sets the first file.
		/// </summary>
		/// <param name="menuItem">The menu item.</param>
		protected override void SetFirstFile(
			MruMenuItem menuItem )
		{
			_firstMenuItem = menuItem;
		}

		/// <summary>
		/// Disables this instance.
		/// </summary>
		protected override void Disable()
		{
			int index = MenuItems.IndexOf( _firstMenuItem );
			MenuItems.RemoveAt( index );
			MenuItems.Insert( index, RecentFileMenuItem );
			_firstMenuItem = RecentFileMenuItem;
		}

		// ------------------------------------------------------------------
		#endregion

		#region Private variables.
		// ------------------------------------------------------------------

		private readonly ToolStripMenuItem _owningMenu;
		private ToolStripMenuItem _firstMenuItem;

		// ------------------------------------------------------------------
		#endregion
	}

	/////////////////////////////////////////////////////////////////////////
}