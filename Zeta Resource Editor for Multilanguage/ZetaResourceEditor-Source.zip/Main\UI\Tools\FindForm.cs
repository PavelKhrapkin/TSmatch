using System.Windows.Forms;
using Zeta.EnterpriseLibrary.Windows.Common;

namespace ZetaResourceEditor.UI.Tools
{
	using System;
	using Zeta.EnterpriseLibrary.Common;
	using Helper.Base;

	public partial class FindForm :
		FormBase
	{
		public FindForm()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Gets the text to find.
		/// </summary>
		/// <value>The text to find.</value>
		public string TextToFind
		{
			get
			{
				return textToFindComboBox.Text.Trim();
			}
			set
			{
				textToFindComboBox.Text = value;
			}
		}

		private void textToFindComboBox_TextUpdate( object sender, EventArgs e )
		{
			UpdateUI();
		}

		public override void UpdateUI()
		{
			base.UpdateUI();

			simpleButton1.Enabled = textToFindComboBox.Text.Trim().Length > 0;
		}

		private void FindForm_Load(
			object sender,
			EventArgs e )
		{
			FormHelper.RestoreState( this );
			CenterToParent();

			RestoreComboBox();

			UpdateUI();
		}

		private void FindForm_FormClosing(
			object sender,
			FormClosingEventArgs e )
		{
			FormHelper.SaveState( this );
			SaveComboBox();
		}

		/// <summary>
		/// Saves the combo box.
		/// </summary>
		private void SaveComboBox()
		{
			FormHelper.SaveState( textToFindComboBox );

			FormHelper.SaveValue(
				textToFindComboBox.Name + @".Count",
				textToFindComboBox.Properties.Items.Count );

			var index = 0;
			foreach ( string item in textToFindComboBox.Properties.Items )
			{
				FormHelper.SaveValue(
					textToFindComboBox.Name + @".Item." + index,
					item );

				index++;
			}
		}

		/// <summary>
		/// Restores the combo box.
		/// </summary>
		private void RestoreComboBox()
		{
			string temp = TextToFind;
			FormHelper.RestoreState( textToFindComboBox );

			int count = ConvertHelper.ToInt32(
				FormHelper.RestoreValue(
					textToFindComboBox.Name + @".Count" ) );

			for ( int index = 0; index < count; ++index )
			{
				string s =
					ConvertHelper.ToString(
						FormHelper.RestoreValue(
							textToFindComboBox.Name + @".Item." + index ) );

				if ( !string.IsNullOrEmpty( s ) )
				{
					textToFindComboBox.Properties.Items.Add( s );
				}
			}

			TextToFind = temp;
		}

		private void buttonOK_Click(
			object sender,
			EventArgs e )
		{
			bool has = false;
			foreach ( string text in textToFindComboBox.Properties.Items )
			{
				if ( string.Compare( text,
					textToFindComboBox.Text.Trim(), true ) == 0 )
				{
					has = true;
					break;
				}
			}

			if ( !has )
			{
				textToFindComboBox.Properties.Items.Insert(
					0,
					textToFindComboBox.Text.Trim() );
			}
		}
	}
}