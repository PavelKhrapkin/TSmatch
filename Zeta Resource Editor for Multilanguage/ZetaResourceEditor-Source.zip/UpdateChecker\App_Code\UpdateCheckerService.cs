﻿using System;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Web.Services;
using Zeta.EnterpriseLibrary.Common.IO;

[WebService( Namespace = @"http://www.zeta-resource-editor.com/" )]
[WebServiceBinding( ConformsTo = WsiProfiles.BasicProfile1_1 )]
public class UpdateCheckerService :
	ApiKeyProtectedWebServiceBase
{
	/// <summary>
	/// Determines whether [is update available] [the specified version].
	/// </summary>
	/// <param name="assemblyVersion">The assembly version.</param>
	/// <returns></returns>
	[WebMethod]
	public string IsUpdateAvailable(
		string assemblyVersion )
	{
		try
		{
			var v1 = new Version( assemblyVersion );
			var v2 = AvailableVersion;

			string url;

			if ( v1 >= v2 )
			{
				// No update available.
				url = string.Empty;
			}
			else
			{
				url = ConfigurationManager.AppSettings[@"downloadUrl"];
			}

			Trace.WriteLine( string.Format( @"Returning download URL '{0}'.", url ) );
			return url;
		}
		catch ( Exception x )
		{
			Trace.TraceError( x.Message );
			throw;
		}
	}

	/// <summary>
	/// Gets the available version.
	/// </summary>
	/// <value>The available version.</value>
	private Version AvailableVersion
	{
		get
		{
			var exeFilePath = Server.MapPath( @"~/App_Data/ZetaResourceEditor.exe" );

			if ( File.Exists( exeFilePath ) )
			{
				return FileHelper.GetAssemblyVersion( exeFilePath );
			}
			else
			{
				return new Version(
					ConfigurationManager.AppSettings[@"availableAssemblyVersion"] );
			}
		}
	}
}