namespace ZetaResourceEditor.Code.CommandLine
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System.ComponentModel;
	using System.Data;
	using Aspose.Cells;
	using DL;
	using Helper;
	using Properties;
	using Zeta.EnterpriseLibrary.Common;
	using Zeta.EnterpriseLibrary.Common.Collections;
	using Zeta.EnterpriseLibrary.Common.IO;

	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	internal class CommandProcessorSend
	{
		private CommandProcessorSendInformation _information;
		private readonly Set<string> _exportedReferenceLanguageValues =
			new Set<string>();

		public void Prepare(
			CommandProcessorSendInformation information)
		{
			_information = information;
		}

		public void Process(BackgroundWorker bw)
		{
			var workbook = new Workbook();

			workbook.Worksheets.Clear();

			Worksheet worksheet = null;
			var currentRowIndex = 0;

			var fileGroupIndex = 0;
			foreach (var fileGroup in _information.FileGroups)
			{
				if (bw.CancellationPending)
				{
					throw new CancelOperationException();
				}

				var isFirstFileGroup = fileGroupIndex == 0;
				var isLastFileGroup = fileGroupIndex == _information.FileGroups.Length - 1;

				var worksheetIndex = -1;

				if (_information.ExportAllGroupsIntoOneWorksheet)
				{
					if (worksheet == null)
					{
						worksheetIndex = workbook.Worksheets.Add();
						worksheet = workbook.Worksheets[worksheetIndex];
						worksheet.Name = Resources.SR_CommandProcessorSend_Process_ZRE_Export;
					}
				}
				else
				{
					worksheetIndex = workbook.Worksheets.Add();
					worksheet = workbook.Worksheets[worksheetIndex];
					worksheet.Name = generateWorksheetName(fileGroup, _information.Project);
				}
				var cells = worksheet.Cells;

				var wantNewSheet = !_information.ExportAllGroupsIntoOneWorksheet || isFirstFileGroup;

				// --
				// Header.

				const int headerStartRowIndex = 0;
				const int columnStartIndex = 0;

				if (wantNewSheet)
				{
					worksheet.FreezePanes(headerStartRowIndex + 1, 0, headerStartRowIndex + 1, 999);

					var offset = 0;
					Cell headerCell;

					if (!_information.ExportLanguageColumnsOnly)
					{
						// Checksum.
						headerCell = cells[headerStartRowIndex, columnStartIndex];
						headerCell.PutValue(Resources.SR_CommandProcessorSend_Process_Group);
						makeHeaderCell(headerCell);
						offset++;

						// String name.
						headerCell = cells[headerStartRowIndex, columnStartIndex + offset];
						headerCell.PutValue(Resources.SR_CommandProcessorSend_Process_Name);
						makeHeaderCell(headerCell);
						offset++;
					}

					// Reference language.
					headerCell = cells[headerStartRowIndex, columnStartIndex + offset];
					headerCell.PutValue(_information.ReferenceLanguageCode);
					makeHeaderCell(headerCell);
					offset++;

					// Destination languages.
					var realRunningColumnIndex = 0;
					for (var runningColIndex = 0;
						 runningColIndex < _information.DestinationLanguageCodes.Length;
						 ++runningColIndex)
					{
						var destinationLanguageCode =
							_information.DestinationLanguageCodes[runningColIndex];

						if (string.Compare(_information.ReferenceLanguageCode, destinationLanguageCode, true) != 0)
						{
							headerCell = cells[headerStartRowIndex, columnStartIndex + offset + realRunningColumnIndex];
							headerCell.PutValue(destinationLanguageCode);
							makeHeaderCell(headerCell);

							realRunningColumnIndex++;
						}
					}

					worksheet.AutoFitRow(headerStartRowIndex);

					currentRowIndex = headerStartRowIndex + 1;
				}

				// --
				// Content.

				var dp = new DataProcessing(fileGroup);
				var table =
					removeUnusedColumns(
						fileGroup.ParentSettings,
						dp.GetDataTableFromResxFiles());

				var rowIndex = 0;

				foreach (DataRow row in table.Rows)
				{
					if ((rowIndex + 1) % 20 == 0)
					{
						bw.ReportProgress(
							0,
							string.Format(
								Resources.SR_CommandProcessorSend_Process_ProcessingFileGroupOfRowOf,
								fileGroupIndex + 1,
								_information.FileGroups.Length,
								rowIndex + 1,
								table.Rows.Count,
								(int)(((rowIndex + 1.0) /
										(table.Rows.Count) *
										((fileGroupIndex + 1.0) /
										 (_information.FileGroups.Length))) * 100)));

						if (bw.CancellationPending)
						{
							throw new CancelOperationException();
						}
					}

					if (wantExportRow(fileGroup.ParentSettings, row))
					{
						if (!wasAlreadyExported(fileGroup.ParentSettings, row))
						{
							var offset = 0;

							if (!_information.ExportLanguageColumnsOnly)
							{
								// Checksum.
								var contentCell = cells[currentRowIndex, columnStartIndex];
								contentCell.PutValue(fileGroup.GetChecksum(_information.Project));
								makeCellReadOnly(contentCell);

								offset++;

								// String name.
								contentCell = cells[currentRowIndex, columnStartIndex + offset];
								contentCell.PutValue(row[0]);
								makeCellReadOnly(contentCell);

								offset++;
							}

							for (var columnIndex = 1; columnIndex < table.Columns.Count; ++columnIndex)
							{
								var languageValue = row[columnIndex] as string;

								var contentCell = cells[currentRowIndex, (columnStartIndex - 1) + columnIndex + offset];
								contentCell.PutValue(languageValue);

								var languageCode =
									new LanguageCodeDetection(_information.Project).DetectLanguageCodeFromFileName(
										fileGroup.ParentSettings,
										table.Columns[columnIndex].ColumnName);

								if (string.Compare(_information.ReferenceLanguageCode, languageCode, true) == 0)
								{
									makeCellReadOnly(contentCell);
									if (string.IsNullOrEmpty(languageValue))
									{
										_exportedReferenceLanguageValues.Add(string.Empty);
									}
									else
									{
										_exportedReferenceLanguageValues.Add(languageValue);
									}
								}
							}

							currentRowIndex++;
						}
					}

					//CHANGED if worksheet empty: remove it
					if (currentRowIndex == headerStartRowIndex + 1 && 
						!_information.ExportAllGroupsIntoOneWorksheet)
					{
						workbook.Worksheets.RemoveAt(worksheetIndex);
					}

					rowIndex++;
				}

				worksheet.AutoFitRow(currentRowIndex - 1);

				if (bw.CancellationPending)
				{
					throw new CancelOperationException();
				}

				// --

				if (!_information.ExportAllGroupsIntoOneWorksheet || isLastFileGroup)
				{
					var offset = 0;

					if (!_information.ExportLanguageColumnsOnly)
					{
						// Checksum.
						worksheet.AutoFitColumn(
							columnStartIndex,
							headerStartRowIndex,
							currentRowIndex);
						offset++;

						// String name.
						worksheet.AutoFitColumn(
							columnStartIndex + offset,
							headerStartRowIndex,
							currentRowIndex);
						offset++;
					}

					// Reference language.
					worksheet.AutoFitColumn(
						columnStartIndex + offset,
						headerStartRowIndex,
						currentRowIndex);
					offset++;

					// Destination languages.
					for (var runningColIndex = 0;
						 runningColIndex < _information.DestinationLanguageCodes.Length;
						 ++runningColIndex)
					{
						worksheet.AutoFitColumn(
							columnStartIndex + runningColIndex + offset,
							headerStartRowIndex,
							currentRowIndex);
					}
				}

				// --

				fileGroupIndex++;
			}

			bw.ReportProgress(
				0,
				string.Format(
					Resources.SR_CommandProcessorSend_Process_SavingMicrosoftOfficeExcelDocument));

			workbook.Save(_information.DestinationFilePath);
		}

		/// <summary>
		/// Check whether the export of duplicates is enabled/disabled and then
		/// check whether was exported in the past.
		/// </summary>
		private bool wasAlreadyExported(
			IInheritedSettings parentSettings,
			DataRow row)
		{
			if (_information.EliminateDuplicateRows)
			{
				for (var columnIndex = 1; columnIndex < row.Table.Columns.Count; ++columnIndex)
				{
					var languageCode =
						new LanguageCodeDetection(_information.Project).DetectLanguageCodeFromFileName(
							parentSettings,
							row.Table.Columns[columnIndex].ColumnName);

					if (string.Compare(_information.ReferenceLanguageCode, languageCode, true) == 0)
					{
						var languageValue = ConvertHelper.ToString(row[columnIndex]);
						return _exportedReferenceLanguageValues.Contains(languageValue);
					}
				}

				return false;
			}
			else
			{
				return false;
			}
		}

		private static string generateWorksheetName(FileGroup fileGroup, Project project)
		{
			// http://social.msdn.microsoft.com/Forums/en-US/vsto/thread/84c0c4d2-52b9-4502-bece-fdc616db05f8

			const int maxLength = 31;

			var ni =
				(project.UseCrypticWorkSheetNamesForExcelExport
					? fileGroup.UniqueID.ToString()
					: fileGroup.GetNameIntelligent(project))
					.Replace('\\', '#')
					.Replace('/', '#')
					.Replace('?', '_')
					.Replace('*', '_')
					.Replace('[', '_')
					.Replace(']', '_')
					.Replace(':', '_');
			//var cs = fileGroup.Checksum.ToString();

			//var s1 = string.Format( @" ({0})", cs );
			//var len = maxLength - s1.Length;

			var ni2 = FileGroup.ShortenFilePath(ni, maxLength);

			return ni2;
		}

		private bool wantExportRow(
			IInheritedSettings settings,
			DataRow row)
		{
			if (FileGroup.IsCompleteRowEmpty(row) ||
				// http://www.codeproject.com/KB/aspnet/ZetaResourceEditor.aspx?msg=3367544#xx3367544xx)
				FileGroup.IsInternalRow(row))
			{
				return false;
			}

			if (_information.OnlyExportRowsWithNoTranslation)
			{
				var emptyCount = 0;

				foreach (DataColumn column in row.Table.Columns)
				{
					if (column.Ordinal != 0)
					{
						var languageCode =
							new LanguageCodeDetection(_information.Project).DetectLanguageCodeFromFileName(
								settings,
								column.ColumnName);

						if (string.Compare(languageCode, _information.ReferenceLanguageCode, true) != 0)
						{
							if (ConvertHelper.ToString(row[column], string.Empty).Trim().Length <= 0)
							{
								emptyCount++;
							}
						}
					}
				}

				return emptyCount > 0;
			}
			else
			{
				return true;
			}
		}

		private DataTable removeUnusedColumns(
			IInheritedSettings settings,
			DataTable table)
		{
			var result = new DataTable();

			// --
			// Columns.

			// Order:
			// 1. The name column.
			// 2. The reference language column.
			// 3. All other columns.

			// 1.
			result.Columns.Add(table.Columns[0].ColumnName, typeof(string));

			// 2. Find.
			foreach (DataColumn column in table.Columns)
			{
				if (column.Ordinal != 0)
				{
					var languageCode =
						new LanguageCodeDetection(_information.Project).DetectLanguageCodeFromFileName(
							settings,
							column.ColumnName);

					if (string.Compare(_information.ReferenceLanguageCode, languageCode, true) == 0)
					{
						result.Columns.Add(column.ColumnName);
						break;
					}
				}
			}

			// 3.
			foreach (DataColumn column in table.Columns)
			{
				if (column.Ordinal != 0)
				{
					var languageCode =
						new LanguageCodeDetection(_information.Project).DetectLanguageCodeFromFileName(
							settings,
							column.ColumnName);

					if (string.Compare(_information.ReferenceLanguageCode, languageCode, true) != 0)
					{
						if (wantExportLanguageCode(languageCode))
						{
							result.Columns.Add(column.ColumnName);
						}
					}
				}
			}

			// --
			// Rows.

			foreach (DataRow sourceRow in table.Rows)
			{
				var destinationRow = result.NewRow();

				foreach (DataColumn column in result.Columns)
				{
					destinationRow[column.ColumnName] = sourceRow[column.ColumnName];
				}

				result.Rows.Add(destinationRow);
			}

			// --

			return result;
		}

		private bool wantExportLanguageCode(string languageCode)
		{
			if (string.IsNullOrEmpty(languageCode))
			{
				return false;
			}
			else
			{
				if (string.Compare(languageCode, _information.ReferenceLanguageCode, true) == 0)
				{
					return true;
				}
				else
				{
					foreach (var destinationLanguageCode in _information.DestinationLanguageCodes)
					{
						if (string.Compare(languageCode, destinationLanguageCode, true) == 0)
						{
							return true;
						}
					}

					return false;
				}
			}
		}

		private static void makeCellReadOnly(Cell cell)
		{
			// TODO: http://www.aspose.com/community/forums/post/34446/cell-locking-alternatives-for-readonly-effect.aspx
			cell.Style.IsLocked = true;
		}

		private static void makeHeaderCell(Cell cell)
		{
			var colorHeader = ExcelHelper.SafeExcelColors.Green;
			//var colorOddRows = ColorTranslator.FromHtml( @"#DBE5F1" );
			var colorLines = ExcelHelper.SafeExcelColors.Gray;
			var colorHeaderLine = ExcelHelper.SafeExcelColors.Black;

			cell.Style.ForegroundColor = colorHeader;
			cell.Style.BackgroundColor = colorHeader;
			cell.Style.Pattern = BackgroundType.Solid;

			cell.Style.Font.Color = ExcelHelper.SafeExcelColors.White;
			cell.Style.Font.IsBold = true;

			cell.Style.Borders[BorderType.BottomBorder].LineStyle = CellBorderType.Thin;
			cell.Style.Borders[BorderType.BottomBorder].Color = colorHeaderLine;

			cell.Style.Borders[BorderType.TopBorder].LineStyle = CellBorderType.Thin;
			cell.Style.Borders[BorderType.TopBorder].Color = colorLines;
		}
	}

	/////////////////////////////////////////////////////////////////////////
}