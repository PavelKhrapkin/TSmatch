namespace ZetaResourceEditor.UI.Helper
{
	partial class ErrorForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose( bool disposing )
		{
			if ( disposing && (components != null) )
			{
				components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager( typeof( ErrorForm ) );
			this.linearGradientPanel1 = new ZetaResourceEditor.UI.Helper.ExtendedControls.LinearGradientPanel();
			this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
			this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.buttonQuit = new DevExpress.XtraEditors.SimpleButton();
			this.buttonContinue = new DevExpress.XtraEditors.SimpleButton();
			this.optionsButton = new DevExpress.XtraEditors.DropDownButton();
			this.optionsPopupMenu = new DevExpress.XtraBars.PopupMenu( this.components );
			this.detailedErrorsButton = new DevExpress.XtraBars.BarButtonItem();
			this.underylingExceptionButton = new DevExpress.XtraBars.BarButtonItem();
			this.barManager = new DevExpress.XtraBars.BarManager( this.components );
			this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
			this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
			this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
			this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
			this.imageCollection1 = new DevExpress.Utils.ImageCollection( this.components );
			this.memoEdit1 = new DevExpress.XtraEditors.MemoEdit();
			this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
			this.linearGradientPanel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.optionsPopupMenu)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.barManager)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.memoEdit1.Properties)).BeginInit();
			this.SuspendLayout();
			// 
			// linearGradientPanel1
			// 
			this.linearGradientPanel1.AccessibleDescription = null;
			this.linearGradientPanel1.AccessibleName = null;
			resources.ApplyResources( this.linearGradientPanel1, "linearGradientPanel1" );
			this.linearGradientPanel1.BackgroundImage = null;
			this.linearGradientPanel1.Controls.Add( this.labelControl3 );
			this.linearGradientPanel1.Controls.Add( this.labelControl2 );
			this.linearGradientPanel1.Controls.Add( this.pictureBox1 );
			this.linearGradientPanel1.Font = null;
			this.linearGradientPanel1.GradientDirection = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
			this.linearGradientPanel1.GradientEnd = System.Drawing.Color.FromArgb( ((int)(((byte)(250)))), ((int)(((byte)(73)))), ((int)(((byte)(29)))) );
			this.linearGradientPanel1.GradientStart = System.Drawing.SystemColors.Window;
			this.linearGradientPanel1.Name = "linearGradientPanel1";
			// 
			// labelControl3
			// 
			this.labelControl3.AccessibleDescription = null;
			this.labelControl3.AccessibleName = null;
			resources.ApplyResources( this.labelControl3, "labelControl3" );
			this.labelControl3.Appearance.Font = new System.Drawing.Font( "Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel );
			this.labelControl3.Appearance.Options.UseFont = true;
			this.labelControl3.Name = "labelControl3";
			// 
			// labelControl2
			// 
			this.labelControl2.AccessibleDescription = null;
			this.labelControl2.AccessibleName = null;
			resources.ApplyResources( this.labelControl2, "labelControl2" );
			this.labelControl2.Appearance.Font = new System.Drawing.Font( "Tahoma", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel );
			this.labelControl2.Appearance.Options.UseFont = true;
			this.labelControl2.Name = "labelControl2";
			// 
			// pictureBox1
			// 
			this.pictureBox1.AccessibleDescription = null;
			this.pictureBox1.AccessibleName = null;
			resources.ApplyResources( this.pictureBox1, "pictureBox1" );
			this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox1.BackgroundImage = null;
			this.pictureBox1.Font = null;
			this.pictureBox1.ImageLocation = null;
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.TabStop = false;
			// 
			// buttonQuit
			// 
			this.buttonQuit.AccessibleDescription = null;
			this.buttonQuit.AccessibleName = null;
			resources.ApplyResources( this.buttonQuit, "buttonQuit" );
			this.buttonQuit.Appearance.Font = new System.Drawing.Font( "Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel );
			this.buttonQuit.Appearance.Options.UseFont = true;
			this.buttonQuit.BackgroundImage = null;
			this.buttonQuit.DialogResult = System.Windows.Forms.DialogResult.Abort;
			this.buttonQuit.Image = ((System.Drawing.Image)(resources.GetObject( "buttonQuit.Image" )));
			this.buttonQuit.Name = "buttonQuit";
			this.buttonQuit.Click += new System.EventHandler( this.buttonQuit_Click );
			// 
			// buttonContinue
			// 
			this.buttonContinue.AccessibleDescription = null;
			this.buttonContinue.AccessibleName = null;
			resources.ApplyResources( this.buttonContinue, "buttonContinue" );
			this.buttonContinue.Appearance.Font = new System.Drawing.Font( "Tahoma", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel );
			this.buttonContinue.Appearance.Options.UseFont = true;
			this.buttonContinue.BackgroundImage = null;
			this.buttonContinue.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.buttonContinue.Image = ((System.Drawing.Image)(resources.GetObject( "buttonContinue.Image" )));
			this.buttonContinue.Name = "buttonContinue";
			// 
			// optionsButton
			// 
			this.optionsButton.AccessibleDescription = null;
			this.optionsButton.AccessibleName = null;
			resources.ApplyResources( this.optionsButton, "optionsButton" );
			this.optionsButton.Appearance.Font = new System.Drawing.Font( "Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel );
			this.optionsButton.Appearance.Options.UseFont = true;
			this.optionsButton.BackgroundImage = null;
			this.optionsButton.DropDownControl = this.optionsPopupMenu;
			this.optionsButton.Image = ((System.Drawing.Image)(resources.GetObject( "optionsButton.Image" )));
			this.optionsButton.ImageLocation = DevExpress.XtraEditors.ImageLocation.MiddleRight;
			this.optionsButton.Name = "optionsButton";
			this.optionsButton.ShowArrowButton = false;
			// 
			// optionsPopupMenu
			// 
			this.optionsPopupMenu.LinksPersistInfo.AddRange( new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.detailedErrorsButton),
            new DevExpress.XtraBars.LinkPersistInfo(this.underylingExceptionButton)} );
			this.optionsPopupMenu.Manager = this.barManager;
			this.optionsPopupMenu.Name = "optionsPopupMenu";
			this.optionsPopupMenu.BeforePopup += new System.ComponentModel.CancelEventHandler( this.optionsPopupMenu_BeforePopup );
			// 
			// detailedErrorsButton
			// 
			this.detailedErrorsButton.AccessibleDescription = null;
			this.detailedErrorsButton.AccessibleName = null;
			resources.ApplyResources( this.detailedErrorsButton, "detailedErrorsButton" );
			this.detailedErrorsButton.Id = 0;
			this.detailedErrorsButton.ImageIndex = 1;
			this.detailedErrorsButton.Name = "detailedErrorsButton";
			this.detailedErrorsButton.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler( this.detailedErrorsButton_ItemClick );
			// 
			// underylingExceptionButton
			// 
			this.underylingExceptionButton.AccessibleDescription = null;
			this.underylingExceptionButton.AccessibleName = null;
			resources.ApplyResources( this.underylingExceptionButton, "underylingExceptionButton" );
			this.underylingExceptionButton.Id = 1;
			this.underylingExceptionButton.ImageIndex = 0;
			this.underylingExceptionButton.Name = "underylingExceptionButton";
			this.underylingExceptionButton.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler( this.underylingExceptionButton_ItemClick );
			// 
			// barManager
			// 
			this.barManager.DockControls.Add( this.barDockControlTop );
			this.barManager.DockControls.Add( this.barDockControlBottom );
			this.barManager.DockControls.Add( this.barDockControlLeft );
			this.barManager.DockControls.Add( this.barDockControlRight );
			this.barManager.Form = this;
			this.barManager.Images = this.imageCollection1;
			this.barManager.Items.AddRange( new DevExpress.XtraBars.BarItem[] {
            this.detailedErrorsButton,
            this.underylingExceptionButton} );
			this.barManager.MaxItemId = 3;
			// 
			// barDockControlTop
			// 
			this.barDockControlTop.AccessibleDescription = null;
			this.barDockControlTop.AccessibleName = null;
			resources.ApplyResources( this.barDockControlTop, "barDockControlTop" );
			this.barDockControlTop.Font = null;
			// 
			// barDockControlBottom
			// 
			this.barDockControlBottom.AccessibleDescription = null;
			this.barDockControlBottom.AccessibleName = null;
			resources.ApplyResources( this.barDockControlBottom, "barDockControlBottom" );
			this.barDockControlBottom.Font = null;
			// 
			// barDockControlLeft
			// 
			this.barDockControlLeft.AccessibleDescription = null;
			this.barDockControlLeft.AccessibleName = null;
			resources.ApplyResources( this.barDockControlLeft, "barDockControlLeft" );
			this.barDockControlLeft.Font = null;
			// 
			// barDockControlRight
			// 
			this.barDockControlRight.AccessibleDescription = null;
			this.barDockControlRight.AccessibleName = null;
			resources.ApplyResources( this.barDockControlRight, "barDockControlRight" );
			this.barDockControlRight.Font = null;
			// 
			// imageCollection1
			// 
			this.imageCollection1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject( "imageCollection1.ImageStream" )));
			// 
			// memoEdit1
			// 
			resources.ApplyResources( this.memoEdit1, "memoEdit1" );
			this.memoEdit1.BackgroundImage = null;
			this.memoEdit1.EditValue = null;
			this.memoEdit1.Name = "memoEdit1";
			this.memoEdit1.Properties.AccessibleDescription = null;
			this.memoEdit1.Properties.AccessibleName = null;
			this.memoEdit1.Properties.NullValuePrompt = resources.GetString( "memoEdit1.Properties.NullValuePrompt" );
			// 
			// labelControl1
			// 
			this.labelControl1.AccessibleDescription = null;
			this.labelControl1.AccessibleName = null;
			resources.ApplyResources( this.labelControl1, "labelControl1" );
			this.labelControl1.Name = "labelControl1";
			// 
			// ErrorForm
			// 
			this.AccessibleDescription = null;
			this.AccessibleName = null;
			this.Appearance.Font = new System.Drawing.Font( "Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel );
			this.Appearance.Options.UseFont = true;
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			resources.ApplyResources( this, "$this" );
			this.Controls.Add( this.labelControl1 );
			this.Controls.Add( this.memoEdit1 );
			this.Controls.Add( this.optionsButton );
			this.Controls.Add( this.buttonContinue );
			this.Controls.Add( this.buttonQuit );
			this.Controls.Add( this.linearGradientPanel1 );
			this.Controls.Add( this.barDockControlLeft );
			this.Controls.Add( this.barDockControlRight );
			this.Controls.Add( this.barDockControlBottom );
			this.Controls.Add( this.barDockControlTop );
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ErrorForm";
			this.Load += new System.EventHandler( this.errorForm_Load );
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler( this.errorForm_FormClosing );
			this.linearGradientPanel1.ResumeLayout( false );
			this.linearGradientPanel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.optionsPopupMenu)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.barManager)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.memoEdit1.Properties)).EndInit();
			this.ResumeLayout( false );
			this.PerformLayout();

		}

		#endregion

		private ZetaResourceEditor.UI.Helper.ExtendedControls.LinearGradientPanel linearGradientPanel1;
		private System.Windows.Forms.PictureBox pictureBox1;
		private DevExpress.XtraEditors.SimpleButton buttonQuit;
		private DevExpress.XtraEditors.SimpleButton buttonContinue;
		private DevExpress.XtraEditors.DropDownButton optionsButton;
		private DevExpress.XtraEditors.LabelControl labelControl3;
		private DevExpress.XtraEditors.LabelControl labelControl2;
		private DevExpress.XtraEditors.MemoEdit memoEdit1;
		private DevExpress.XtraEditors.LabelControl labelControl1;
		private DevExpress.XtraBars.PopupMenu optionsPopupMenu;
		private DevExpress.XtraBars.BarButtonItem detailedErrorsButton;
		private DevExpress.XtraBars.BarManager barManager;
		private DevExpress.XtraBars.BarDockControl barDockControlTop;
		private DevExpress.XtraBars.BarDockControl barDockControlBottom;
		private DevExpress.XtraBars.BarDockControl barDockControlLeft;
		private DevExpress.XtraBars.BarDockControl barDockControlRight;
		private DevExpress.XtraBars.BarButtonItem underylingExceptionButton;
		private DevExpress.Utils.ImageCollection imageCollection1;
	}
}