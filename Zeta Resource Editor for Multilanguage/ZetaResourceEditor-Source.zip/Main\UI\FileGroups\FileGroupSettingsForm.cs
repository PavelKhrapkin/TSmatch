﻿namespace ZetaResourceEditor.UI.FileGroups
{
	using System;
	using System.IO;
	using System.Windows.Forms;
	using Code.App;
	using Code.DL;
	using Helper.Base;
	using Main;
	using Zeta.EnterpriseLibrary.Windows.Common;

	public partial class FileGroupSettingsForm :
		FormBase
	{
		private FileGroup _fileGroup;

		public FileGroupSettingsForm()
		{
			InitializeComponent();
		}

		public override void UpdateUI()
		{
			base.UpdateUI();

			buttonOK.Enabled = nameTextBox.Text.Trim().Length > 0;
		}

		/// <summary>
		/// Initializes the specified file group.
		/// </summary>
		/// <param name="fileGroup">The file group.</param>
		internal void Initialize(
			FileGroup fileGroup )
		{
			_fileGroup = fileGroup;
		}

		private void FileGroupSettingsForm_Load( object sender, EventArgs e )
		{
			FormHelper.RestoreState( this );
			CenterToParent();

			nameTextBox.Text = _fileGroup.Name;
			locationTextBox.Text = _fileGroup.FolderPath != null ? _fileGroup.FolderPath.FullName : null;
			checkSumTextEdit.Text =
				_fileGroup.GetChecksum(
					MainForm.Current.ProjectFilesControl.Project ).ToString();

			parentTextEdit.Text =
				_fileGroup.ProjectFolder == null
					? _fileGroup.Project.Name
					: _fileGroup.ProjectFolder.NameIntelli;

			descriptionTextBox.Text = _fileGroup.Remarks;
		}

		private void buttonOK_Click( object sender, EventArgs e )
		{
			_fileGroup.Name = nameTextBox.Text;
			_fileGroup.Remarks = descriptionTextBox.Text;
		}

		private void FileGroupSettingsForm_FormClosing(
			object sender,
			FormClosingEventArgs e )
		{
			FormHelper.SaveState( this );
		}

		//private void button1_Click( object sender, EventArgs e )
		//{
		//    ((Button)sender).ContextMenuStrip.Show(
		//        ((Button)sender),
		//        new Point( 0, ((Button)sender).Height ) );
		//}

		private void openButton_ItemClick( object sender, DevExpress.XtraBars.ItemClickEventArgs e )
		{
			if ( !string.IsNullOrEmpty( locationTextBox.Text ) &&
			     Directory.Exists( locationTextBox.Text ) )
			{
				var sei =
					new ShellExecuteInformation
						{
							FileName = locationTextBox.Text
						};

				sei.Execute();
			}
		}

		private void nameTextBox_TextChanged( object sender, EventArgs e )
		{
			UpdateUI();
		}
	}
}