namespace ZetaResourceEditor.UI.Helper.ExtendedControls
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System;
	using System.Collections.Generic;
	using Properties;
	using Zeta.EnterpriseLibrary.Common.Collections;
	using Zeta.EnterpriseLibrary.Tools;
	using Base;

	// ----------------------------------------------------------------------
	#endregion

	public partial class EnumComboBox :
		UserControlBase
	{
		private Type _enumType;
		private bool _isFilled;

		public EnumComboBox()
		{
			//CheckThrowIsEnum();
			InitializeComponent();
		}

		public void Initialize(
			Type enumType )
		{
			if ( !enumType.IsEnum )
			{
				throw new ArgumentException( Resources.SR_EnumComboBox_Initialize_TMustBeAnEnum );
			}

			comboBox.Items.Clear();
			_enumType = enumType;
			_isFilled = false;
		}

		//private static void CheckThrowIsEnum()
		//{
		//    if ( !typeof( T ).IsEnum )
		//    {
		//        throw new ArgumentException( "T must be an enum." );
		//    }
		//}

		/// <summary>
		/// Gets or sets the selected value.
		/// </summary>
		/// <value>The value.</value>
		public Enum SelectedValue
		{
			get
			{
				if ( DesignMode )
				{
					return default( Enum );
				}
				else
				{
					fill();
					if ( comboBox.SelectedItem == null )
					{
						return default( Enum );
					}
					else
					{
						var p =
							(Pair<string, Enum>)comboBox.SelectedItem;

						return p.Value;
					}
				}
			}
			set
			{
				if ( !DesignMode )
				{
					fill();
					foreach ( Pair<string, Enum> pair in comboBox.Items )
					{
						if ( pair.Value.CompareTo( value ) == 0 )
						{
							comboBox.SelectedItem = pair;
							return;
						}
					}

					// Not found.
					comboBox.SelectedIndex = -1;
				}
			}
		}

		private void fill()
		{
			if ( !DesignMode && !_isFilled && _enumType != null )
			{
				comboBox.Items.Clear();
				_isFilled = true;

				var list = new List<Pair<string, Enum>>();

				foreach ( Enum t in Enum.GetValues( _enumType ) )
				{
					//if ( IgnoreInListAttribute.GetAttribute( t ) == null )
					{
						var p = new Pair<string, Enum>(
							StringHelper.GetEnumDescription(
								(Enum)Enum.Parse(
									_enumType,
									Convert.ToInt32( t ).ToString() ) ), t );

						list.Add( p );
					}
				}

				list.Sort( (a, b) => a.Name.CompareTo(b.Name));

				// --

				foreach ( var pair in list )
				{
					comboBox.Items.Add( pair );
				}
			}
		}

		public event EventHandler SelectedIndexChanged;

		private void comboBox_SelectedIndexChanged( object sender, EventArgs e )
		{
			if ( SelectedIndexChanged != null )
			{
				SelectedIndexChanged( this, e );
			}
		}
	}
}