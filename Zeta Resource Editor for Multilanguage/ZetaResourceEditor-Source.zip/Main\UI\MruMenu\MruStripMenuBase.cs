namespace ZetaResourceEditor.UI.MruMenu
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System;
	using System.Collections.Generic;
	using System.Windows.Forms;
	using System.IO;
	using System.Threading;
	using Code.Helper;
	using Zeta.EnterpriseLibrary.Common;
	using Zeta.EnterpriseLibrary.Tools.Storage;

	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	// See http://www.codeproject.com/csharp/mrutoolstripmenu.asp.

	/// <summary>
	/// Represents a most recently used (MRU) menu.
	/// </summary>
	/// <remarks>This class shows the MRU list in a popup menu. To display
	/// the MRU list "inline" use <see labelName="MruMenuInline" />.
	/// <para>The class will optionally load the last set of files from the 
	/// storage on construction and store them when instructed by the main 
	/// program.</para>
	/// <para>Internally, this class uses zero-based numbering for the items.
	/// The displayed numbers, however, will start with one.</para></remarks>
	public abstract class MruStripMenuBase
	{
		#region Private variables.
		// ------------------------------------------------------------------

		private MruMenuClickedEventHandler _clickedHandler;
		private ToolStripMenuItem _recentFileMenuItem;
		private IPersistentPairStorage _storage;
		private int _numEntries;
		private int _maxEntries = _defaultMaxEntries;
		private Mutex _mruStripMutex;
		private string _storageKey = _defaultStorageKey;

		private int _maxShortenPathLength = 250;
		protected static readonly int _defaultMaxEntries = 16;
		protected static readonly string _defaultStorageKey = @"MRU";

		// ------------------------------------------------------------------
		#endregion

		#region Construction.
		// ------------------------------------------------------------------

		/// <summary>
		/// Initializes a new instance of the <see cref="MruStripMenuBase"/> class.
		/// </summary>
		protected MruStripMenuBase()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="MruMenu"/> class.
		/// </summary>
		/// <param name="recentFileMenuItem">The recent file menu item.</param>
		/// <param name="clickedHandler">The clicked handler.</param>
		protected MruStripMenuBase(
			ToolStripMenuItem recentFileMenuItem,
			MruMenuClickedEventHandler clickedHandler )
			:
			this( recentFileMenuItem, clickedHandler, null, _defaultStorageKey, _defaultMaxEntries )
		{
		}

		/// <summary>
		/// Initializes a new instance of the MruMenu class.
		/// </summary>
		/// <param name="recentFileMenuItem">The recent file menu item.</param>
		/// <param name="clickedHandler">The clicked handler.</param>
		/// <param name="maxEntries">The max entries.</param>
		protected MruStripMenuBase(
			ToolStripMenuItem recentFileMenuItem,
			MruMenuClickedEventHandler clickedHandler,
			int maxEntries )
			:
			this( recentFileMenuItem, clickedHandler, null, _defaultStorageKey, maxEntries )
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="MruMenu"/> class.
		/// </summary>
		/// <param name="recentFileMenuItem">The recent file menu item.</param>
		/// <param name="clickedHandler">The clicked handler.</param>
		/// <param name="storage">The storage.</param>
		/// <param name="storageKey">The storage key.</param>
		protected MruStripMenuBase(
			ToolStripMenuItem recentFileMenuItem,
			MruMenuClickedEventHandler clickedHandler,
			IPersistentPairStorage storage,
			string storageKey )
			:
			this(
			recentFileMenuItem,
			clickedHandler,
			storage,
			storageKey,
			_defaultMaxEntries )
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="MruMenu"/> class.
		/// </summary>
		/// <param name="recentFileMenuItem">The recent file menu item.</param>
		/// <param name="clickedHandler">The clicked handler.</param>
		/// <param name="storage">The storage.</param>
		/// <param name="storageKey">The storage key.</param>
		/// <param name="maxEntries">The max entries.</param>
		protected MruStripMenuBase(
			ToolStripMenuItem recentFileMenuItem,
			MruMenuClickedEventHandler clickedHandler,
			IPersistentPairStorage storage,
			string storageKey,
			int maxEntries )
		{
			Init(
				recentFileMenuItem,
				clickedHandler,
				storage,
				storageKey,
				maxEntries );
		}

		/// <summary>
		/// Initializes the specified recent file menu item.
		/// </summary>
		/// <param name="recentFileMenuItem">The recent file menu item.</param>
		/// <param name="clickedHandler">The clicked handler.</param>
		/// <param name="storage">The storage.</param>
		/// <param name="storageKey">The storage key.</param>
		/// <param name="maxEntries">The max entries.</param>
		protected void Init(
			ToolStripMenuItem recentFileMenuItem,
			MruMenuClickedEventHandler clickedHandler,
			IPersistentPairStorage storage,
			string storageKey,
			int maxEntries )
		{
			if ( recentFileMenuItem == null )
			{
				throw new ArgumentNullException( @"recentFileMenuItem" );
			}

			RecentFileMenuItem = recentFileMenuItem;
			RecentFileMenuItem.Checked = false;
			RecentFileMenuItem.Enabled = false;

			_maxEntries = maxEntries;
			_clickedHandler = clickedHandler;

			if ( storage != null && storageKey != null )
			{
				LoadFromStorage( storage, storageKey );
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Event handling.
		// ------------------------------------------------------------------

		/// <summary>
		/// Called when [click].
		/// </summary>
		/// <param name="sender">The sender.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance 
		/// containing the event data.</param>
		protected void OnClick(
			object sender,
			EventArgs e )
		{
			var menuItem = (MruMenuItem)sender;

			if ( _clickedHandler != null )
			{
				_clickedHandler(
					sender,
					new MruMenuClickedEventArgs(
						MenuItems.IndexOf( menuItem ) - StartIndex,
						menuItem.FileName ) );
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Properties.
		// ------------------------------------------------------------------

		/// <summary>
		/// Gets the menu items.
		/// </summary>
		/// <value>The menu items.</value>
		public virtual ToolStripItemCollection MenuItems
		{
			get
			{
				return RecentFileMenuItem.DropDownItems;
			}
		}

		/// <summary>
		/// Gets the start index.
		/// </summary>
		/// <value>The start index.</value>
		public virtual int StartIndex
		{
			get
			{
				return 0;
			}
		}

		/// <summary>
		/// Gets the end index.
		/// </summary>
		/// <value>The end index.</value>
		public virtual int EndIndex
		{
			get
			{
				return _numEntries;
			}
		}

		/// <summary>
		/// Gets the number of entries.
		/// </summary>
		/// <value>The number of entries.</value>
		public int NumEntries
		{
			get
			{
				return _numEntries;
			}
		}

		/// <summary>
		/// Gets or sets the max entries.
		/// </summary>
		/// <value>The max entries.</value>
		public int MaxEntries
		{
			get
			{
				return _maxEntries;
			}
			set
			{
				if ( value > 16 )
				{
					_maxEntries = 16;
				}
				else
				{
					_maxEntries = value < _defaultMaxEntries ? _defaultMaxEntries : value;

					int index = StartIndex + _maxEntries;
					while ( _numEntries > _maxEntries )
					{
						MenuItems.RemoveAt( index );
						_numEntries--;
					}
				}
			}
		}

		/// <summary>
		/// Gets or sets the length of the max shorten path.
		/// </summary>
		/// <value>The length of the max shorten path.</value>
		public int MaxShortenPathLength
		{
			get
			{
				return _maxShortenPathLength;
			}
			set
			{
				_maxShortenPathLength = value < 16 ? 16 : value;
			}
		}

		/// <summary>
		/// Gets a value indicating whether this instance is inline.
		/// </summary>
		/// <value><c>true</c> if this instance is inline; otherwise, <c>false</c>.</value>
		public virtual bool IsInline
		{
			get
			{
				return false;
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Helper methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// Enables this instance.
		/// </summary>
		protected virtual void Enable()
		{
			RecentFileMenuItem.Enabled = true;
		}

		/// <summary>
		/// Disables this instance.
		/// </summary>
		protected virtual void Disable()
		{
			RecentFileMenuItem.Enabled = false;
			//recentFileMenuItem.MenuItems.RemoveAt(0);
		}

		/// <summary>
		/// Sets the first file.
		/// </summary>
		/// <param name="menuItem">The menu item.</param>
		protected virtual void SetFirstFile(
			MruMenuItem menuItem )
		{
		}

		/// <summary>
		/// Sets the first file.
		/// </summary>
		/// <param name="number">The number.</param>
		public void SetFirstFile(
			int number )
		{
			if ( number > 0 && _numEntries > 1 && number < _numEntries )
			{
				MruMenuItem menuItem =
					(MruMenuItem)MenuItems[StartIndex + number];

				MenuItems.RemoveAt( StartIndex + number );
				MenuItems.Insert( StartIndex, menuItem );

				SetFirstFile( menuItem );
				FixupPrefixes( 0 );
			}
		}

		/// <summary>
		/// Fixups the entryname.
		/// </summary>
		/// <param name="number">The number.</param>
		/// <param name="entryName">Name of the entry.</param>
		/// <returns></returns>
		public static string FixupEntryName(
			int number,
			string entryName )
		{
			if ( number < 9 )
			{
				return string.Format( @"&{0}  {1}", (number + 1), entryName );
			}
			else if ( number == 9 )
			{
				return string.Format( @"1&0  {0}", entryName );
			}
			else
			{
				return string.Format( @"{0}  {1}", (number + 1), entryName );
			}
		}

		/// <summary>
		/// Fixups the prefixes.
		/// </summary>
		/// <param name="startNumber">The start number.</param>
		protected void FixupPrefixes(
			int startNumber )
		{
			if ( startNumber < 0 )
			{
				startNumber = 0;
			}

			if ( startNumber < _maxEntries )
			{
				for ( int i = StartIndex + startNumber;
					i < EndIndex; i++, startNumber++ )
				{
					MenuItems[i].Text = FixupEntryName(
						startNumber,
						MenuItems[i].Text.Substring(
						startNumber == 9 ? 5 : 4 ) );
				}
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Get methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// Returns the entry number matching the passed fileName.
		/// </summary>
		/// <param name="fileName">The fileName to search for.</param>
		/// <returns>The entry number of the matching fileName or -1 if not 
		/// found.</returns>
		public int FindFileNameNumber(
			string fileName )
		{
			if ( fileName == null )
				throw new ArgumentNullException( @"fileName" );

			if ( fileName.Length == 0 )
				throw new ArgumentException( @"fileName" );

			if ( _numEntries > 0 )
			{
				int number = 0;
				for ( int i = StartIndex; i < EndIndex; i++, number++ )
				{
					if ( string.Compare(
						((MruMenuItem)MenuItems[i]).FileName, fileName, true )
						== 0 )
					{
						return number;
					}
				}
			}
			return -1;
		}

		/// <summary>
		/// Returns the menu index of the passed fileName.
		/// </summary>
		/// <param name="fileName">The fileName to search for.</param>
		/// <returns>The menu index of the matching fileName or -1 if not 
		/// found.</returns>
		public int FindFilenameMenuIndex(
			string fileName )
		{
			int number = FindFileNameNumber( fileName );
			return number < 0 ? -1 : StartIndex + number;
		}

		/// <summary>
		/// Returns the menu index for a specified MRU item number.
		/// </summary>
		/// <param name="number">The MRU item number.</param>
		/// <exception cref="ArgumentOutOfRangeException"></exception>
		/// <returns>The menu index of the passed MRU number.</returns>
		public int GetMenuIndex(
			int number )
		{
			if ( number < 0 || number >= _numEntries )
			{
				throw new ArgumentOutOfRangeException( @"number" );
			}

			return StartIndex + number;
		}

		/// <summary>
		/// Gets the file at.
		/// </summary>
		/// <param name="number">The number.</param>
		/// <returns></returns>
		public string GetFileAt(
			int number )
		{
			if ( number < 0 || number >= _numEntries )
			{
				throw new ArgumentOutOfRangeException( @"number" );
			}

			return ((MruMenuItem)MenuItems[StartIndex + number]).FileName;
		}

		/// <summary>
		/// Gets the files.
		/// </summary>
		/// <returns></returns>
		public string[] GetFiles()
		{
			string[] fileNames = new string[_numEntries];

			int index = StartIndex;
			for ( int i = 0; i < fileNames.GetLength( 0 ); i++, index++ )
			{
				fileNames[i] = ((MruMenuItem)MenuItems[index]).FileName;
			}

			return fileNames;
		}

		// 
		/// <summary>
		/// This is used for testing.
		/// </summary>
		public string[] GetFilesFullEntrystring()
		{
			string[] filenames = new string[_numEntries];

			int index = StartIndex;
			for ( int i = 0; i < filenames.GetLength( 0 ); i++, index++ )
			{
				filenames[i] = MenuItems[index].Text;
			}

			return filenames;
		}

		// ------------------------------------------------------------------
		#endregion

		#region Add methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// 
		/// </summary>
		/// <param name="filenames"></param>
		public void SetFiles(
			string[] filenames )
		{
			RemoveAll();
			for ( int i = filenames.GetLength( 0 ) - 1; i >= 0; i-- )
			{
				AddFile( filenames[i] );
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="filenames"></param>
		public void AddFiles(
			string[] filenames )
		{
			for ( int i = filenames.GetLength( 0 ) - 1; i >= 0; i-- )
			{
				AddFile( filenames[i] );
			}
		}

		/// <summary>
		/// Adds the file.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		public void AddFile(
			string fileName )
		{
			List<string> pathnames =
				new List<string>( fileName.Split( ';' ) );
			List<string> pathnames2 = new List<string>();

			foreach ( string s in pathnames )
			{
				pathnames2.Add( Path.GetFullPath( s ) );
			}

			AddFile(
				string.Join( @";", pathnames2.ToArray() ),
				ZrePathHelper.ShortenPathName(
					Path.GetDirectoryName( pathnames2[0] ),
					MaxShortenPathLength ) );
		}

		/// <summary>
		/// Adds the file.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		/// <param name="entryName">Name of the entry.</param>
		public void AddFile(
			string fileName,
			string entryName )
		{
			if ( fileName == null )
			{
				throw new ArgumentNullException( @"fileName" );
			}
			else if ( fileName.Length == 0 )
			{
				throw new ArgumentException( @"fileName" );
			}
			else
			{
				if ( _numEntries > 0 )
				{
					int index = FindFilenameMenuIndex( fileName );
					if ( index >= 0 )
					{
						SetFirstFile( index - StartIndex );
						return;
					}
				}

				if ( _numEntries < _maxEntries )
				{
					MruMenuItem menuItem = new MruMenuItem(
						fileName,
						FixupEntryName( 0, entryName ),
						entryName,
						OnClick );
					MenuItems.Insert( StartIndex, menuItem );
					SetFirstFile( menuItem );

					if ( _numEntries++ == 0 )
					{
						Enable();
					}
					else
					{
						FixupPrefixes( 1 );
					}
				}
				else if ( _numEntries > 1 )
				{
					MruMenuItem menuItem =
						(MruMenuItem)MenuItems[StartIndex + _numEntries - 1];
					MenuItems.RemoveAt( StartIndex + _numEntries - 1 );

					menuItem.Text = FixupEntryName( 0, entryName );
					menuItem.FileName = fileName;
					menuItem.EntryName = entryName;

					MenuItems.Insert( StartIndex, menuItem );

					SetFirstFile( menuItem );
					FixupPrefixes( 1 );
				}
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Remove methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// 
		/// </summary>
		/// <param name="number"></param>
		public void RemoveFile(
			int number )
		{
			if ( number >= 0 && number < _numEntries )
			{
				if ( --_numEntries == 0 )
				{
					Disable();
				}
				else
				{
					int startIndex = StartIndex;
					if ( number == 0 )
					{
						SetFirstFile(
							(MruMenuItem)MenuItems[startIndex + 1] );
					}

					MenuItems.RemoveAt( startIndex + number );

					if ( number < _numEntries )
					{
						FixupPrefixes( number );
					}
				}
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="fileName"></param>
		public void RemoveFile(
			string fileName )
		{
			if ( _numEntries > 0 )
			{
				RemoveFile( FindFileNameNumber( fileName ) );
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public void RemoveAll()
		{
			if ( _numEntries > 0 )
			{
				for ( int index = EndIndex - 1; index > StartIndex; index-- )
				{
					MenuItems.RemoveAt( index );
				}
				Disable();
				_numEntries = 0;
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Rename methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// Renames the file.
		/// </summary>
		/// <param name="oldFilename">The old filename.</param>
		/// <param name="newFilename">The new filename.</param>
		public void RenameFile(
			string oldFilename,
			string newFilename )
		{
			string newPathname = Path.GetFullPath( newFilename );

			RenameFile(
				Path.GetFullPath( oldFilename ),
				newPathname,
				ZrePathHelper.ShortenPathName( newPathname, MaxShortenPathLength ) );
		}

		/// <summary>
		/// Renames the file.
		/// </summary>
		/// <param name="oldFileName">Old name of the file.</param>
		/// <param name="newFileName">New name of the file.</param>
		/// <param name="newEntryName">New name of the entry.</param>
		public void RenameFile(
			string oldFileName,
			string newFileName,
			string newEntryName )
		{
			if ( string.IsNullOrEmpty( newFileName ) )
			{
				throw new ArgumentNullException( @"newFileName" );
			}

			if ( _numEntries > 0 )
			{
				int index = FindFilenameMenuIndex( oldFileName );
				if ( index >= 0 )
				{
					MruMenuItem menuItem = (MruMenuItem)MenuItems[index];

					menuItem.Text = FixupEntryName( 0, newEntryName );
					menuItem.FileName = newFileName;
					menuItem.EntryName = newEntryName;

					return;
				}
			}

			AddFile( newFileName, newEntryName );
		}

		// ------------------------------------------------------------------
		#endregion

		#region Storage methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// Gets or sets the storage.
		/// </summary>
		/// <value>The storage.</value>
		public IPersistentPairStorage Storage
		{
			get
			{
				return _storage;
			}
			set
			{
				_storage = value;
			}
		}

		/// <summary>
		/// Gets or sets the storage key.
		/// </summary>
		/// <value>The storagekey.</value>
		public string StorageKey
		{
			get
			{
				return _storageKey;
			}
			set
			{
				if ( _mruStripMutex != null )
				{
					_mruStripMutex.Close();
				}

				_storageKey =
					ConvertHelper.ToString( value, string.Empty ).Trim();

				if ( string.IsNullOrEmpty( _storageKey ) )
				{
					_storageKey = null;
					_mruStripMutex = null;
				}
				else
				{
					string mutexName =
						_storageKey.
						Replace( '\\', '_' ).
						Replace( '/', '_' ) + @"Mutex";

					_mruStripMutex = new Mutex( false, mutexName );
				}
			}
		}

		/// <summary>
		/// Gets or sets the recent file menu item.
		/// </summary>
		/// <value>The recent file menu item.</value>
		protected ToolStripMenuItem RecentFileMenuItem
		{
			get
			{
				return _recentFileMenuItem;
			}
			set
			{
				_recentFileMenuItem = value;
			}
		}

		/// <summary>
		/// Loads from storage.
		/// </summary>
		/// <param name="storage">The storage.</param>
		/// <param name="storageKey">The storage key.</param>
		public void LoadFromStorage(
			IPersistentPairStorage storage,
			string storageKey )
		{
			Storage = storage;
			StorageKey = storageKey;

			LoadFromStorage();
		}

		/// <summary>
		/// Loads from storage.
		/// </summary>
		public void LoadFromStorage()
		{
			if ( _storage != null )
			{
				_mruStripMutex.WaitOne();

				RemoveAll();

				_maxEntries = ConvertHelper.ToInt32(
					_storage.RetrieveValue( @"max." + _storageKey, _maxEntries ) );

				for ( int number = _maxEntries; number > 0; number-- )
				{
					string fileName =
						ConvertHelper.ToString(
							_storage.RetrieveValue(
								@"File." + _storageKey + number ) );
					string entryName =
						ConvertHelper.ToString(
							_storage.RetrieveValue(
								@"Entry." + _storageKey + number ) );

					if ( !string.IsNullOrEmpty( fileName ) )
					{
						if ( string.IsNullOrEmpty( entryName ) )
						{
							AddFile( fileName );
						}
						else
						{
							AddFile( fileName, entryName );
						}
					}
				}

				_mruStripMutex.ReleaseMutex();
			}
		}

		/// <summary>
		/// Saves to storage.
		/// </summary>
		/// <param name="storage">The storage.</param>
		public void SaveToStorage(
			IPersistentPairStorage storage )
		{
			_storage = storage;
			SaveToStorage();
		}

		/// <summary>
		/// Saves to storage.
		/// </summary>
		public void SaveToStorage()
		{
			if ( _storage != null )
			{
				_mruStripMutex.WaitOne();

				_storage.PersistValue( @"max." + _storageKey, _maxEntries );

				int number = 1;
				int i = StartIndex;
				for ( ; i < EndIndex; i++, number++ )
				{
					_storage.PersistValue(
						@"File." + _storageKey + number,
						((MruMenuItem)MenuItems[i]).FileName );
					_storage.PersistValue(
						@"Entry." + _storageKey + number,
						((MruMenuItem)MenuItems[i]).EntryName );
				}

				for ( ; number <= _maxEntries; number++ )
				{
					_storage.DeleteValue(
						@"File." + _storageKey + number );
					_storage.DeleteValue(
						@"Entry." + _storageKey + number );
				}

				_mruStripMutex.ReleaseMutex();
			}
		}

		// ------------------------------------------------------------------
		#endregion
	}

	/////////////////////////////////////////////////////////////////////////
}