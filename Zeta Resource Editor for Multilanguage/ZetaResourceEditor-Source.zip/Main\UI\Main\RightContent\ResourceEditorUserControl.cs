namespace ZetaResourceEditor.UI.Main.RightContent
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System;
	using System.Collections.Generic;
	using System.ComponentModel;
	using System.Data;
	using System.Diagnostics;
	using System.Drawing;
	using System.Globalization;
	using System.Windows.Forms;
	using Code.DL;
	using Code.Helper;
	using Code.Misc;
	using DevExpress.Data;
	using DevExpress.Skins;
	using DevExpress.XtraBars;
	using DevExpress.XtraEditors;
	using DevExpress.XtraEditors.Repository;
	using DevExpress.XtraGrid.Columns;
	using DevExpress.XtraGrid.Views.Base;
	using DevExpress.XtraGrid.Views.Grid;
	using DevExpress.XtraSpellChecker;
	using DevExpress.XtraTab;
	using Helper.Base;
	using Helper.Grid;
	using Properties;
	using TagOperations;
	using Tools;
	using Zeta.EnterpriseLibrary.Common;
	using Zeta.EnterpriseLibrary.Common.Collections;
	using Zeta.EnterpriseLibrary.Windows.Common;

	// ----------------------------------------------------------------------
	#endregion

	public partial class ResourceEditorUserControl :
		UserControlBase
	{
		public ResourceEditorUserControl()
		{
			InitializeComponent();
		}

		private void resourceEditorUserControlNew_SizeChanged(object sender, EventArgs e)
		{
			// Restore the size of the spliter after finally having
			// loaded and layouted.
			if (_isLoaded && !_restoredSplitContainer)
			{
				_restoredSplitContainer = true;
				restoreSplitterState();
			}

			Trace.WriteLine(@"SizeChanged");
		}

		private void resourceEditorUserControlNew_Load(object sender, EventArgs e)
		{
			MainForm.Current.Closing += current_Closing;

			FormHelper.RestoreState(tabControl1);

			_findText = ConvertHelper.ToString(
				FormHelper.RestoreValue(@"FindText"));

			mainDataGrid.Focus();
			mainDataGrid.Select();

			_isLoaded = true;
			Trace.WriteLine(@"Load");
		}

		private void current_Closing(object sender, CancelEventArgs e)
		{
			if (!SaveState())
			{
				e.Cancel = true;
			}
		}

		private void updateInGridButton_Click(object sender, EventArgs e)
		{
			updateGridFromDetails(selectedRowHandle);
		}

		private DataRowView selectedRow
		{
			get
			{
				var h = selectedRowHandle;
				if (h == -1)
				{
					return null;
				}
				else
				{
					return (DataRowView)mainGridView.GetRow(h);
				}
			}
		}

		private int selectedRowHandle
		{
			get
			{
				var cells = mainGridView.GetSelectedCells();
				if (cells.Length > 0)
				{
					return cells[0].RowHandle;
				}
				else
				{
					var rows = mainGridView.GetSelectedRows();
					if (rows.Length > 0)
					{
						return rows[0];
					}
					else
					{
						return -1;
					}
				}
			}
		}

		private IEnumerable<int> selectedRowHandles
		{
			get
			{
				var result = new Set<int>();

				var cells = mainGridView.GetSelectedCells();
				if (cells.Length > 0)
				{
					foreach (var cell in cells)
					{
						result.Add(cell.RowHandle);
					}
				}
				else
				{
					var rows = mainGridView.GetSelectedRows();

					foreach (int row in rows)
					{
						result.Add(row);
					}
				}

				return result.ToArray();
			}
		}

		private bool hasSelectedRow
		{
			get
			{
				return selectedRowHandle != -1;
			}
		}

		private void mainDataView_RowCellStyle(object sender, RowCellStyleEventArgs e)
		{
			// Ignore during closing.
			if (mainDataGrid.DataSource != null)
			{
				adjustCellColor(e);
			}
		}

		private void mainDataView_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
		{
			// Ignore during closing.
			if (mainDataGrid.DataSource != null)
			{
				startDoUpdateDetails();
			}
		}

		private void mainDataView_FocusedColumnChanged(object sender, FocusedColumnChangedEventArgs e)
		{
			// Ignore during closing.
			if (mainDataGrid.DataSource != null)
			{
				startDoUpdateDetails();
			}
		}

		private void mainDataView_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			// Ignore during closing.
			if (mainDataGrid.DataSource != null)
			{
				startDoUpdateDetails();
			}
		}

		private void doUpdateDetails()
		{
			if (_allowUpdatingDetails)
			{
				var newCurrentRowIndex = selectedRowHandle;

				// --

				// Must put details back to grid.
				if (_currentRowIndex >= 0 && newCurrentRowIndex >= 0 &&
					newCurrentRowIndex != _currentRowIndex)
				{
					updateGridFromDetails(_currentRowIndex);
				}

				// --

				_currentRowIndex = newCurrentRowIndex;

				updateDetailsFromGrid();
			}
		}

		private DataProcessing _data;
		private bool _allowUpdatingDetails = true;

		/// <summary>
		/// Stores.
		/// </summary>
		/// <param name="options">The options.</param>
		/// <returns></returns>
		internal DialogResult DoSaveFiles(
			SaveOptions options)
		{
			if ((options & SaveOptions.OnlyIfModified) == 0 ||
				_isGridContentModified)
			{
				var createBackups =
					MainForm.Current.ProjectFilesControl.Project != null &&
					MainForm.Current.ProjectFilesControl.Project.CreateBackupFiles;
				var omitEmptyStrings =
					MainForm.Current.ProjectFilesControl.Project != null &&
					MainForm.Current.ProjectFilesControl.Project.OmitEmptyItems;

				using (new WaitCursor(this))
				{
					if ((options & SaveOptions.AskConfirm) == 0)
					{
						_data.SaveDataTableToResxFiles(
							(DataTable)mainDataGrid.DataSource,
							createBackups,
							omitEmptyStrings);

						markDetailsContentAsUnmodified(); // 2009-08-25, Uwe Keim.
						markGridContentAsUnmodified();

						return DialogResult.OK;
					}
					else
					{
						var r2 =
							XtraMessageBox.Show(
								Resources.SR_MainForm_DoSaveFiles_SaveChangesToTheResourceFiles,
								@"Zeta Resource Editor",
								MessageBoxButtons.YesNoCancel,
								MessageBoxIcon.Question);

						if (r2 == DialogResult.Yes)
						{
							_data.SaveDataTableToResxFiles(
								(DataTable)mainDataGrid.DataSource,
								createBackups,
								omitEmptyStrings);

							markDetailsContentAsUnmodified(); // 2009-08-25, Uwe Keim.
							markGridContentAsUnmodified();

							return DialogResult.OK;
						}
						else if (r2 == DialogResult.No)
						{
							return DialogResult.OK;
						}
						else
						{
							return DialogResult.Cancel;
						}
					}
				}
			}
			else
			{
				return DialogResult.OK;
			}
		}

		private void markGridContentAsUnmodified()
		{
			_isGridContentModified = false;
			notifyModifyStateChanged();
		}

		/// <summary>
		/// Gets a value indicating whether this instance is modified.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if this instance is modified; otherwise, <c>false</c>.
		/// </value>
		public bool IsModified
		{
			get
			{
				return _isDetailsContentModified || _isGridContentModified;
			}
		}

		/// <summary>
		/// Opens the with dialog.
		/// </summary>
		/// <param name="fileGroup">The file group.</param>
		/// <returns></returns>
		internal bool OpenWithDialog(
			FileGroup fileGroup)
		{
			var r = DoSaveFiles(
				SaveOptions.OnlyIfModified |
					SaveOptions.AskConfirm);

			if (r == DialogResult.OK)
			{
				DoLoadFiles(fileGroup);

				// Immediately stores.
				MainForm.AddMruFiles(fileGroup.JoinedFilePaths);

				GridEditableData = fileGroup;
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// Does the load files.
		/// </summary>
		/// <param name="gridEditableData">The file group.</param>
		internal void DoLoadFiles(
			IGridEditableData gridEditableData)
		{
			closeDataGrid();

			GridEditableData = gridEditableData;
			_data = new DataProcessing(gridEditableData);

			// ReSharper disable ConvertIfStatementToConditionalTernaryExpression
			if (gridEditableData.GetFileFileInfosSorted().Length > 0)
			// ReSharper restore ConvertIfStatementToConditionalTernaryExpression
			{
				fileNameTextEdit.Text = gridEditableData.FolderPath.FullName;
			}
			else
			{
				fileNameTextEdit.Text = null;
			}

			tabControl1.TabPages.Clear();

			var table = _data.GetDataTableFromResxFiles();

			if (table == null)
			{
				CloseAndSaveDataGrid();
			}
			else
			{
				for (var i = 1; i < table.Columns.Count; ++i)
				{
					var imageIndex =
						DataProcessing.CommentsAreVisible(table) &&
							i == table.Columns.Count - 1
							? 1
							: 0;

					addTab(
						imageIndex,
						imageIndex == 1
							? Resources.SR_ColumnCaption_Comment
							: table.Columns[i].Caption);
				}
			}

			mainDataGrid.DataSource = table;
			mainDataGrid.MainView.PopulateColumns();
			postpareStructure();

			FormBase.RestoreState(tabControl1);

			UpdateUI();

			restoreGridLayout();
			restoreSplitterState();

			// Initially.
			markGridContentAsUnmodified();
			markDetailsContentAsUnmodified();
			_currentRowIndex = -1;
			_canSaveGridLayout = true;

			// --

			updateStateImage();
		}

		private void postpareStructure()
		{
			var meRepositoryItem =
				new RepositoryItemMemoEdit
				{
					ReadOnly = true,
					AutoHeight = true,
					AcceptsReturn = false,
					AcceptsTab = false,
				};
			mainDataGrid.RepositoryItems.Add(meRepositoryItem);

			var me =
				new RepositoryItemMemoEdit
					{
						AutoHeight = true,
						AcceptsReturn = false,
						AcceptsTab = false,
					};
			mainDataGrid.RepositoryItems.Add(me);
			me.KeyDown += me_KeyDown;

			var index = 0;
			foreach (GridColumn column in mainGridView.Columns)
			{
				// ReSharper disable ConvertIfStatementToConditionalTernaryExpression
				if (index == 0)
				// ReSharper restore ConvertIfStatementToConditionalTernaryExpression
				{
					column.ColumnEdit = meRepositoryItem;
				}
				else
				{
					column.ColumnEdit = me;
				}

				index++;
			}
		}

		private static void me_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Shift && e.KeyCode == Keys.Enter)
			{
				var me = (MemoEdit)sender;

				me.SelectedText = Environment.NewLine;
				e.Handled = true;
			}
		}

		/// <summary>
		/// Adds a new detail tab.
		/// </summary>
		private void addTab(int imageIndex, string name)
		{
			var tabPage =
				new XtraTabPage
					{
						Text = name,
						ImageIndex = imageIndex
					};
			tabControl1.TabPages.Add(tabPage);

			var textBox = new MemoEdit();
			textBox.TextChanged += textBox_TextChanged;
			textBox.KeyDown += textBox_KeyDown;
			textBox.Name = @"ColumnText";
			tabPage.Controls.Add(textBox);

			textBox.Properties.AcceptsReturn = true;
			textBox.Properties.AcceptsTab = true;
			textBox.AllowDrop = true;
			textBox.Dock = DockStyle.Fill;
			textBox.Properties.HideSelection = false;
			textBox.Properties.ScrollBars = ScrollBars.Vertical;
			textBox.TabIndex = 0;

			// --
			// Spell checker.

			var project = MainForm.Current.ProjectFilesControl.Project;

			if (project != null && project.UseSpellChecker)
			{
				var culture =
					new LanguageCodeDetection(project).DetectCultureFromFileName(
					GridEditableData.ParentSettings,
					name);

				var spellChecker = CultureHelper.CreateSpellChecker(culture);
				if (spellChecker != null)
				{
					spellChecker.ParentContainer = textBox;
					spellChecker.SetShowSpellCheckMenu(textBox, true);
				}
			}
		}

		private static void textBox_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Control && e.KeyCode == Keys.A)
			{
				((MemoEdit)sender).SelectAll();
				e.Handled = true;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void textBox_TextChanged(
			object sender,
			EventArgs e)
		{
			markDetailsContentAsModified();
			UpdateUI();
		}

		/// <summary>
		/// Occurs when [modify state changed].
		/// </summary>
		public event EventHandler ModifyStateChanged;

		public void MarkAsModified()
		{
			markDetailsContentAsModified();
			UpdateUI();
		}

		private void markDetailsContentAsModified()
		{
			_isDetailsContentModified = true;
			notifyModifyStateChanged();
		}

		/// <summary>
		/// Notifies the modify state changed.
		/// </summary>
		private void notifyModifyStateChanged()
		{
			if (ModifyStateChanged != null)
			{
				ModifyStateChanged(this, EventArgs.Empty);
			}

			// --

			if (GridEditableData != null)
			{
				var tabPage = (XtraTabPage)Parent;

				var text = GridEditableData.GetNameIntelligent(
					MainForm.Current.ProjectFilesControl.Project);

				if (IsModified)
				{
					text += @" " + Project.ModifiedChar;
				}

				tabPage.Text = text;
			}
		}

		/// <summary>
		/// Renames the tag.
		/// </summary>
		public void RenameTag()
		{
			var rowHandle = selectedRowHandle;

			using (var form = new RenameTagForm(DistinctTagNames))
			{
				var oldName = mainGridHelper.GetRowCellValue(rowHandle, 0) as string;
				form.TagName = oldName;

				if (form.ShowDialog(this) == DialogResult.OK)
				{
					var newName = form.TagName;

					//--
					// Rename visually.

					mainGridHelper.SetRowCellValue(rowHandle, 0, newName);

					// --
					// Rename in Dataobject

					_data.RenameTag(
						oldName,
						newName);

					MarkGridContentAsModified();
					UpdateUI();
				}
			}
		}

		public void MarkGridContentAsModified()
		{
			_isGridContentModified = true;
			notifyModifyStateChanged();
		}

		/// <summary>
		/// Deletes the tag.
		/// </summary>
		public void DeleteTag()
		{
			if (XtraMessageBox.Show(
				this,
				Resources.SR_MainForm_deleteTagToolStripMenuItemClick_DoYouReallyWantToDeleteTheTagAndAllOfItsTranslations,
				@"Zeta Resource Editor",
				MessageBoxButtons.YesNo,
				MessageBoxIcon.Question,
				MessageBoxDefaultButton.Button2
				) == DialogResult.Yes)
			{
				var rowHandles = new List<int>(selectedRowHandles);
				rowHandles.Sort((x, y) => -x.CompareTo(y));

				foreach (var rowHandle in rowHandles)
				{
					var row = (DataRowView)mainGridView.GetRow(rowHandle);
					var tagName = mainGridHelper.GetRowCellValue<string>(rowHandle, 0);

					// Remove visually.
					row.Delete();

					// Remove from the DataObject
					_data.DeleteTag(tagName);
				}

				MarkGridContentAsModified();
				UpdateUI();
			}
		}

		public void AddTag()
		{
			using (var form = new AddTagForm(DistinctTagNames))
			{
				if (form.ShowDialog(this) == DialogResult.OK)
				{
					var newTagName = form.TagName;

					//--
					// Add visually.

					var dataRow = createNewDataRow();
					dataRow[0] = newTagName;
					((DataTable)mainDataGrid.DataSource).Rows.Add(dataRow);

					// --
					// Add to DataObject

					_data.AddTag(
						newTagName);

					MarkGridContentAsModified();
					UpdateUI();
				}
			}
		}

		/// <summary>
		/// Save the files and clear the Grid and the other resources.
		/// </summary>
		private void closeDataGrid()
		{
			if (GridEditableData != null)
			{
				saveSplitterState();
				saveGridLayout();

				GridEditableData = null;
				_data = null;

				mainDataGrid.DataSource = null;
				mainDataGrid.Refresh();

				UpdateUI();
			}

			fileNameTextEdit.Text = null;
		}

		/// <summary>
		/// Updates the UserControls
		/// </summary>
		public override void UpdateUI()
		{
			base.UpdateUI();

			buttonAddTag.Enabled =
				CanAddTag;
			buttonDeleteTag.Enabled =
				CanDeleteTag;
			buttonEditTag.Enabled = CanRenameTag;
		}

		/// <summary>
		/// Get a list of all distinct tag names.
		/// </summary>
		public List<string> DistinctTagNames
		{
			get
			{
				var result = new List<string>();

				for (var i = 0; i < mainGridView.RowCount; ++i)
				{
					var row = (DataRowView)mainGridView.GetRow(i);
					var s = row[0] as string;

					if (!string.IsNullOrEmpty(s))
					{
						result.Add(s);
					}
				}

				return result;
			}
		}

		public bool CanSave
		{
			get
			{
				return _data != null;
			}
		}

		public bool CanResetLayout
		{
			get
			{
				return _data != null;
			}
		}

		public bool CanClose
		{
			get
			{
				return _data != null;
			}
		}

		public bool CanAddTag
		{
			get
			{
				return _data != null &&
					// Only allow to add when file group because otherwise
					// it cannot be determined for which file group to add.
					GridEditableData != null &&
						GridEditableData.SourceType == GridSourceType.FileGroup;
			}
		}

		public bool CanDeleteTag
		{
			get
			{
				return _data != null && hasSelectedRow;
			}
		}

		public bool CanRenameTag
		{
			get
			{
				return _data != null && hasSelectedRow;
			}
		}

		public bool CanAutoTranslateMissingTranslations
		{
			get
			{
				return _data != null && mainGridView.Columns.Count > 2;
			}
		}

		public bool CanOpenFolder
		{
			get
			{
				return _data != null;
			}
		}

		public bool CanFind
		{
			get
			{
				return _data != null;
			}
		}

		public bool CanFindNext
		{
			get
			{
				return _data != null &&
					!string.IsNullOrEmpty(_findText);
			}
		}

		internal IGridEditableData GridEditableData { get; private set; }

		public DataTable GetDataSource()
		{
			return (DataTable)mainDataGrid.DataSource;
		}

		/// <summary>
		/// 
		/// </summary>
		private DataRow createNewDataRow()
		{
			var table = (DataTable)mainDataGrid.DataSource;
			return table.NewRow();
		}

		/// <summary>
		/// 
		/// </summary>
		private void saveGridLayout()
		{
			if (_canSaveGridLayout)
			{
				var project = MainForm.Current.ProjectFilesControl.Project;
				if (project != null && layoutSerializer != null)
				{
					using (new SilentProjectStoreGuard(project))
					{
						layoutSerializer.Save();
					}
				}
			}
		}

		private AllLayoutSerializer layoutSerializer
		{
			get
			{
				if (_layoutSerializer == null)
				{
					var project = MainForm.Current.ProjectFilesControl.Project;
					if (project != null && project.PersistGridSettings)
					{
						_layoutSerializer =
							new AllLayoutSerializer(
								mainGridView,
								project.DynamicSettingsGlobalHierarchical,
								@"ResourceEditorGrid");
					}
				}

				return _layoutSerializer;
			}
		}

		private void restoreGridLayout()
		{
			var project = MainForm.Current.ProjectFilesControl.Project;
			if (project != null && layoutSerializer != null)
			{
				layoutSerializer.Restore();
			}
		}

		/// <summary>
		/// 
		/// </summary>
		private void updateDetailsFromGrid()
		{
			if (hasSelectedRow)
			{
				updateInGridButton.Enabled = true;
				var row = selectedRow;

				textBox1.Text = (string)row[0];

				for (var i = 1; i < mainGridView.Columns.Count; ++i)
				{
					var page = tabControl1.TabPages[i - 1];
					var text = row[i] as string;

					var columnText =
						(MemoEdit)page.Controls[@"ColumnText"];

					columnText.Text = DataProcessing.AdjustLineBreaks(text);
					columnText.Enabled = true;
				}
			}
			else
			{
				updateInGridButton.Enabled = false;
				textBox1.Text = string.Empty;

				foreach (XtraTabPage page in tabControl1.TabPages)
				{
					var columnText =
						(MemoEdit)page.Controls[@"ColumnText"];

					columnText.Text = string.Empty;
					columnText.Enabled = false;
				}
			}

			// Reset flag.
			markDetailsContentAsUnmodified();
		}

		public void ResetLayout()
		{
			_canSaveGridLayout = false;

			mainGridView.ClearColumnsFilter();
			mainGridView.ClearGrouping();
			mainGridView.ClearSorting();

			var project = MainForm.Current.ProjectFilesControl.Project;
			if (project != null && layoutSerializer != null)
			{
				using (new SilentProjectStoreGuard(project))
				{
					layoutSerializer.Reset();
				}
			}

			UpdateUI();
		}

		private bool _isGridContentModified;
		private bool _isDetailsContentModified;

		/// <summary>
		/// 
		/// </summary>
		private void updateGridFromDetails(
			int rowIndex)
		{
			if (_isDetailsContentModified)
			{
				var row =
					(DataRowView)
					mainGridView.GetRow(rowIndex);

				for (var i = 1; i < mainGridView.Columns.Count; ++i)
				{
					var page = tabControl1.TabPages[i - 1];
					var columnText =
						(MemoEdit)page.Controls[@"ColumnText"];

					row[i] = DataProcessing.AdjustLineBreaks(columnText.Text.Trim());
				}

				MarkGridContentAsModified();
			}

			markDetailsContentAsUnmodified();
		}

		private void markDetailsContentAsUnmodified()
		{
			_isDetailsContentModified = false;
			notifyModifyStateChanged();
		}

		private void mainDataView_CellValueChanged(
			object sender,
			CellValueChangedEventArgs e)
		{
			// Ignore during closing.
			if (mainDataGrid.DataSource != null)
			{
				MarkGridContentAsModified();

				// --

				var rowHandle = selectedRowHandle;

				// Force all other cells in this row to redraw.
				for (var i = 1; i < mainGridView.Columns.Count; ++i)
				{
					if (i != e.Column.AbsoluteIndex)
					{
						mainGridView.InvalidateRowCell(rowHandle, mainGridView.Columns[i]);
					}
				}

				// --

				var state = updateStateImage();
				GridEditableData.InMemoryState = state;
				MainForm.Current.NotifyFileGroupStateChanged(GridEditableData);
			}
		}

		/// <summary>
		/// Adjusts the color of the cell.
		/// </summary>
		/// <param name="e">The <see cref="DevExpress.XtraGrid.Views.Grid.RowCellStyleEventArgs"/> 
		/// instance containing the event data.</param>
		private void adjustCellColor(
			RowCellStyleEventArgs e)
		{
			// http://www.devexpress.com/Support/Center/KB/p/A2753.aspx
			var currentSkin = CommonSkins.GetSkin(
				MainForm.Current.DefaultLookAndFeel.LookAndFeel);

			var row =
				(DataRowView)
				mainGridView.GetRow(e.RowHandle);

			var isRowSelected = e.RowHandle == selectedRowHandle;

			// --

			if (DataProcessing.CommentsAreVisible(row.Row) &&
				e.Column.AbsoluteIndex == mainGridView.Columns.Count - 1)
			{
				// Reset.
				e.Appearance.ForeColor =
					isRowSelected
						? currentSkin.TranslateColor(SystemColors.HighlightText)
						: currentSkin.TranslateColor(Color.DarkGray);
			}
			else
			{
				// Reset.
				e.Appearance.ForeColor =
					isRowSelected
						? currentSkin.TranslateColor(SystemColors.HighlightText)
						: currentSkin.TranslateColor(SystemColors.WindowText);
			}

			// --

			if (e.Column.AbsoluteIndex == 0)
			{
				if (isCompleteRowEmpty(row))
				{
					e.Appearance.Font = italicFont;
					e.Appearance.ForeColor =
						isRowSelected
							? currentSkin.TranslateColor(SystemColors.HighlightText)
							: currentSkin.TranslateColor(SystemColors.ButtonShadow);
				}
				else
				{
					e.Appearance.Font = regularFont;
					e.Appearance.ForeColor =
						isRowSelected
							? currentSkin.TranslateColor(SystemColors.HighlightText)
							: currentSkin.TranslateColor(Color.DarkBlue);
				}
			}
			else
			{
				// --
				// Make empty cells colored.

				if (ConvertHelper.ToString(e.CellValue, string.Empty).Trim().Length <= 0)
				{
					if (!isRowSelected)
					{
						if (isCompleteRowEmpty(row))
						{
							e.Appearance.ForeColor =
								currentSkin.TranslateColor(SystemColors.ButtonShadow);

							var color =
								currentSkin.TranslateColor(
									SystemColors.ControlLight);

							e.Appearance.BackColor = color;
							e.Appearance.BackColor2 = color;
						}
						else
						{
							if (!DataProcessing.CommentsAreVisible(row.Row) ||
								e.Column.AbsoluteIndex != mainGridView.Columns.Count - 1)
							{
								var color =
									currentSkin.TranslateColor(
										Color.FromArgb(255, 233, 127));

								// http://www.codeproject.com/Messages/3403105/Re-Null-vs-empty-resource-value.aspx
								if (e.CellValue == null || DBNull.Value == e.CellValue)
								{
									if (colorifyNullValues)
									{
										color = Color.Lavender;
									}
								}

								e.Appearance.BackColor = color;
								e.Appearance.BackColor2 = color;
							}
						}
					}
				}

				// --
				// Make rows with different number of placeholders colored.

				// AJ CHANGE, don't count the comments column.
				if (e.Column.AbsoluteIndex >= 1 &&
					mainGridView.Columns.Count > (DataProcessing.CommentsAreVisible(row.Row) ? 3 : 2)
					)
				{
					var placeholderCount =
						FileGroup.ExtractPlaceholders(
							ConvertHelper.ToString(
								row[e.Column.AbsoluteIndex == 1 ? 2 : 1]));

					var c =
						FileGroup.ExtractPlaceholders(
							ConvertHelper.ToString(e.CellValue));

					if (c != placeholderCount)
					{
						e.Appearance.ForeColor =
							isRowSelected
								? currentSkin.TranslateColor(SystemColors.HighlightText)
								: currentSkin.TranslateColor(Color.Red);
					}
				}

				// --
				// Make translated cells that need to be reviewed different color.

				if (e.Column.AbsoluteIndex >= 1)
				{
					var value =
						ConvertHelper.ToString(e.CellValue);

					if (!string.IsNullOrEmpty(value) &&
						value.StartsWith(FileGroup.DefaultTranslatedPrefix))
					{
						e.Appearance.ForeColor =
						isRowSelected
							? currentSkin.TranslateColor(SystemColors.HighlightText)
							: currentSkin.TranslateColor(Color.Green);
						e.Appearance.Font = boldFont;
					}
					else if (!string.IsNullOrEmpty(value) &&
						value.StartsWith(FileGroup.DefaultTranslationErrorPrefix))
					{
						e.Appearance.ForeColor =
						isRowSelected
							? currentSkin.TranslateColor(SystemColors.HighlightText)
							: currentSkin.TranslateColor(Color.Red);
						e.Appearance.Font = boldFont;
					}
					else
					{
						e.Appearance.Font = regularFont;
					}
				}
			}
		}

		private static bool colorifyNullValues
		{
			get
			{
				var project = MainForm.Current.ProjectFilesControl.Project;
				return project != null && project.ColorifyNullCells;
			}
		}

		/// <summary>
		/// Gets the bold font.
		/// </summary>
		/// <value>The bold font.</value>
		private Font boldFont
		{
			get
			{
				// ReSharper disable ConvertIfStatementToNullCoalescingExpression
				if (_boldFont == null)
				// ReSharper restore ConvertIfStatementToNullCoalescingExpression
				{
					_boldFont = new Font(Font, FontStyle.Bold);
				}

				return _boldFont;
			}
		}

		private Font regularFont
		{
			get
			{
				// ReSharper disable ConvertIfStatementToNullCoalescingExpression
				if (_regularFont == null)
				// ReSharper restore ConvertIfStatementToNullCoalescingExpression
				{
					_regularFont = new Font(Font, FontStyle.Regular);
				}

				return _regularFont;
			}
		}

		private Font italicFont
		{
			get
			{
				// ReSharper disable ConvertIfStatementToNullCoalescingExpression
				if (_italicFont == null)
				// ReSharper restore ConvertIfStatementToNullCoalescingExpression
				{
					_italicFont = new Font(Font, FontStyle.Italic);
				}

				return _italicFont;
			}
		}

		/*
				private Font boldItalicFont
				{
					get
					{
						// ReSharper disable ConvertIfStatementToNullCoalescingExpression
						if (_boldItalicFont == null)
						// ReSharper restore ConvertIfStatementToNullCoalescingExpression
						{
							_boldItalicFont = new Font(Font, FontStyle.Bold | FontStyle.Italic);
						}

						return _boldItalicFont;
					}
				}
		*/

		private bool isCompleteRowEmpty(DataRowView row)
		{
			if (row == null)
			{
				return false;
			}
			else
			{
				// Check both, grid and underlying table, because depending
				// on the loading stage of the grid, the grid can still be empty.

				if (mainGridView != null && mainGridView.Columns != null)
				{
					for (var i = 1; i < mainGridView.Columns.Count; ++i)
					{
						if (ConvertHelper.ToString(row[i], string.Empty).Trim().Length > 0)
						{
							return false;
						}
					}
				}

				// --

				if (row.Row.Table != null)
				{
					for (var i = 1; i < row.Row.Table.Columns.Count; ++i)
					{
						if (ConvertHelper.ToString(row[i], string.Empty).Trim().Length > 0)
						{
							return false;
						}
					}
				}

				return true;
			}
		}

		private GridViewHelper _mainGridHelper;

		private GridViewHelper mainGridHelper
		{
			get
			{
				// ReSharper disable ConvertIfStatementToNullCoalescingExpression
				if (_mainGridHelper == null)
				// ReSharper restore ConvertIfStatementToNullCoalescingExpression
				{
					_mainGridHelper = new GridViewHelper(mainGridView);
				}

				return _mainGridHelper;
			}
		}

		public bool AllowUpdatingDetails
		{
			get
			{
				return _allowUpdatingDetails;
			}
			set
			{
				if (_allowUpdatingDetails != value)
				{
					_allowUpdatingDetails = value;

					// Do once when enabled back.
					if (value)
					{
						doUpdateDetails();
						UpdateUI();
					}
				}
			}
		}

		private int _currentRowIndex = -1;

		private string _findText;
		private bool _isLoaded;
		private bool _restoredSplitContainer;
		private Font _boldFont;
		private Font _regularFont;
		private Font _italicFont;
		/*
				private Font _boldItalicFont;
		*/

		public void Find()
		{
			using (var form = new FindForm())
			{
				form.TextToFind = _findText;

				if (form.ShowDialog(this) == DialogResult.OK)
				{
					_findText = form.TextToFind;
					if (!FindNext())
					{
						XtraMessageBox.Show(
							Resources.SR_ResourceEditorUserControl_Find_TheTextWasNotFound,
							@"Zeta Resource Editor",
							MessageBoxButtons.OK,
							MessageBoxIcon.Information);
					}
				}
			}
		}

		public bool FindNext()
		{
			var index = new Point();

			if (hasSelectedRow)
			{
				var cells = mainGridView.GetSelectedCells();
				if (cells.Length > 0)
				{
					index.X = 0;//cells[0].Column.AbsoluteIndex;
					index.Y = selectedRowHandle;
				}
				else
				{
					index.X = 0;
					index.Y = selectedRowHandle;
				}
			}
			else
			{
				index.X = 0;
				index.Y = 0;
			}

			// --

			// Only search if inside range.
			if (index.X < mainGridView.Columns.Count &&
				index.Y < mainGridView.RowCount)
			{
				var startingIndex = index;

				index = incrementGridIndex(index, true);

				while (index != startingIndex)
				{
					var text = ConvertHelper.ToString(
						mainGridHelper.GetRowCellValue(index.Y, index.X));

					if (!string.IsNullOrEmpty(text))
					{
						var pos = text.IndexOf(
							_findText,
							StringComparison.InvariantCultureIgnoreCase);

						if (pos >= 0)
						{
							mainGridView.ClearSelection();
							mainGridHelper.SelectCell(index.Y, index.X);
							mainGridHelper.FocusCell(index.Y, index.X);
							//break;
							return true;
						}
					}

					index = incrementGridIndex(index, false);
				}
			}

			return false;
		}

		/// <summary>
		/// Increments the index of the grid.
		/// </summary>
		/// <param name="index">The index.</param>
		/// <param name="wholeRowsOnly">if set to <c>true</c> [whole rows only].</param>
		/// <returns></returns>
		private Point incrementGridIndex(
			Point index,
			bool wholeRowsOnly)
		{
			index.X++;

			if (wholeRowsOnly || index.X >= mainGridView.Columns.Count)
			{
				index.X = 0;
				index.Y++;
			}

			if (index.Y >= mainGridView.RowCount)
			{
				index.Y = 0;
			}

			return index;
		}

		/// <summary>
		/// Opens the folder.
		/// </summary>
		public void OpenFolder()
		{
			var info =
				new ProcessStartInfo
				{
					FileName = GridEditableData.FolderPath.FullName,
					UseShellExecute = true
				};

			Process.Start(info);
		}

		/// <summary>
		/// Closes the and save data grid.
		/// </summary>
		/// <returns></returns>
		public bool CloseAndSaveDataGrid()
		{
			if (DoSaveFiles(
				SaveOptions.OnlyIfModified |
					SaveOptions.AskConfirm) == DialogResult.OK)
			{
				closeDataGrid();
				return true;
			}
			else
			{
				return false;
			}
		}

		internal bool SaveState()
		{
			return SaveState(
				SaveOptions.OnlyIfModified |
					SaveOptions.AskConfirm);
		}

		/// <summary>
		/// Saves the state.
		/// </summary>
		/// <param name="options">The options.</param>
		/// <returns>Returns FALSE if cancel requested.</returns>
		internal bool SaveState(
			SaveOptions options)
		{
			FormHelper.SaveValue(
				MainForm.UserStorageIntelligent,
				@"FindText", _findText);

			if (_data != null)
			{
				var r = DoSaveFiles(options);

				if (r != DialogResult.OK)
				{
					return false;
				}
			}

			//--

			saveGridLayout();
			saveSplitterState();

			FormBase.SaveState(tabControl1);

			return true;
		}

		private void saveSplitterState()
		{
			FormBase.SaveState(
				resourceEditorUserControlMainSplitContainer);
		}

		private void restoreSplitterState()
		{
			FormBase.RestoreState(
				resourceEditorUserControlMainSplitContainer);
		}

		private FileGroupStates updateStateImage()
		{

			var table = getTable();
			var state = FileGroup.DoCalculateEditingState(table);
			var key = (int)FileGroup.TranslateStateToColorKey(state);

			statusPictureBox.Image = stateImageList.Images[key];

			return state;
		}

		private DataTable getTable()
		{
			var table = new DataTable();

			foreach (GridColumn column in mainGridView.Columns)
			{
				table.Columns.Add(column.Name);
			}

			for (var rowHandle = 0; rowHandle < mainGridView.RowCount; ++rowHandle)
			{
				var row = table.NewRow();

				foreach (GridColumn column in mainGridView.Columns)
				{
					row[column.Name] = mainGridView.GetRowCellValue(rowHandle, column);
				}

				table.Rows.Add(row);
			}


			return table;
		}

		private void buttonAddTag_ItemClick(object sender, ItemClickEventArgs e)
		{
			AddTag();
			UpdateUI();
		}

		private void buttonEditTag_ItemClick(object sender, ItemClickEventArgs e)
		{
			RenameTag();
			UpdateUI();
		}

		private void buttonDeleteTag_ItemClick(object sender, ItemClickEventArgs e)
		{
			DeleteTag();
			UpdateUI();
		}

		private void mainGridView_MouseUp(object sender, MouseEventArgs e)
		{
			// http://www.devexpress.com/Support/Center/KB/p/A915.aspx.

			if (e.Button == MouseButtons.Right &&
				ModifierKeys == Keys.None)
			{
				var pt = mainDataGrid.PointToClient(MousePosition);
				var info = mainGridView.CalcHitInfo(pt);

				if (info.RowHandle >= 0)
				{
					mainGridView.ClearSelection();
					mainGridHelper.SelectRow(info.RowHandle);

					UpdateUI();

					optionsPopupMenu.ShowPopup(MousePosition);
				}
				else
				{
					mainGridView.ClearSelection();

					UpdateUI();

					optionsPopupMenu.ShowPopup(MousePosition);
				}
			}
		}

		private readonly Dictionary<CultureInfo, SpellChecker> _gridSpellCheckers =
			new Dictionary<CultureInfo, SpellChecker>();

		private bool _canSaveGridLayout;
		private AllLayoutSerializer _layoutSerializer;

		private void mainGridView_ShownEditor(object sender, EventArgs e)
		{
			var project = MainForm.Current.ProjectFilesControl.Project;

			if (project != null && project.UseSpellChecker)
			{
				var name = mainGridView.FocusedColumn.Caption;
				var culture = new LanguageCodeDetection(project).DetectCultureFromFileName(
					GridEditableData.ParentSettings,
					name);

				SpellChecker gridSpellChecker;
				if (!_gridSpellCheckers.TryGetValue(culture, out gridSpellChecker))
				{
					gridSpellChecker = CultureHelper.CreateSpellChecker(culture);
					if (gridSpellChecker != null)
					{
						gridSpellChecker.ParentContainer = mainDataGrid;
					}

					_gridSpellCheckers[culture] = gridSpellChecker;
				}

				if (gridSpellChecker != null)
				{
					gridSpellChecker.SetShowSpellCheckMenu(
					   mainGridView.ActiveEditor,
					   true);
				}
			}
		}

		private void mainGridView_CustomRowFilter(
			object sender,
			RowFilterEventArgs e)
		{
			var project = MainForm.Current.ProjectFilesControl.Project;

			if (project != null && project.HideEmptyRows)
			{
				var row =
					(DataRowView)
					mainGridView.GetRow(e.ListSourceRow);

				if (isCompleteRowEmpty(row))
				{
					e.Visible = false;
					e.Handled = true;
				}
				else
				{
					//e.Visible = true;
					//e.Handled = true;
				}
			}
			else if (project != null && project.HideInternalDesignerRows)
			{
				var row =
					(DataRowView)
					mainGridView.GetRow(e.ListSourceRow);

				if (row != null &&
					ConvertHelper.ToString(row[0], string.Empty).StartsWith(@">>"))
				{
					e.Visible = false;
					e.Handled = true;
				}
				else
				{
					//e.Visible = true;
					//e.Handled = true;
				}
			}
			else
			{
				//e.Visible = true;
				//e.Handled = true;
			}

			// Immediately store.
			saveGridLayout();
		}

		private void startDoUpdateDetails()
		{
			updateDetailsTimer.Stop();
			updateDetailsTimer.Start();
		}

		private void updateDetailsTimer_Tick(object sender, EventArgs e)
		{
			updateDetailsTimer.Stop();
			doUpdateDetails();
		}

		private void mainGridView_EndSorting(object sender, EventArgs e)
		{
			// Immediately store.
			saveGridLayout();
		}
	}
}