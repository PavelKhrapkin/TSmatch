﻿namespace ZetaResourceEditor.Code.Helper
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System;
	using System.Collections.Generic;
	using System.Diagnostics;
	using System.Globalization;
	using System.IO;
	using System.Text.RegularExpressions;
	using DL;

	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// Methods for dealing with file names.
	/// </summary>
	public sealed class LanguageCodeDetection
	{
		#region Private variables.
		// ------------------------------------------------------------------

		private readonly Project _project;
		private const string PhBasename = @"[basename]";
		private const string PhLanguagecode = @"[languagecode]";
		private const string PhExtension = @"[extension]";
		private const string PhOptionaltypes = @"[optionaldefaulttypes]";

		// ------------------------------------------------------------------
		#endregion

		#region Public methods and properties.
		// ------------------------------------------------------------------

		public LanguageCodeDetection(
			Project project)
		{
			_project = project;
		}

		public Project Project
		{
			get
			{
				return _project;
			}
		}

		/// <summary>
		/// Gets the base name.
		/// </summary>
		/// <remarks>
		/// E.g. for:
		///  - Main.master.resx
		///  - Main.master.de.resx
		///  - Main.master.en-us.resx
		/// it would be "Main.master"
		/// 
		/// E.g. for:
		///  - Properties.resx
		///  - Properties.de.resx
		/// it would be "Properties".
		/// </remarks>
		/// <value>The base name.</value>
		public string GetBaseName(
			FileGroup fileGroup)
		{
			string baseName;
			string extension;
			string optionalDefaultType;

			doGetBaseName(
				fileGroup,
				out baseName,
				out extension,
				out optionalDefaultType);
			return baseName;
		}

		public string GetBaseExtension(
			FileGroup fileGroup)
		{
			string baseName;
			string extension;
			string optionalDefaultType;

			doGetBaseName(
				fileGroup,
				out baseName,
				out extension,
				out optionalDefaultType);
			return extension;
		}

		public string GetBaseOptionalDefaultType(
			FileGroup fileGroup)
		{
			string baseName;
			string extension;
			string optionalDefaultType;

			doGetBaseName(
				fileGroup,
				out baseName,
				out extension,
				out optionalDefaultType);
			return optionalDefaultType;
		}

		//public string DetectLanguageCodeFromFileName(
		//    string filePath)
		//{
		//    var fileName = Path.GetFileNameWithoutExtension(filePath);

		//    if (fileName.Contains(@"."))
		//    {
		//        var type =
		//            Path.GetExtension(fileName).Trim('.').ToLowerInvariant();

		//        if (IsValidCultureName(type))
		//        {
		//            return type;
		//        }
		//        else
		//        {
		//            return _project == null ? string.Empty : settings.EffectiveNeutralLanguageCode;
		//        }
		//    }
		//    else
		//    {
		//        return _project == null ? string.Empty : settings.EffectiveNeutralLanguageCode;
		//    }
		//}

		public static bool IsValidCultureName(
			string cultureName)
		{
			if (string.IsNullOrEmpty(cultureName) || cultureName.Length > 5)
			{
				return false;
			}
			else
			{
				try
				{
					CultureInfo.GetCultureInfo(cultureName);
					return true;
				}
				catch (ArgumentException)
				{
					// Found no CultureInfo.TryParse, therefore use the catch.
					return false;
				}
			}
		}

		public CultureInfo DetectCultureFromFileName(
			IInheritedSettings settings,
			string fileName)
		{
			var culture =
				DetectLanguageCodeFromFileName(
					settings,
					fileName);

			return new CultureInfo(culture);
		}

		public string DetectLanguageCodeFromFileName(
			IInheritedSettings settings,
			string fileName)
		{
			if (string.IsNullOrEmpty(fileName))
			{
				return settings.EffectiveNeutralLanguageCode;
			}
			else
			{
				fileName = Path.GetFileName(fileName);
				fileName = removeOptionalDefaultTypes(settings, fileName, null);

				// Check for non-neutral, first.
				if (IsNonNeutralLanguageFileName(settings, fileName))
				{
					return extractBlock(settings, fileName, PhLanguagecode);
				}
				else
				{
					// Is neutral language.
					return settings.EffectiveNeutralLanguageCode;
				}
			}
		}

		//CHANGED extract language string inside next to last point delimited part
		//returns culture string like de-DE or null or empty if neutral file guessed
		public string GetLanguageCodeFromFileNameSuffix(
			IInheritedSettings settings,
			string fileName
			)
		{
			var cultureString = string.Empty;
			if (string.IsNullOrEmpty(fileName))
			{
				return null; //no suffix found
			}
			else
			{
				fileName = Path.GetFileName(fileName);
				fileName = Path.GetFileNameWithoutExtension(fileName);
				fileName = removeOptionalDefaultTypes(settings, fileName, null);

				var baseName = fileName.ToLowerInvariant();

				if (!string.IsNullOrEmpty(baseName))
				{
					var pPos = fileName.LastIndexOf('.');
					if (pPos > -1 && pPos < fileName.Length - 1)
					{
						var possibleCulture = fileName.Substring(pPos + 1);
						if (!string.IsNullOrEmpty(possibleCulture))
						{
							if (IsValidCultureName(possibleCulture))
							{
								cultureString = fileName.Substring(pPos + 1);
							}
						}
					}
				}
			}
			return cultureString;
		}

		//CHANGED extract language string inside next to last point delimited part
		//returns culture string like de-DE or null or empty if neutral file guessed
		public string GetBaseName(
			IInheritedSettings settings,
			string fileName
			)
		{
			return extractBlock(settings, fileName, PhBasename);
		}

		public bool IsNeutralLanguageFileName(
			IInheritedSettings settings,
			string filePath)
		{
			//CHANGED just invert decision
			return !IsNonNeutralLanguageFileName(settings, filePath);
		}

		public bool IsNonNeutralLanguageFileName(
			IInheritedSettings settings,
			string filePath)
		{
			var fn = Path.GetFileName(filePath);
			var baseDotCount = settings == null ? 0 : settings.EffectiveBaseNameDotCount;

			//CHANGED: special case if settings.EffectiveBaseNameDotCount < 0, guess culture from name:
			if (settings == null || baseDotCount < 0)
			{
				var cultureString = GetLanguageCodeFromFileNameSuffix(settings, filePath);
				return !string.IsNullOrEmpty(cultureString);
			}
			else
			{
				var nonNeutralDotCount =
					getDotCount(settings.EffectiveNonNeutralLanguageFileNamePattern);

				var dc = getDotCount(fn);

				return dc == nonNeutralDotCount + baseDotCount;
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Private implementation.
		// ------------------------------------------------------------------

		private void doGetBaseName(
			IGridEditableData fileGroup,
			out string baseName,
			out string extension,
			out string removedType)
		{
			Debug.Assert(fileGroup == null || fileGroup != null);

			if (fileGroup == null || fileGroup.FilePaths.Length <= 0)
			{
				baseName = null;
				extension = null;
				removedType = null;
			}
			else
			{
				var fileName = Path.GetFileName(fileGroup.FilePaths[0]);

				var removedTypes = new List<string>();

				fileName = removeOptionalDefaultTypes(fileGroup.ParentSettings, fileName, removedTypes);
				//CHANGED: using new common method. Extract all names by reverse pattern resolve
				baseName = GetBaseName(fileGroup.ParentSettings, fileName);
				extension = extractBlock(fileGroup.ParentSettings, fileName, PhExtension);
				removedType = (removedTypes.Count > 0 ? removedTypes[0] : null) ?? string.Empty;
			}
		}

		private static string removeOptionalDefaultTypes(
			IInheritedSettings settings,
			string fileName,
			ICollection<string> removedTypes)
		{
			if (settings == null || string.IsNullOrEmpty(fileName))
			{
				return fileName;
			}
			else
			{
				var odfts = settings.EffectiveDefaultFileTypesToIgnoreArray;
				if (odfts.Length > 0)
				{
					foreach (var odft in odfts)
					{
						var p =
							string.Format(
								@"\b({0})\b",
								Regex.Escape(odft));

						var before = fileName;
						fileName = Regex.Replace(fileName, p, string.Empty, RegexOptions.IgnoreCase);

						if (fileName != before && removedTypes != null)
						{
							removedTypes.Add(odft);
						}
					}

					return fileName;
				}
				else
				{
					return fileName;
				}
			}
		}

		private string extractBlock(
			IInheritedSettings settings,
			string text,
			string after)
		{
			if (string.IsNullOrEmpty(text))
			{
				return text; //no suffix found
			}
			else
			{
				var patternOrigin =
					IsNonNeutralLanguageFileName(settings, text)
						? settings.EffectiveNonNeutralLanguageFileNamePattern
						: settings.EffectiveNeutralLanguageFileNamePattern;

				var optionalTypes = new List<string>();
				text = removeOptionalDefaultTypes(settings, text, optionalTypes);
				if (after == PhOptionaltypes)
				{
					return (optionalTypes.Count > 0 ? optionalTypes[0] : null) ?? string.Empty;
				}
				//remove pattern:
				patternOrigin = patternOrigin.Replace(PhOptionaltypes, string.Empty);

				if (!patternOrigin.Contains(after))
				{
					if (after == PhLanguagecode)
					{
						//special case neutral cuture
						return settings.EffectiveNeutralLanguageCode;
					}
				}

				var pattern = patternOrigin;
				var block = text;
				string leftBlock;
				string rightBlock;
				string leftPattern;
				string rightPattern;

				//trim right
				while (!string.IsNullOrEmpty(block) && !string.IsNullOrEmpty(pattern) && pattern.Contains(after))
				{
					splitBlockRight(pattern, @".", out leftPattern, out rightPattern);
					splitBlockRight(block, @".", out leftBlock, out rightBlock);
					if (rightPattern == PhBasename)
					{
						//we must trim from left now because basename may expand multiple blocks
						break;
					}
					if (rightPattern == after)
					{
						//we are done
						return rightBlock;
					}
					pattern = leftPattern;
					block = leftBlock;
				}

				//trim left
				while (!string.IsNullOrEmpty(block) && !string.IsNullOrEmpty(pattern) && pattern.Contains(after))
				{
					splitBlockLeft(pattern, @".", out leftPattern, out rightPattern);
					splitBlockLeft(block, @".", out leftBlock, out rightBlock);

					if (leftPattern == after)
					{
						if (leftPattern == PhBasename && string.IsNullOrEmpty(rightPattern))
						{
							//return remaining block
							return block;
						}
						//we are done
						return leftBlock;
					}
					pattern = rightPattern;
					block = rightBlock;
				}

				//if we gets here, we have problems with pattern.
				throw new ArgumentException(
					string.Format(
						"pattern {0}/{1} doesn't match {2}", after, patternOrigin, text));
			}
		}

		private static void splitBlockRight(
			string text,
			string separator,
			out string left,
			out string right)
		{
			if (string.IsNullOrEmpty(text))
			{
				left = text;
				right = text;
			}
			else
			{
				var separatorPos = text.LastIndexOf(separator);
				if (separatorPos < 0)
				{
					left = string.Empty;
					right = text;
				}
				else
				{
					right = text.Substring(separatorPos + 1);
					left = text.Substring(0, separatorPos);
				}
			}
		}

		private static void splitBlockLeft(
			string text,
			string separator,
			out string left,
			out string right)
		{
			if (string.IsNullOrEmpty(text))
			{
				left = text;
				right = text;
			}
			else
			{
				var separatorPos = text.IndexOf(separator);
				if (separatorPos < 0)
				{
					left = text;
					right = string.Empty;
				}
				else
				{
					left = text.Substring(0, separatorPos);
					right = text.Substring(separatorPos + 1);
				}
			}
		}

		private static int getDotCount(
			string text)
		{
			if (string.IsNullOrEmpty(text))
			{
				return 0;
			}
			else
			{
				var count = 0;

				foreach (var c in text)
				{
					if (c == '.')
					{
						count++;
					}
				}

				return count;
			}
		}

		public bool IsNeutralCulture(
			IInheritedSettings settings,
			CultureInfo culture)
		{
			return culture ==
				   new CultureInfo(
					settings.EffectiveNeutralLanguageCode);
		}

		// ------------------------------------------------------------------
		#endregion
	}

	/////////////////////////////////////////////////////////////////////////
}