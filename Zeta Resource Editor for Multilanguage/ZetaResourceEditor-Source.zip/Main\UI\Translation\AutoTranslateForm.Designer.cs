﻿namespace ZetaResourceEditor.UI.Translation
{
	partial class AutoTranslateForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose( bool disposing )
		{
			if ( disposing && (components != null) )
			{
				components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AutoTranslateForm));
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.updateUITimer = new System.Windows.Forms.Timer(this.components);
			this.groupBox1 = new DevExpress.XtraEditors.GroupControl();
			this.buttonDefault = new DevExpress.XtraEditors.SimpleButton();
			this.prefixTextBox = new DevExpress.XtraEditors.TextEdit();
			this.prefixCheckBox = new DevExpress.XtraEditors.CheckEdit();
			this.buttonAll = new DevExpress.XtraEditors.SimpleButton();
			this.buttonInvert = new DevExpress.XtraEditors.SimpleButton();
			this.buttonNone = new DevExpress.XtraEditors.SimpleButton();
			this.languagesToTranslateCheckListBox = new DevExpress.XtraEditors.CheckedListBoxControl();
			this.referenceLanguageGroupBox = new DevExpress.XtraEditors.ComboBoxEdit();
			this.fileGroupTextBox = new DevExpress.XtraEditors.TextEdit();
			this.label3 = new DevExpress.XtraEditors.LabelControl();
			this.label2 = new DevExpress.XtraEditors.LabelControl();
			this.label1 = new DevExpress.XtraEditors.LabelControl();
			this.buttonTranslate = new DevExpress.XtraEditors.SimpleButton();
			this.buttonCancel = new DevExpress.XtraEditors.SimpleButton();
			this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
			this.buttonSettings = new DevExpress.XtraEditors.SimpleButton();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.groupBox1)).BeginInit();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.prefixTextBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.prefixCheckBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.languagesToTranslateCheckListBox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.referenceLanguageGroupBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.fileGroupTextBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
			this.panelControl1.SuspendLayout();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.AccessibleDescription = null;
			this.pictureBox1.AccessibleName = null;
			resources.ApplyResources(this.pictureBox1, "pictureBox1");
			this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox1.BackgroundImage = null;
			this.pictureBox1.Font = null;
			this.pictureBox1.ImageLocation = null;
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.TabStop = false;
			// 
			// updateUITimer
			// 
			this.updateUITimer.Tick += new System.EventHandler(this.updateUITimer_Tick);
			// 
			// groupBox1
			// 
			this.groupBox1.AccessibleDescription = null;
			this.groupBox1.AccessibleName = null;
			resources.ApplyResources(this.groupBox1, "groupBox1");
			this.groupBox1.Controls.Add(this.buttonDefault);
			this.groupBox1.Controls.Add(this.prefixTextBox);
			this.groupBox1.Controls.Add(this.prefixCheckBox);
			this.groupBox1.Controls.Add(this.buttonAll);
			this.groupBox1.Controls.Add(this.buttonInvert);
			this.groupBox1.Controls.Add(this.buttonNone);
			this.groupBox1.Controls.Add(this.languagesToTranslateCheckListBox);
			this.groupBox1.Controls.Add(this.referenceLanguageGroupBox);
			this.groupBox1.Controls.Add(this.fileGroupTextBox);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.pictureBox1);
			this.groupBox1.Name = "groupBox1";
			// 
			// buttonDefault
			// 
			this.buttonDefault.AccessibleDescription = null;
			this.buttonDefault.AccessibleName = null;
			resources.ApplyResources(this.buttonDefault, "buttonDefault");
			this.buttonDefault.BackgroundImage = null;
			this.buttonDefault.Name = "buttonDefault";
			this.buttonDefault.Click += new System.EventHandler(this.buttonDefault_Click);
			// 
			// prefixTextBox
			// 
			resources.ApplyResources(this.prefixTextBox, "prefixTextBox");
			this.prefixTextBox.BackgroundImage = null;
			this.prefixTextBox.EditValue = null;
			this.prefixTextBox.Name = "prefixTextBox";
			this.prefixTextBox.Properties.AccessibleDescription = null;
			this.prefixTextBox.Properties.AccessibleName = null;
			this.prefixTextBox.Properties.AutoHeight = ((bool)(resources.GetObject("prefixTextBox.Properties.AutoHeight")));
			this.prefixTextBox.Properties.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("prefixTextBox.Properties.Mask.AutoComplete")));
			this.prefixTextBox.Properties.Mask.BeepOnError = ((bool)(resources.GetObject("prefixTextBox.Properties.Mask.BeepOnError")));
			this.prefixTextBox.Properties.Mask.EditMask = resources.GetString("prefixTextBox.Properties.Mask.EditMask");
			this.prefixTextBox.Properties.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("prefixTextBox.Properties.Mask.IgnoreMaskBlank")));
			this.prefixTextBox.Properties.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("prefixTextBox.Properties.Mask.MaskType")));
			this.prefixTextBox.Properties.Mask.PlaceHolder = ((char)(resources.GetObject("prefixTextBox.Properties.Mask.PlaceHolder")));
			this.prefixTextBox.Properties.Mask.SaveLiteral = ((bool)(resources.GetObject("prefixTextBox.Properties.Mask.SaveLiteral")));
			this.prefixTextBox.Properties.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("prefixTextBox.Properties.Mask.ShowPlaceHolders")));
			this.prefixTextBox.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("prefixTextBox.Properties.Mask.UseMaskAsDisplayFormat")));
			this.prefixTextBox.Properties.NullValuePrompt = resources.GetString("prefixTextBox.Properties.NullValuePrompt");
			this.prefixTextBox.Properties.NullValuePromptShowForEmptyValue = ((bool)(resources.GetObject("prefixTextBox.Properties.NullValuePromptShowForEmptyValue")));
			this.prefixTextBox.TextChanged += new System.EventHandler(this.prefixTextBox_TextChanged);
			// 
			// prefixCheckBox
			// 
			resources.ApplyResources(this.prefixCheckBox, "prefixCheckBox");
			this.prefixCheckBox.BackgroundImage = null;
			this.prefixCheckBox.Name = "prefixCheckBox";
			this.prefixCheckBox.Properties.AccessibleDescription = null;
			this.prefixCheckBox.Properties.AccessibleName = null;
			this.prefixCheckBox.Properties.AutoHeight = ((bool)(resources.GetObject("prefixCheckBox.Properties.AutoHeight")));
			this.prefixCheckBox.Properties.AutoWidth = true;
			this.prefixCheckBox.Properties.Caption = resources.GetString("prefixCheckBox.Properties.Caption");
			this.prefixCheckBox.Properties.DisplayValueChecked = resources.GetString("prefixCheckBox.Properties.DisplayValueChecked");
			this.prefixCheckBox.Properties.DisplayValueGrayed = resources.GetString("prefixCheckBox.Properties.DisplayValueGrayed");
			this.prefixCheckBox.Properties.DisplayValueUnchecked = resources.GetString("prefixCheckBox.Properties.DisplayValueUnchecked");
			this.prefixCheckBox.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
			// 
			// buttonAll
			// 
			this.buttonAll.AccessibleDescription = null;
			this.buttonAll.AccessibleName = null;
			resources.ApplyResources(this.buttonAll, "buttonAll");
			this.buttonAll.BackgroundImage = null;
			this.buttonAll.Name = "buttonAll";
			this.buttonAll.Click += new System.EventHandler(this.buttonAll_Click);
			// 
			// buttonInvert
			// 
			this.buttonInvert.AccessibleDescription = null;
			this.buttonInvert.AccessibleName = null;
			resources.ApplyResources(this.buttonInvert, "buttonInvert");
			this.buttonInvert.BackgroundImage = null;
			this.buttonInvert.Name = "buttonInvert";
			this.buttonInvert.Click += new System.EventHandler(this.buttonInvert_Click);
			// 
			// buttonNone
			// 
			this.buttonNone.AccessibleDescription = null;
			this.buttonNone.AccessibleName = null;
			resources.ApplyResources(this.buttonNone, "buttonNone");
			this.buttonNone.BackgroundImage = null;
			this.buttonNone.Name = "buttonNone";
			this.buttonNone.Click += new System.EventHandler(this.buttonNone_Click);
			// 
			// languagesToTranslateCheckListBox
			// 
			this.languagesToTranslateCheckListBox.AccessibleDescription = null;
			this.languagesToTranslateCheckListBox.AccessibleName = null;
			resources.ApplyResources(this.languagesToTranslateCheckListBox, "languagesToTranslateCheckListBox");
			this.languagesToTranslateCheckListBox.BackgroundImage = null;
			this.languagesToTranslateCheckListBox.Name = "languagesToTranslateCheckListBox";
			this.languagesToTranslateCheckListBox.SelectedIndexChanged += new System.EventHandler(this.languagesToTranslateCheckListBox_SelectedIndexChanged);
			this.languagesToTranslateCheckListBox.ItemCheck += new DevExpress.XtraEditors.Controls.ItemCheckEventHandler(this.languagesToTranslateCheckListBox_ItemCheck);
			// 
			// referenceLanguageGroupBox
			// 
			resources.ApplyResources(this.referenceLanguageGroupBox, "referenceLanguageGroupBox");
			this.referenceLanguageGroupBox.BackgroundImage = null;
			this.referenceLanguageGroupBox.EditValue = null;
			this.referenceLanguageGroupBox.Name = "referenceLanguageGroupBox";
			this.referenceLanguageGroupBox.Properties.AccessibleDescription = null;
			this.referenceLanguageGroupBox.Properties.AccessibleName = null;
			this.referenceLanguageGroupBox.Properties.AutoHeight = ((bool)(resources.GetObject("referenceLanguageGroupBox.Properties.AutoHeight")));
			this.referenceLanguageGroupBox.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("referenceLanguageGroupBox.Properties.Buttons"))))});
			this.referenceLanguageGroupBox.Properties.DropDownRows = 20;
			this.referenceLanguageGroupBox.Properties.NullValuePrompt = resources.GetString("referenceLanguageGroupBox.Properties.NullValuePrompt");
			this.referenceLanguageGroupBox.Properties.NullValuePromptShowForEmptyValue = ((bool)(resources.GetObject("referenceLanguageGroupBox.Properties.NullValuePromptShowForEmptyValue")));
			this.referenceLanguageGroupBox.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.referenceLanguageGroupBox.Properties.SelectedIndexChanged += new System.EventHandler(this.referenceLanguageGroupBox_SelectedIndexChanged);
			// 
			// fileGroupTextBox
			// 
			resources.ApplyResources(this.fileGroupTextBox, "fileGroupTextBox");
			this.fileGroupTextBox.BackgroundImage = null;
			this.fileGroupTextBox.EditValue = null;
			this.fileGroupTextBox.Name = "fileGroupTextBox";
			this.fileGroupTextBox.Properties.AccessibleDescription = null;
			this.fileGroupTextBox.Properties.AccessibleName = null;
			this.fileGroupTextBox.Properties.AutoHeight = ((bool)(resources.GetObject("fileGroupTextBox.Properties.AutoHeight")));
			this.fileGroupTextBox.Properties.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("fileGroupTextBox.Properties.Mask.AutoComplete")));
			this.fileGroupTextBox.Properties.Mask.BeepOnError = ((bool)(resources.GetObject("fileGroupTextBox.Properties.Mask.BeepOnError")));
			this.fileGroupTextBox.Properties.Mask.EditMask = resources.GetString("fileGroupTextBox.Properties.Mask.EditMask");
			this.fileGroupTextBox.Properties.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("fileGroupTextBox.Properties.Mask.IgnoreMaskBlank")));
			this.fileGroupTextBox.Properties.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("fileGroupTextBox.Properties.Mask.MaskType")));
			this.fileGroupTextBox.Properties.Mask.PlaceHolder = ((char)(resources.GetObject("fileGroupTextBox.Properties.Mask.PlaceHolder")));
			this.fileGroupTextBox.Properties.Mask.SaveLiteral = ((bool)(resources.GetObject("fileGroupTextBox.Properties.Mask.SaveLiteral")));
			this.fileGroupTextBox.Properties.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("fileGroupTextBox.Properties.Mask.ShowPlaceHolders")));
			this.fileGroupTextBox.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("fileGroupTextBox.Properties.Mask.UseMaskAsDisplayFormat")));
			this.fileGroupTextBox.Properties.NullValuePrompt = resources.GetString("fileGroupTextBox.Properties.NullValuePrompt");
			this.fileGroupTextBox.Properties.NullValuePromptShowForEmptyValue = ((bool)(resources.GetObject("fileGroupTextBox.Properties.NullValuePromptShowForEmptyValue")));
			this.fileGroupTextBox.Properties.ReadOnly = true;
			this.fileGroupTextBox.TextChanged += new System.EventHandler(this.fileGroupTextBox_TextChanged);
			// 
			// label3
			// 
			this.label3.AccessibleDescription = null;
			this.label3.AccessibleName = null;
			resources.ApplyResources(this.label3, "label3");
			this.label3.Name = "label3";
			// 
			// label2
			// 
			this.label2.AccessibleDescription = null;
			this.label2.AccessibleName = null;
			resources.ApplyResources(this.label2, "label2");
			this.label2.Name = "label2";
			// 
			// label1
			// 
			this.label1.AccessibleDescription = null;
			this.label1.AccessibleName = null;
			resources.ApplyResources(this.label1, "label1");
			this.label1.Name = "label1";
			// 
			// buttonTranslate
			// 
			this.buttonTranslate.AccessibleDescription = null;
			this.buttonTranslate.AccessibleName = null;
			resources.ApplyResources(this.buttonTranslate, "buttonTranslate");
			this.buttonTranslate.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
			this.buttonTranslate.Appearance.Options.UseFont = true;
			this.buttonTranslate.BackgroundImage = null;
			this.buttonTranslate.Name = "buttonTranslate";
			this.buttonTranslate.Click += new System.EventHandler(this.buttonTranslate_Click);
			// 
			// buttonCancel
			// 
			this.buttonCancel.AccessibleDescription = null;
			this.buttonCancel.AccessibleName = null;
			resources.ApplyResources(this.buttonCancel, "buttonCancel");
			this.buttonCancel.BackgroundImage = null;
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.Name = "buttonCancel";
			// 
			// panelControl1
			// 
			this.panelControl1.AccessibleDescription = null;
			this.panelControl1.AccessibleName = null;
			resources.ApplyResources(this.panelControl1, "panelControl1");
			this.panelControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
			this.panelControl1.Controls.Add(this.buttonCancel);
			this.panelControl1.Controls.Add(this.groupBox1);
			this.panelControl1.Controls.Add(this.buttonTranslate);
			this.panelControl1.Controls.Add(this.buttonSettings);
			this.panelControl1.Name = "panelControl1";
			// 
			// buttonSettings
			// 
			this.buttonSettings.AccessibleDescription = null;
			this.buttonSettings.AccessibleName = null;
			resources.ApplyResources(this.buttonSettings, "buttonSettings");
			this.buttonSettings.BackgroundImage = null;
			this.buttonSettings.Image = ((System.Drawing.Image)(resources.GetObject("buttonSettings.Image")));
			this.buttonSettings.Name = "buttonSettings";
			this.buttonSettings.Click += new System.EventHandler(this.buttonSettings_Click);
			// 
			// AutoTranslateForm
			// 
			this.AcceptButton = this.buttonTranslate;
			this.AccessibleDescription = null;
			this.AccessibleName = null;
			this.Appearance.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			this.Appearance.Options.UseFont = true;
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			resources.ApplyResources(this, "$this");
			this.CancelButton = this.buttonCancel;
			this.Controls.Add(this.panelControl1);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "AutoTranslateForm";
			this.ShowInTaskbar = false;
			this.Load += new System.EventHandler(this.autoTranslateForm_Load);
			this.Shown += new System.EventHandler(this.autoTranslateForm_Shown);
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.autoTranslateForm_FormClosing);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.groupBox1)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.prefixTextBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.prefixCheckBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.languagesToTranslateCheckListBox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.referenceLanguageGroupBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.fileGroupTextBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
			this.panelControl1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Timer updateUITimer;
		private DevExpress.XtraEditors.GroupControl groupBox1;
		private DevExpress.XtraEditors.SimpleButton buttonTranslate;
		private DevExpress.XtraEditors.SimpleButton buttonCancel;
		private DevExpress.XtraEditors.LabelControl label3;
		private DevExpress.XtraEditors.LabelControl label2;
		private DevExpress.XtraEditors.LabelControl label1;
		private DevExpress.XtraEditors.TextEdit prefixTextBox;
		private DevExpress.XtraEditors.CheckEdit prefixCheckBox;
		private DevExpress.XtraEditors.SimpleButton buttonAll;
		private DevExpress.XtraEditors.SimpleButton buttonInvert;
		private DevExpress.XtraEditors.SimpleButton buttonNone;
		private DevExpress.XtraEditors.CheckedListBoxControl languagesToTranslateCheckListBox;
		private DevExpress.XtraEditors.ComboBoxEdit referenceLanguageGroupBox;
		private DevExpress.XtraEditors.TextEdit fileGroupTextBox;
		private DevExpress.XtraEditors.PanelControl panelControl1;
		private DevExpress.XtraEditors.SimpleButton buttonDefault;
		private DevExpress.XtraEditors.SimpleButton buttonSettings;
	}
}