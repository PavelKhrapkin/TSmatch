﻿namespace ZetaResourceEditor.UI.Projects
{
	partial class ProjectSettingsForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose( bool disposing )
		{
			if ( disposing && (components != null) )
			{
				components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProjectSettingsForm));
			DevExpress.Utils.SuperToolTip superToolTip4 = new DevExpress.Utils.SuperToolTip();
			DevExpress.Utils.ToolTipTitleItem toolTipTitleItem4 = new DevExpress.Utils.ToolTipTitleItem();
			DevExpress.Utils.ToolTipItem toolTipItem4 = new DevExpress.Utils.ToolTipItem();
			DevExpress.Utils.SuperToolTip superToolTip5 = new DevExpress.Utils.SuperToolTip();
			DevExpress.Utils.ToolTipTitleItem toolTipTitleItem5 = new DevExpress.Utils.ToolTipTitleItem();
			DevExpress.Utils.ToolTipItem toolTipItem5 = new DevExpress.Utils.ToolTipItem();
			DevExpress.Utils.SuperToolTip superToolTip6 = new DevExpress.Utils.SuperToolTip();
			DevExpress.Utils.ToolTipTitleItem toolTipTitleItem6 = new DevExpress.Utils.ToolTipTitleItem();
			DevExpress.Utils.ToolTipItem toolTipItem6 = new DevExpress.Utils.ToolTipItem();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.optionsGroupBox = new DevExpress.XtraEditors.GroupControl();
			this.readOnlySaveBehaviourComboBox = new DevExpress.XtraEditors.ComboBoxEdit();
			this.barManager = new DevExpress.XtraBars.BarManager(this.components);
			this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
			this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
			this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
			this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
			this.imageCollection1 = new DevExpress.Utils.ImageCollection(this.components);
			this.openButton = new DevExpress.XtraBars.BarButtonItem();
			this.ignoreWindowsFormsDesignerFiles = new DevExpress.XtraEditors.CheckEdit();
			this.button1 = new DevExpress.XtraEditors.DropDownButton();
			this.optionsPopupMenu = new DevExpress.XtraBars.PopupMenu(this.components);
			this.omitEmptyItemsCheckBox = new DevExpress.XtraEditors.CheckEdit();
			this.createBackupsCheckBox = new DevExpress.XtraEditors.CheckEdit();
			this.nameTextBox = new DevExpress.XtraEditors.TextEdit();
			this.locationTextBox = new DevExpress.XtraEditors.TextEdit();
			this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
			this.label2 = new DevExpress.XtraEditors.LabelControl();
			this.label1 = new DevExpress.XtraEditors.LabelControl();
			this.hideInternalDesignerRowsCheckEdit = new DevExpress.XtraEditors.CheckEdit();
			this.shallowCumulationCheckEdit = new DevExpress.XtraEditors.CheckEdit();
			this.showCommentsColumnInGridCheckEdit = new DevExpress.XtraEditors.CheckEdit();
			this.hideEmptyRowsCheck = new DevExpress.XtraEditors.CheckEdit();
			this.descriptionTextBox = new DevExpress.XtraEditors.MemoEdit();
			this.neutralLanguageCodeTextEdit = new DevExpress.XtraEditors.TextEdit();
			this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
			this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
			this.buttonCancel = new DevExpress.XtraEditors.SimpleButton();
			this.buttonOK = new DevExpress.XtraEditors.SimpleButton();
			this.useSpellCheckingCheckEdit = new DevExpress.XtraEditors.CheckEdit();
			this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
			this.hyperLinkEdit1 = new DevExpress.XtraEditors.HyperLinkEdit();
			this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
			this.pictureBox3 = new System.Windows.Forms.PictureBox();
			this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
			this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
			this.imageCollection2 = new DevExpress.Utils.ImageCollection(this.components);
			this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
			this.groupControl3 = new DevExpress.XtraEditors.GroupControl();
			this.pictureBox4 = new System.Windows.Forms.PictureBox();
			this.xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
			this.groupControl4 = new DevExpress.XtraEditors.GroupControl();
			this.pictureBox8 = new System.Windows.Forms.PictureBox();
			this.pictureBox6 = new System.Windows.Forms.PictureBox();
			this.pictureBox7 = new System.Windows.Forms.PictureBox();
			this.baseNameDotCountSpinEdit = new DevExpress.XtraEditors.SpinEdit();
			this.defaultTypesTextEdit = new DevExpress.XtraEditors.TextEdit();
			this.nonNeutralLanguageFileNamePatternTextEdit = new DevExpress.XtraEditors.TextEdit();
			this.neutralLanguageFileNamePatternTextEdit = new DevExpress.XtraEditors.TextEdit();
			this.pictureBox5 = new System.Windows.Forms.PictureBox();
			this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
			this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
			this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
			this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
			this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
			this.xtraTabPage3 = new DevExpress.XtraTab.XtraTabPage();
			this.groupControl6 = new DevExpress.XtraEditors.GroupControl();
			this.pictureBox10 = new System.Windows.Forms.PictureBox();
			this.colorifyNullCellsCheckEdit = new DevExpress.XtraEditors.CheckEdit();
			this.persistGridSettingsCheckEdit = new DevExpress.XtraEditors.CheckEdit();
			this.groupControl5 = new DevExpress.XtraEditors.GroupControl();
			this.useCrypticExcelExportSheetNamesCheckEdit = new DevExpress.XtraEditors.CheckEdit();
			this.pictureBox9 = new System.Windows.Forms.PictureBox();
			this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
			this.defaultToolTipController1 = new DevExpress.Utils.DefaultToolTipController(this.components);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.optionsGroupBox)).BeginInit();
			this.optionsGroupBox.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.readOnlySaveBehaviourComboBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.barManager)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.ignoreWindowsFormsDesignerFiles.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.optionsPopupMenu)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.omitEmptyItemsCheckBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.createBackupsCheckBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.nameTextBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.locationTextBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.hideInternalDesignerRowsCheckEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.shallowCumulationCheckEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.showCommentsColumnInGridCheckEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.hideEmptyRowsCheck.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.descriptionTextBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.neutralLanguageCodeTextEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.useSpellCheckingCheckEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
			this.groupControl1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
			this.groupControl2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.hyperLinkEdit1.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
			this.xtraTabControl1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.imageCollection2)).BeginInit();
			this.xtraTabPage1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.groupControl3)).BeginInit();
			this.groupControl3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
			this.xtraTabPage2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.groupControl4)).BeginInit();
			this.groupControl4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.baseNameDotCountSpinEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.defaultTypesTextEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.nonNeutralLanguageFileNamePatternTextEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.neutralLanguageFileNamePatternTextEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
			this.xtraTabPage3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.groupControl6)).BeginInit();
			this.groupControl6.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.colorifyNullCellsCheckEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.persistGridSettingsCheckEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.groupControl5)).BeginInit();
			this.groupControl5.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.useCrypticExcelExportSheetNamesCheckEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
			this.panelControl1.SuspendLayout();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.AccessibleDescription = null;
			this.pictureBox1.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.pictureBox1, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("pictureBox1.AllowHtmlText"))));
			resources.ApplyResources(this.pictureBox1, "pictureBox1");
			this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox1.BackgroundImage = null;
			this.pictureBox1.Font = null;
			this.pictureBox1.ImageLocation = null;
			this.pictureBox1.Name = "pictureBox1";
			this.defaultToolTipController1.SetSuperTip(this.pictureBox1, null);
			this.pictureBox1.TabStop = false;
			this.defaultToolTipController1.SetTitle(this.pictureBox1, resources.GetString("pictureBox1.Title"));
			this.defaultToolTipController1.SetToolTip(this.pictureBox1, resources.GetString("pictureBox1.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.pictureBox1, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("pictureBox1.ToolTipIconType"))));
			// 
			// optionsGroupBox
			// 
			this.optionsGroupBox.AccessibleDescription = null;
			this.optionsGroupBox.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.optionsGroupBox, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("optionsGroupBox.AllowHtmlText"))));
			resources.ApplyResources(this.optionsGroupBox, "optionsGroupBox");
			this.optionsGroupBox.Controls.Add(this.readOnlySaveBehaviourComboBox);
			this.optionsGroupBox.Controls.Add(this.ignoreWindowsFormsDesignerFiles);
			this.optionsGroupBox.Controls.Add(this.button1);
			this.optionsGroupBox.Controls.Add(this.omitEmptyItemsCheckBox);
			this.optionsGroupBox.Controls.Add(this.createBackupsCheckBox);
			this.optionsGroupBox.Controls.Add(this.nameTextBox);
			this.optionsGroupBox.Controls.Add(this.locationTextBox);
			this.optionsGroupBox.Controls.Add(this.labelControl7);
			this.optionsGroupBox.Controls.Add(this.label2);
			this.optionsGroupBox.Controls.Add(this.label1);
			this.optionsGroupBox.Controls.Add(this.pictureBox1);
			this.optionsGroupBox.Name = "optionsGroupBox";
			this.defaultToolTipController1.SetSuperTip(this.optionsGroupBox, null);
			this.defaultToolTipController1.SetTitle(this.optionsGroupBox, resources.GetString("optionsGroupBox.Title"));
			this.defaultToolTipController1.SetToolTip(this.optionsGroupBox, resources.GetString("optionsGroupBox.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.optionsGroupBox, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("optionsGroupBox.ToolTipIconType"))));
			// 
			// readOnlySaveBehaviourComboBox
			// 
			resources.ApplyResources(this.readOnlySaveBehaviourComboBox, "readOnlySaveBehaviourComboBox");
			this.readOnlySaveBehaviourComboBox.BackgroundImage = null;
			this.readOnlySaveBehaviourComboBox.EditValue = null;
			this.readOnlySaveBehaviourComboBox.MenuManager = this.barManager;
			this.readOnlySaveBehaviourComboBox.Name = "readOnlySaveBehaviourComboBox";
			this.readOnlySaveBehaviourComboBox.Properties.AccessibleDescription = null;
			this.readOnlySaveBehaviourComboBox.Properties.AccessibleName = null;
			this.readOnlySaveBehaviourComboBox.Properties.AutoHeight = ((bool)(resources.GetObject("readOnlySaveBehaviourComboBox.Properties.AutoHeight")));
			this.readOnlySaveBehaviourComboBox.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("readOnlySaveBehaviourComboBox.Properties.Buttons"))))});
			this.readOnlySaveBehaviourComboBox.Properties.NullValuePrompt = resources.GetString("readOnlySaveBehaviourComboBox.Properties.NullValuePrompt");
			this.readOnlySaveBehaviourComboBox.Properties.NullValuePromptShowForEmptyValue = ((bool)(resources.GetObject("readOnlySaveBehaviourComboBox.Properties.NullValuePromptShowForEmptyValue")));
			this.readOnlySaveBehaviourComboBox.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			// 
			// barManager
			// 
			this.barManager.DockControls.Add(this.barDockControlTop);
			this.barManager.DockControls.Add(this.barDockControlBottom);
			this.barManager.DockControls.Add(this.barDockControlLeft);
			this.barManager.DockControls.Add(this.barDockControlRight);
			this.barManager.Form = this;
			this.barManager.Images = this.imageCollection1;
			this.barManager.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.openButton});
			this.barManager.MaxItemId = 3;
			// 
			// barDockControlTop
			// 
			this.barDockControlTop.AccessibleDescription = null;
			this.barDockControlTop.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.barDockControlTop, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("barDockControlTop.AllowHtmlText"))));
			resources.ApplyResources(this.barDockControlTop, "barDockControlTop");
			this.barDockControlTop.Font = null;
			this.defaultToolTipController1.SetSuperTip(this.barDockControlTop, null);
			this.defaultToolTipController1.SetTitle(this.barDockControlTop, resources.GetString("barDockControlTop.Title"));
			this.defaultToolTipController1.SetToolTip(this.barDockControlTop, resources.GetString("barDockControlTop.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.barDockControlTop, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("barDockControlTop.ToolTipIconType"))));
			// 
			// barDockControlBottom
			// 
			this.barDockControlBottom.AccessibleDescription = null;
			this.barDockControlBottom.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.barDockControlBottom, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("barDockControlBottom.AllowHtmlText"))));
			resources.ApplyResources(this.barDockControlBottom, "barDockControlBottom");
			this.barDockControlBottom.Font = null;
			this.defaultToolTipController1.SetSuperTip(this.barDockControlBottom, null);
			this.defaultToolTipController1.SetTitle(this.barDockControlBottom, resources.GetString("barDockControlBottom.Title"));
			this.defaultToolTipController1.SetToolTip(this.barDockControlBottom, resources.GetString("barDockControlBottom.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.barDockControlBottom, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("barDockControlBottom.ToolTipIconType"))));
			// 
			// barDockControlLeft
			// 
			this.barDockControlLeft.AccessibleDescription = null;
			this.barDockControlLeft.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.barDockControlLeft, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("barDockControlLeft.AllowHtmlText"))));
			resources.ApplyResources(this.barDockControlLeft, "barDockControlLeft");
			this.barDockControlLeft.Font = null;
			this.defaultToolTipController1.SetSuperTip(this.barDockControlLeft, null);
			this.defaultToolTipController1.SetTitle(this.barDockControlLeft, resources.GetString("barDockControlLeft.Title"));
			this.defaultToolTipController1.SetToolTip(this.barDockControlLeft, resources.GetString("barDockControlLeft.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.barDockControlLeft, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("barDockControlLeft.ToolTipIconType"))));
			// 
			// barDockControlRight
			// 
			this.barDockControlRight.AccessibleDescription = null;
			this.barDockControlRight.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.barDockControlRight, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("barDockControlRight.AllowHtmlText"))));
			resources.ApplyResources(this.barDockControlRight, "barDockControlRight");
			this.barDockControlRight.Font = null;
			this.defaultToolTipController1.SetSuperTip(this.barDockControlRight, null);
			this.defaultToolTipController1.SetTitle(this.barDockControlRight, resources.GetString("barDockControlRight.Title"));
			this.defaultToolTipController1.SetToolTip(this.barDockControlRight, resources.GetString("barDockControlRight.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.barDockControlRight, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("barDockControlRight.ToolTipIconType"))));
			// 
			// imageCollection1
			// 
			this.imageCollection1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection1.ImageStream")));
			this.imageCollection1.Images.SetKeyName(0, "folder_green.png");
			// 
			// openButton
			// 
			this.openButton.AccessibleDescription = null;
			this.openButton.AccessibleName = null;
			resources.ApplyResources(this.openButton, "openButton");
			this.openButton.Id = 0;
			this.openButton.ImageIndex = 0;
			this.openButton.Name = "openButton";
			this.openButton.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.openButton_ItemClick);
			// 
			// ignoreWindowsFormsDesignerFiles
			// 
			resources.ApplyResources(this.ignoreWindowsFormsDesignerFiles, "ignoreWindowsFormsDesignerFiles");
			this.ignoreWindowsFormsDesignerFiles.BackgroundImage = null;
			this.ignoreWindowsFormsDesignerFiles.Name = "ignoreWindowsFormsDesignerFiles";
			this.ignoreWindowsFormsDesignerFiles.Properties.AccessibleDescription = null;
			this.ignoreWindowsFormsDesignerFiles.Properties.AccessibleName = null;
			this.ignoreWindowsFormsDesignerFiles.Properties.AutoHeight = ((bool)(resources.GetObject("ignoreWindowsFormsDesignerFiles.Properties.AutoHeight")));
			this.ignoreWindowsFormsDesignerFiles.Properties.AutoWidth = true;
			this.ignoreWindowsFormsDesignerFiles.Properties.Caption = resources.GetString("ignoreWindowsFormsDesignerFiles.Properties.Caption");
			this.ignoreWindowsFormsDesignerFiles.Properties.DisplayValueChecked = resources.GetString("ignoreWindowsFormsDesignerFiles.Properties.DisplayValueChecked");
			this.ignoreWindowsFormsDesignerFiles.Properties.DisplayValueGrayed = resources.GetString("ignoreWindowsFormsDesignerFiles.Properties.DisplayValueGrayed");
			this.ignoreWindowsFormsDesignerFiles.Properties.DisplayValueUnchecked = resources.GetString("ignoreWindowsFormsDesignerFiles.Properties.DisplayValueUnchecked");
			// 
			// button1
			// 
			this.button1.AccessibleDescription = null;
			this.button1.AccessibleName = null;
			resources.ApplyResources(this.button1, "button1");
			this.button1.BackgroundImage = null;
			this.button1.DropDownControl = this.optionsPopupMenu;
			this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
			this.button1.ImageLocation = DevExpress.XtraEditors.ImageLocation.MiddleRight;
			this.button1.Name = "button1";
			this.button1.ShowArrowButton = false;
			// 
			// optionsPopupMenu
			// 
			this.optionsPopupMenu.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.openButton)});
			this.optionsPopupMenu.Manager = this.barManager;
			this.optionsPopupMenu.Name = "optionsPopupMenu";
			// 
			// omitEmptyItemsCheckBox
			// 
			resources.ApplyResources(this.omitEmptyItemsCheckBox, "omitEmptyItemsCheckBox");
			this.omitEmptyItemsCheckBox.BackgroundImage = null;
			this.omitEmptyItemsCheckBox.Name = "omitEmptyItemsCheckBox";
			this.omitEmptyItemsCheckBox.Properties.AccessibleDescription = null;
			this.omitEmptyItemsCheckBox.Properties.AccessibleName = null;
			this.omitEmptyItemsCheckBox.Properties.AutoHeight = ((bool)(resources.GetObject("omitEmptyItemsCheckBox.Properties.AutoHeight")));
			this.omitEmptyItemsCheckBox.Properties.AutoWidth = true;
			this.omitEmptyItemsCheckBox.Properties.Caption = resources.GetString("omitEmptyItemsCheckBox.Properties.Caption");
			this.omitEmptyItemsCheckBox.Properties.DisplayValueChecked = resources.GetString("omitEmptyItemsCheckBox.Properties.DisplayValueChecked");
			this.omitEmptyItemsCheckBox.Properties.DisplayValueGrayed = resources.GetString("omitEmptyItemsCheckBox.Properties.DisplayValueGrayed");
			this.omitEmptyItemsCheckBox.Properties.DisplayValueUnchecked = resources.GetString("omitEmptyItemsCheckBox.Properties.DisplayValueUnchecked");
			// 
			// createBackupsCheckBox
			// 
			resources.ApplyResources(this.createBackupsCheckBox, "createBackupsCheckBox");
			this.createBackupsCheckBox.BackgroundImage = null;
			this.createBackupsCheckBox.Name = "createBackupsCheckBox";
			this.createBackupsCheckBox.Properties.AccessibleDescription = null;
			this.createBackupsCheckBox.Properties.AccessibleName = null;
			this.createBackupsCheckBox.Properties.AutoHeight = ((bool)(resources.GetObject("createBackupsCheckBox.Properties.AutoHeight")));
			this.createBackupsCheckBox.Properties.AutoWidth = true;
			this.createBackupsCheckBox.Properties.Caption = resources.GetString("createBackupsCheckBox.Properties.Caption");
			this.createBackupsCheckBox.Properties.DisplayValueChecked = resources.GetString("createBackupsCheckBox.Properties.DisplayValueChecked");
			this.createBackupsCheckBox.Properties.DisplayValueGrayed = resources.GetString("createBackupsCheckBox.Properties.DisplayValueGrayed");
			this.createBackupsCheckBox.Properties.DisplayValueUnchecked = resources.GetString("createBackupsCheckBox.Properties.DisplayValueUnchecked");
			// 
			// nameTextBox
			// 
			resources.ApplyResources(this.nameTextBox, "nameTextBox");
			this.nameTextBox.BackgroundImage = null;
			this.nameTextBox.EditValue = null;
			this.nameTextBox.Name = "nameTextBox";
			this.nameTextBox.Properties.AccessibleDescription = null;
			this.nameTextBox.Properties.AccessibleName = null;
			this.nameTextBox.Properties.AutoHeight = ((bool)(resources.GetObject("nameTextBox.Properties.AutoHeight")));
			this.nameTextBox.Properties.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("nameTextBox.Properties.Mask.AutoComplete")));
			this.nameTextBox.Properties.Mask.BeepOnError = ((bool)(resources.GetObject("nameTextBox.Properties.Mask.BeepOnError")));
			this.nameTextBox.Properties.Mask.EditMask = resources.GetString("nameTextBox.Properties.Mask.EditMask");
			this.nameTextBox.Properties.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("nameTextBox.Properties.Mask.IgnoreMaskBlank")));
			this.nameTextBox.Properties.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("nameTextBox.Properties.Mask.MaskType")));
			this.nameTextBox.Properties.Mask.PlaceHolder = ((char)(resources.GetObject("nameTextBox.Properties.Mask.PlaceHolder")));
			this.nameTextBox.Properties.Mask.SaveLiteral = ((bool)(resources.GetObject("nameTextBox.Properties.Mask.SaveLiteral")));
			this.nameTextBox.Properties.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("nameTextBox.Properties.Mask.ShowPlaceHolders")));
			this.nameTextBox.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("nameTextBox.Properties.Mask.UseMaskAsDisplayFormat")));
			this.nameTextBox.Properties.NullValuePrompt = resources.GetString("nameTextBox.Properties.NullValuePrompt");
			this.nameTextBox.Properties.NullValuePromptShowForEmptyValue = ((bool)(resources.GetObject("nameTextBox.Properties.NullValuePromptShowForEmptyValue")));
			this.nameTextBox.Properties.ReadOnly = true;
			// 
			// locationTextBox
			// 
			resources.ApplyResources(this.locationTextBox, "locationTextBox");
			this.locationTextBox.BackgroundImage = null;
			this.locationTextBox.EditValue = null;
			this.locationTextBox.Name = "locationTextBox";
			this.locationTextBox.Properties.AccessibleDescription = null;
			this.locationTextBox.Properties.AccessibleName = null;
			this.locationTextBox.Properties.AutoHeight = ((bool)(resources.GetObject("locationTextBox.Properties.AutoHeight")));
			this.locationTextBox.Properties.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("locationTextBox.Properties.Mask.AutoComplete")));
			this.locationTextBox.Properties.Mask.BeepOnError = ((bool)(resources.GetObject("locationTextBox.Properties.Mask.BeepOnError")));
			this.locationTextBox.Properties.Mask.EditMask = resources.GetString("locationTextBox.Properties.Mask.EditMask");
			this.locationTextBox.Properties.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("locationTextBox.Properties.Mask.IgnoreMaskBlank")));
			this.locationTextBox.Properties.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("locationTextBox.Properties.Mask.MaskType")));
			this.locationTextBox.Properties.Mask.PlaceHolder = ((char)(resources.GetObject("locationTextBox.Properties.Mask.PlaceHolder")));
			this.locationTextBox.Properties.Mask.SaveLiteral = ((bool)(resources.GetObject("locationTextBox.Properties.Mask.SaveLiteral")));
			this.locationTextBox.Properties.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("locationTextBox.Properties.Mask.ShowPlaceHolders")));
			this.locationTextBox.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("locationTextBox.Properties.Mask.UseMaskAsDisplayFormat")));
			this.locationTextBox.Properties.NullValuePrompt = resources.GetString("locationTextBox.Properties.NullValuePrompt");
			this.locationTextBox.Properties.NullValuePromptShowForEmptyValue = ((bool)(resources.GetObject("locationTextBox.Properties.NullValuePromptShowForEmptyValue")));
			this.locationTextBox.Properties.ReadOnly = true;
			// 
			// labelControl7
			// 
			this.labelControl7.AccessibleDescription = null;
			this.labelControl7.AccessibleName = null;
			resources.ApplyResources(this.labelControl7, "labelControl7");
			this.labelControl7.Name = "labelControl7";
			// 
			// label2
			// 
			this.label2.AccessibleDescription = null;
			this.label2.AccessibleName = null;
			resources.ApplyResources(this.label2, "label2");
			this.label2.Name = "label2";
			// 
			// label1
			// 
			this.label1.AccessibleDescription = null;
			this.label1.AccessibleName = null;
			resources.ApplyResources(this.label1, "label1");
			this.label1.Name = "label1";
			// 
			// hideInternalDesignerRowsCheckEdit
			// 
			resources.ApplyResources(this.hideInternalDesignerRowsCheckEdit, "hideInternalDesignerRowsCheckEdit");
			this.hideInternalDesignerRowsCheckEdit.BackgroundImage = null;
			this.hideInternalDesignerRowsCheckEdit.Name = "hideInternalDesignerRowsCheckEdit";
			this.hideInternalDesignerRowsCheckEdit.Properties.AccessibleDescription = null;
			this.hideInternalDesignerRowsCheckEdit.Properties.AccessibleName = null;
			this.hideInternalDesignerRowsCheckEdit.Properties.AutoHeight = ((bool)(resources.GetObject("hideInternalDesignerRowsCheckEdit.Properties.AutoHeight")));
			this.hideInternalDesignerRowsCheckEdit.Properties.AutoWidth = true;
			this.hideInternalDesignerRowsCheckEdit.Properties.Caption = resources.GetString("hideInternalDesignerRowsCheckEdit.Properties.Caption");
			this.hideInternalDesignerRowsCheckEdit.Properties.DisplayValueChecked = resources.GetString("hideInternalDesignerRowsCheckEdit.Properties.DisplayValueChecked");
			this.hideInternalDesignerRowsCheckEdit.Properties.DisplayValueGrayed = resources.GetString("hideInternalDesignerRowsCheckEdit.Properties.DisplayValueGrayed");
			this.hideInternalDesignerRowsCheckEdit.Properties.DisplayValueUnchecked = resources.GetString("hideInternalDesignerRowsCheckEdit.Properties.DisplayValueUnchecked");
			// 
			// shallowCumulationCheckEdit
			// 
			resources.ApplyResources(this.shallowCumulationCheckEdit, "shallowCumulationCheckEdit");
			this.shallowCumulationCheckEdit.BackgroundImage = null;
			this.shallowCumulationCheckEdit.Name = "shallowCumulationCheckEdit";
			this.shallowCumulationCheckEdit.Properties.AccessibleDescription = null;
			this.shallowCumulationCheckEdit.Properties.AccessibleName = null;
			this.shallowCumulationCheckEdit.Properties.AutoHeight = ((bool)(resources.GetObject("shallowCumulationCheckEdit.Properties.AutoHeight")));
			this.shallowCumulationCheckEdit.Properties.AutoWidth = true;
			this.shallowCumulationCheckEdit.Properties.Caption = resources.GetString("shallowCumulationCheckEdit.Properties.Caption");
			this.shallowCumulationCheckEdit.Properties.DisplayValueChecked = resources.GetString("shallowCumulationCheckEdit.Properties.DisplayValueChecked");
			this.shallowCumulationCheckEdit.Properties.DisplayValueGrayed = resources.GetString("shallowCumulationCheckEdit.Properties.DisplayValueGrayed");
			this.shallowCumulationCheckEdit.Properties.DisplayValueUnchecked = resources.GetString("shallowCumulationCheckEdit.Properties.DisplayValueUnchecked");
			// 
			// showCommentsColumnInGridCheckEdit
			// 
			resources.ApplyResources(this.showCommentsColumnInGridCheckEdit, "showCommentsColumnInGridCheckEdit");
			this.showCommentsColumnInGridCheckEdit.BackgroundImage = null;
			this.showCommentsColumnInGridCheckEdit.Name = "showCommentsColumnInGridCheckEdit";
			this.showCommentsColumnInGridCheckEdit.Properties.AccessibleDescription = null;
			this.showCommentsColumnInGridCheckEdit.Properties.AccessibleName = null;
			this.showCommentsColumnInGridCheckEdit.Properties.AutoHeight = ((bool)(resources.GetObject("showCommentsColumnInGridCheckEdit.Properties.AutoHeight")));
			this.showCommentsColumnInGridCheckEdit.Properties.AutoWidth = true;
			this.showCommentsColumnInGridCheckEdit.Properties.Caption = resources.GetString("showCommentsColumnInGridCheckEdit.Properties.Caption");
			this.showCommentsColumnInGridCheckEdit.Properties.DisplayValueChecked = resources.GetString("showCommentsColumnInGridCheckEdit.Properties.DisplayValueChecked");
			this.showCommentsColumnInGridCheckEdit.Properties.DisplayValueGrayed = resources.GetString("showCommentsColumnInGridCheckEdit.Properties.DisplayValueGrayed");
			this.showCommentsColumnInGridCheckEdit.Properties.DisplayValueUnchecked = resources.GetString("showCommentsColumnInGridCheckEdit.Properties.DisplayValueUnchecked");
			// 
			// hideEmptyRowsCheck
			// 
			resources.ApplyResources(this.hideEmptyRowsCheck, "hideEmptyRowsCheck");
			this.hideEmptyRowsCheck.BackgroundImage = null;
			this.hideEmptyRowsCheck.Name = "hideEmptyRowsCheck";
			this.hideEmptyRowsCheck.Properties.AccessibleDescription = null;
			this.hideEmptyRowsCheck.Properties.AccessibleName = null;
			this.hideEmptyRowsCheck.Properties.AutoHeight = ((bool)(resources.GetObject("hideEmptyRowsCheck.Properties.AutoHeight")));
			this.hideEmptyRowsCheck.Properties.AutoWidth = true;
			this.hideEmptyRowsCheck.Properties.Caption = resources.GetString("hideEmptyRowsCheck.Properties.Caption");
			this.hideEmptyRowsCheck.Properties.DisplayValueChecked = resources.GetString("hideEmptyRowsCheck.Properties.DisplayValueChecked");
			this.hideEmptyRowsCheck.Properties.DisplayValueGrayed = resources.GetString("hideEmptyRowsCheck.Properties.DisplayValueGrayed");
			this.hideEmptyRowsCheck.Properties.DisplayValueUnchecked = resources.GetString("hideEmptyRowsCheck.Properties.DisplayValueUnchecked");
			// 
			// descriptionTextBox
			// 
			resources.ApplyResources(this.descriptionTextBox, "descriptionTextBox");
			this.descriptionTextBox.BackgroundImage = null;
			this.descriptionTextBox.EditValue = null;
			this.descriptionTextBox.Name = "descriptionTextBox";
			this.descriptionTextBox.Properties.AccessibleDescription = null;
			this.descriptionTextBox.Properties.AccessibleName = null;
			this.descriptionTextBox.Properties.NullValuePrompt = resources.GetString("descriptionTextBox.Properties.NullValuePrompt");
			this.descriptionTextBox.Properties.NullValuePromptShowForEmptyValue = ((bool)(resources.GetObject("descriptionTextBox.Properties.NullValuePromptShowForEmptyValue")));
			// 
			// neutralLanguageCodeTextEdit
			// 
			resources.ApplyResources(this.neutralLanguageCodeTextEdit, "neutralLanguageCodeTextEdit");
			this.neutralLanguageCodeTextEdit.BackgroundImage = null;
			this.neutralLanguageCodeTextEdit.EditValue = null;
			this.neutralLanguageCodeTextEdit.MenuManager = this.barManager;
			this.neutralLanguageCodeTextEdit.Name = "neutralLanguageCodeTextEdit";
			this.neutralLanguageCodeTextEdit.Properties.AccessibleDescription = null;
			this.neutralLanguageCodeTextEdit.Properties.AccessibleName = null;
			this.neutralLanguageCodeTextEdit.Properties.AutoHeight = ((bool)(resources.GetObject("neutralLanguageCodeTextEdit.Properties.AutoHeight")));
			this.neutralLanguageCodeTextEdit.Properties.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("neutralLanguageCodeTextEdit.Properties.Mask.AutoComplete")));
			this.neutralLanguageCodeTextEdit.Properties.Mask.BeepOnError = ((bool)(resources.GetObject("neutralLanguageCodeTextEdit.Properties.Mask.BeepOnError")));
			this.neutralLanguageCodeTextEdit.Properties.Mask.EditMask = resources.GetString("neutralLanguageCodeTextEdit.Properties.Mask.EditMask");
			this.neutralLanguageCodeTextEdit.Properties.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("neutralLanguageCodeTextEdit.Properties.Mask.IgnoreMaskBlank")));
			this.neutralLanguageCodeTextEdit.Properties.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("neutralLanguageCodeTextEdit.Properties.Mask.MaskType")));
			this.neutralLanguageCodeTextEdit.Properties.Mask.PlaceHolder = ((char)(resources.GetObject("neutralLanguageCodeTextEdit.Properties.Mask.PlaceHolder")));
			this.neutralLanguageCodeTextEdit.Properties.Mask.SaveLiteral = ((bool)(resources.GetObject("neutralLanguageCodeTextEdit.Properties.Mask.SaveLiteral")));
			this.neutralLanguageCodeTextEdit.Properties.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("neutralLanguageCodeTextEdit.Properties.Mask.ShowPlaceHolders")));
			this.neutralLanguageCodeTextEdit.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("neutralLanguageCodeTextEdit.Properties.Mask.UseMaskAsDisplayFormat")));
			this.neutralLanguageCodeTextEdit.Properties.NullValuePrompt = resources.GetString("neutralLanguageCodeTextEdit.Properties.NullValuePrompt");
			this.neutralLanguageCodeTextEdit.Properties.NullValuePromptShowForEmptyValue = ((bool)(resources.GetObject("neutralLanguageCodeTextEdit.Properties.NullValuePromptShowForEmptyValue")));
			// 
			// labelControl2
			// 
			this.labelControl2.AccessibleDescription = null;
			this.labelControl2.AccessibleName = null;
			resources.ApplyResources(this.labelControl2, "labelControl2");
			this.labelControl2.Name = "labelControl2";
			// 
			// labelControl1
			// 
			this.labelControl1.AccessibleDescription = null;
			this.labelControl1.AccessibleName = null;
			resources.ApplyResources(this.labelControl1, "labelControl1");
			this.labelControl1.Name = "labelControl1";
			// 
			// buttonCancel
			// 
			this.buttonCancel.AccessibleDescription = null;
			this.buttonCancel.AccessibleName = null;
			resources.ApplyResources(this.buttonCancel, "buttonCancel");
			this.buttonCancel.BackgroundImage = null;
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.Name = "buttonCancel";
			// 
			// buttonOK
			// 
			this.buttonOK.AccessibleDescription = null;
			this.buttonOK.AccessibleName = null;
			resources.ApplyResources(this.buttonOK, "buttonOK");
			this.buttonOK.BackgroundImage = null;
			this.buttonOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// useSpellCheckingCheckEdit
			// 
			resources.ApplyResources(this.useSpellCheckingCheckEdit, "useSpellCheckingCheckEdit");
			this.useSpellCheckingCheckEdit.BackgroundImage = null;
			this.useSpellCheckingCheckEdit.Name = "useSpellCheckingCheckEdit";
			this.useSpellCheckingCheckEdit.Properties.AccessibleDescription = null;
			this.useSpellCheckingCheckEdit.Properties.AccessibleName = null;
			this.useSpellCheckingCheckEdit.Properties.AutoHeight = ((bool)(resources.GetObject("useSpellCheckingCheckEdit.Properties.AutoHeight")));
			this.useSpellCheckingCheckEdit.Properties.AutoWidth = true;
			this.useSpellCheckingCheckEdit.Properties.Caption = resources.GetString("useSpellCheckingCheckEdit.Properties.Caption");
			this.useSpellCheckingCheckEdit.Properties.DisplayValueChecked = resources.GetString("useSpellCheckingCheckEdit.Properties.DisplayValueChecked");
			this.useSpellCheckingCheckEdit.Properties.DisplayValueGrayed = resources.GetString("useSpellCheckingCheckEdit.Properties.DisplayValueGrayed");
			this.useSpellCheckingCheckEdit.Properties.DisplayValueUnchecked = resources.GetString("useSpellCheckingCheckEdit.Properties.DisplayValueUnchecked");
			// 
			// groupControl1
			// 
			this.groupControl1.AccessibleDescription = null;
			this.groupControl1.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.groupControl1, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("groupControl1.AllowHtmlText"))));
			resources.ApplyResources(this.groupControl1, "groupControl1");
			this.groupControl1.Controls.Add(this.neutralLanguageCodeTextEdit);
			this.groupControl1.Controls.Add(this.useSpellCheckingCheckEdit);
			this.groupControl1.Controls.Add(this.pictureBox2);
			this.groupControl1.Controls.Add(this.labelControl1);
			this.groupControl1.Controls.Add(this.labelControl2);
			this.groupControl1.Name = "groupControl1";
			this.defaultToolTipController1.SetSuperTip(this.groupControl1, null);
			this.defaultToolTipController1.SetTitle(this.groupControl1, resources.GetString("groupControl1.Title"));
			this.defaultToolTipController1.SetToolTip(this.groupControl1, resources.GetString("groupControl1.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.groupControl1, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("groupControl1.ToolTipIconType"))));
			// 
			// pictureBox2
			// 
			this.pictureBox2.AccessibleDescription = null;
			this.pictureBox2.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.pictureBox2, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("pictureBox2.AllowHtmlText"))));
			resources.ApplyResources(this.pictureBox2, "pictureBox2");
			this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox2.BackgroundImage = null;
			this.pictureBox2.Font = null;
			this.pictureBox2.ImageLocation = null;
			this.pictureBox2.Name = "pictureBox2";
			this.defaultToolTipController1.SetSuperTip(this.pictureBox2, null);
			this.pictureBox2.TabStop = false;
			this.defaultToolTipController1.SetTitle(this.pictureBox2, resources.GetString("pictureBox2.Title"));
			this.defaultToolTipController1.SetToolTip(this.pictureBox2, resources.GetString("pictureBox2.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.pictureBox2, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("pictureBox2.ToolTipIconType"))));
			// 
			// groupControl2
			// 
			this.groupControl2.AccessibleDescription = null;
			this.groupControl2.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.groupControl2, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("groupControl2.AllowHtmlText"))));
			resources.ApplyResources(this.groupControl2, "groupControl2");
			this.groupControl2.Controls.Add(this.hyperLinkEdit1);
			this.groupControl2.Controls.Add(this.labelControl3);
			this.groupControl2.Controls.Add(this.pictureBox3);
			this.groupControl2.Controls.Add(this.labelControl4);
			this.groupControl2.Name = "groupControl2";
			this.defaultToolTipController1.SetSuperTip(this.groupControl2, null);
			this.defaultToolTipController1.SetTitle(this.groupControl2, resources.GetString("groupControl2.Title"));
			this.defaultToolTipController1.SetToolTip(this.groupControl2, resources.GetString("groupControl2.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.groupControl2, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("groupControl2.ToolTipIconType"))));
			// 
			// hyperLinkEdit1
			// 
			resources.ApplyResources(this.hyperLinkEdit1, "hyperLinkEdit1");
			this.hyperLinkEdit1.BackgroundImage = null;
			this.hyperLinkEdit1.Name = "hyperLinkEdit1";
			this.hyperLinkEdit1.Properties.AccessibleDescription = null;
			this.hyperLinkEdit1.Properties.AccessibleName = null;
			this.hyperLinkEdit1.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
			this.hyperLinkEdit1.Properties.Appearance.Options.UseBackColor = true;
			this.hyperLinkEdit1.Properties.AutoHeight = ((bool)(resources.GetObject("hyperLinkEdit1.Properties.AutoHeight")));
			this.hyperLinkEdit1.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
			this.hyperLinkEdit1.Properties.Caption = resources.GetString("hyperLinkEdit1.Properties.Caption");
			this.hyperLinkEdit1.Properties.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("hyperLinkEdit1.Properties.Mask.AutoComplete")));
			this.hyperLinkEdit1.Properties.Mask.BeepOnError = ((bool)(resources.GetObject("hyperLinkEdit1.Properties.Mask.BeepOnError")));
			this.hyperLinkEdit1.Properties.Mask.EditMask = resources.GetString("hyperLinkEdit1.Properties.Mask.EditMask");
			this.hyperLinkEdit1.Properties.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("hyperLinkEdit1.Properties.Mask.IgnoreMaskBlank")));
			this.hyperLinkEdit1.Properties.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("hyperLinkEdit1.Properties.Mask.MaskType")));
			this.hyperLinkEdit1.Properties.Mask.PlaceHolder = ((char)(resources.GetObject("hyperLinkEdit1.Properties.Mask.PlaceHolder")));
			this.hyperLinkEdit1.Properties.Mask.SaveLiteral = ((bool)(resources.GetObject("hyperLinkEdit1.Properties.Mask.SaveLiteral")));
			this.hyperLinkEdit1.Properties.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("hyperLinkEdit1.Properties.Mask.ShowPlaceHolders")));
			this.hyperLinkEdit1.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("hyperLinkEdit1.Properties.Mask.UseMaskAsDisplayFormat")));
			this.hyperLinkEdit1.Properties.NullValuePrompt = resources.GetString("hyperLinkEdit1.Properties.NullValuePrompt");
			this.hyperLinkEdit1.Properties.NullValuePromptShowForEmptyValue = ((bool)(resources.GetObject("hyperLinkEdit1.Properties.NullValuePromptShowForEmptyValue")));
			this.hyperLinkEdit1.OpenLink += new DevExpress.XtraEditors.Controls.OpenLinkEventHandler(this.hyperLinkEdit1_OpenLink);
			// 
			// labelControl3
			// 
			this.labelControl3.AccessibleDescription = null;
			this.labelControl3.AccessibleName = null;
			resources.ApplyResources(this.labelControl3, "labelControl3");
			this.labelControl3.Name = "labelControl3";
			// 
			// pictureBox3
			// 
			this.pictureBox3.AccessibleDescription = null;
			this.pictureBox3.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.pictureBox3, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("pictureBox3.AllowHtmlText"))));
			resources.ApplyResources(this.pictureBox3, "pictureBox3");
			this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox3.BackgroundImage = null;
			this.pictureBox3.Font = null;
			this.pictureBox3.ImageLocation = null;
			this.pictureBox3.Name = "pictureBox3";
			this.defaultToolTipController1.SetSuperTip(this.pictureBox3, null);
			this.pictureBox3.TabStop = false;
			this.defaultToolTipController1.SetTitle(this.pictureBox3, resources.GetString("pictureBox3.Title"));
			this.defaultToolTipController1.SetToolTip(this.pictureBox3, resources.GetString("pictureBox3.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.pictureBox3, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("pictureBox3.ToolTipIconType"))));
			// 
			// labelControl4
			// 
			this.labelControl4.AccessibleDescription = null;
			this.labelControl4.AccessibleName = null;
			resources.ApplyResources(this.labelControl4, "labelControl4");
			this.labelControl4.Appearance.Options.UseTextOptions = true;
			this.labelControl4.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
			this.labelControl4.Name = "labelControl4";
			// 
			// xtraTabControl1
			// 
			this.xtraTabControl1.AccessibleDescription = null;
			this.xtraTabControl1.AccessibleName = null;
			resources.ApplyResources(this.xtraTabControl1, "xtraTabControl1");
			this.xtraTabControl1.BackgroundImage = null;
			this.xtraTabControl1.Font = null;
			this.xtraTabControl1.Images = this.imageCollection2;
			this.xtraTabControl1.Name = "xtraTabControl1";
			this.xtraTabControl1.SelectedTabPage = this.xtraTabPage1;
			this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1,
            this.xtraTabPage2,
            this.xtraTabPage3});
			// 
			// imageCollection2
			// 
			this.imageCollection2.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection2.ImageStream")));
			this.imageCollection2.Images.SetKeyName(0, "earth_edit.png");
			this.imageCollection2.Images.SetKeyName(1, "spellcheck.png");
			this.imageCollection2.Images.SetKeyName(2, "gear_edit.png");
			// 
			// xtraTabPage1
			// 
			this.xtraTabPage1.AccessibleDescription = null;
			this.xtraTabPage1.AccessibleName = null;
			resources.ApplyResources(this.xtraTabPage1, "xtraTabPage1");
			this.xtraTabPage1.BackgroundImage = null;
			this.xtraTabPage1.Controls.Add(this.groupControl3);
			this.xtraTabPage1.Controls.Add(this.optionsGroupBox);
			this.xtraTabPage1.Font = null;
			this.xtraTabPage1.ImageIndex = 0;
			this.xtraTabPage1.Name = "xtraTabPage1";
			// 
			// groupControl3
			// 
			this.groupControl3.AccessibleDescription = null;
			this.groupControl3.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.groupControl3, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("groupControl3.AllowHtmlText"))));
			resources.ApplyResources(this.groupControl3, "groupControl3");
			this.groupControl3.Controls.Add(this.pictureBox4);
			this.groupControl3.Controls.Add(this.descriptionTextBox);
			this.groupControl3.Name = "groupControl3";
			this.defaultToolTipController1.SetSuperTip(this.groupControl3, null);
			this.defaultToolTipController1.SetTitle(this.groupControl3, resources.GetString("groupControl3.Title"));
			this.defaultToolTipController1.SetToolTip(this.groupControl3, resources.GetString("groupControl3.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.groupControl3, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("groupControl3.ToolTipIconType"))));
			// 
			// pictureBox4
			// 
			this.pictureBox4.AccessibleDescription = null;
			this.pictureBox4.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.pictureBox4, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("pictureBox4.AllowHtmlText"))));
			resources.ApplyResources(this.pictureBox4, "pictureBox4");
			this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox4.BackgroundImage = null;
			this.pictureBox4.Font = null;
			this.pictureBox4.ImageLocation = null;
			this.pictureBox4.Name = "pictureBox4";
			this.defaultToolTipController1.SetSuperTip(this.pictureBox4, null);
			this.pictureBox4.TabStop = false;
			this.defaultToolTipController1.SetTitle(this.pictureBox4, resources.GetString("pictureBox4.Title"));
			this.defaultToolTipController1.SetToolTip(this.pictureBox4, resources.GetString("pictureBox4.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.pictureBox4, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("pictureBox4.ToolTipIconType"))));
			// 
			// xtraTabPage2
			// 
			this.xtraTabPage2.AccessibleDescription = null;
			this.xtraTabPage2.AccessibleName = null;
			resources.ApplyResources(this.xtraTabPage2, "xtraTabPage2");
			this.xtraTabPage2.BackgroundImage = null;
			this.xtraTabPage2.Controls.Add(this.groupControl4);
			this.xtraTabPage2.Controls.Add(this.groupControl1);
			this.xtraTabPage2.Controls.Add(this.groupControl2);
			this.xtraTabPage2.Font = null;
			this.xtraTabPage2.ImageIndex = 2;
			this.xtraTabPage2.Name = "xtraTabPage2";
			// 
			// groupControl4
			// 
			this.groupControl4.AccessibleDescription = null;
			this.groupControl4.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.groupControl4, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("groupControl4.AllowHtmlText"))));
			resources.ApplyResources(this.groupControl4, "groupControl4");
			this.groupControl4.Controls.Add(this.pictureBox8);
			this.groupControl4.Controls.Add(this.pictureBox6);
			this.groupControl4.Controls.Add(this.pictureBox7);
			this.groupControl4.Controls.Add(this.baseNameDotCountSpinEdit);
			this.groupControl4.Controls.Add(this.defaultTypesTextEdit);
			this.groupControl4.Controls.Add(this.nonNeutralLanguageFileNamePatternTextEdit);
			this.groupControl4.Controls.Add(this.neutralLanguageFileNamePatternTextEdit);
			this.groupControl4.Controls.Add(this.pictureBox5);
			this.groupControl4.Controls.Add(this.labelControl10);
			this.groupControl4.Controls.Add(this.labelControl6);
			this.groupControl4.Controls.Add(this.labelControl9);
			this.groupControl4.Controls.Add(this.labelControl8);
			this.groupControl4.Controls.Add(this.labelControl5);
			this.groupControl4.Name = "groupControl4";
			this.defaultToolTipController1.SetSuperTip(this.groupControl4, null);
			this.defaultToolTipController1.SetTitle(this.groupControl4, resources.GetString("groupControl4.Title"));
			this.defaultToolTipController1.SetToolTip(this.groupControl4, resources.GetString("groupControl4.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.groupControl4, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("groupControl4.ToolTipIconType"))));
			// 
			// pictureBox8
			// 
			this.pictureBox8.AccessibleDescription = null;
			this.pictureBox8.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.pictureBox8, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("pictureBox8.AllowHtmlText"))));
			resources.ApplyResources(this.pictureBox8, "pictureBox8");
			this.pictureBox8.BackgroundImage = null;
			this.pictureBox8.Cursor = System.Windows.Forms.Cursors.Help;
			this.pictureBox8.Font = null;
			this.pictureBox8.ImageLocation = null;
			this.pictureBox8.Name = "pictureBox8";
			toolTipTitleItem4.Appearance.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image")));
			toolTipTitleItem4.Appearance.Options.UseImage = true;
			resources.ApplyResources(toolTipTitleItem4, "toolTipTitleItem4");
			toolTipItem4.Image = null;
			resources.ApplyResources(toolTipItem4, "toolTipItem4");
			toolTipItem4.LeftIndent = 6;
			superToolTip4.Items.Add(toolTipTitleItem4);
			superToolTip4.Items.Add(toolTipItem4);
			this.defaultToolTipController1.SetSuperTip(this.pictureBox8, superToolTip4);
			this.pictureBox8.TabStop = false;
			this.defaultToolTipController1.SetTitle(this.pictureBox8, resources.GetString("pictureBox8.Title"));
			this.defaultToolTipController1.SetToolTip(this.pictureBox8, resources.GetString("pictureBox8.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.pictureBox8, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("pictureBox8.ToolTipIconType"))));
			// 
			// pictureBox6
			// 
			this.pictureBox6.AccessibleDescription = null;
			this.pictureBox6.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.pictureBox6, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("pictureBox6.AllowHtmlText"))));
			resources.ApplyResources(this.pictureBox6, "pictureBox6");
			this.pictureBox6.BackgroundImage = null;
			this.pictureBox6.Cursor = System.Windows.Forms.Cursors.Help;
			this.pictureBox6.Font = null;
			this.pictureBox6.ImageLocation = null;
			this.pictureBox6.Name = "pictureBox6";
			toolTipTitleItem5.Appearance.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image1")));
			toolTipTitleItem5.Appearance.Options.UseImage = true;
			resources.ApplyResources(toolTipTitleItem5, "toolTipTitleItem5");
			toolTipItem5.Image = null;
			resources.ApplyResources(toolTipItem5, "toolTipItem5");
			toolTipItem5.LeftIndent = 6;
			superToolTip5.Items.Add(toolTipTitleItem5);
			superToolTip5.Items.Add(toolTipItem5);
			this.defaultToolTipController1.SetSuperTip(this.pictureBox6, superToolTip5);
			this.pictureBox6.TabStop = false;
			this.defaultToolTipController1.SetTitle(this.pictureBox6, resources.GetString("pictureBox6.Title"));
			this.defaultToolTipController1.SetToolTip(this.pictureBox6, resources.GetString("pictureBox6.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.pictureBox6, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("pictureBox6.ToolTipIconType"))));
			// 
			// pictureBox7
			// 
			this.pictureBox7.AccessibleDescription = null;
			this.pictureBox7.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.pictureBox7, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("pictureBox7.AllowHtmlText"))));
			resources.ApplyResources(this.pictureBox7, "pictureBox7");
			this.pictureBox7.BackgroundImage = null;
			this.pictureBox7.Cursor = System.Windows.Forms.Cursors.Help;
			this.pictureBox7.Font = null;
			this.pictureBox7.ImageLocation = null;
			this.pictureBox7.Name = "pictureBox7";
			toolTipTitleItem6.Appearance.Image = ((System.Drawing.Image)(resources.GetObject("resource.Image2")));
			toolTipTitleItem6.Appearance.Options.UseImage = true;
			resources.ApplyResources(toolTipTitleItem6, "toolTipTitleItem6");
			toolTipItem6.Image = null;
			resources.ApplyResources(toolTipItem6, "toolTipItem6");
			toolTipItem6.LeftIndent = 6;
			superToolTip6.Items.Add(toolTipTitleItem6);
			superToolTip6.Items.Add(toolTipItem6);
			this.defaultToolTipController1.SetSuperTip(this.pictureBox7, superToolTip6);
			this.pictureBox7.TabStop = false;
			this.defaultToolTipController1.SetTitle(this.pictureBox7, resources.GetString("pictureBox7.Title"));
			this.defaultToolTipController1.SetToolTip(this.pictureBox7, resources.GetString("pictureBox7.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.pictureBox7, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("pictureBox7.ToolTipIconType"))));
			// 
			// baseNameDotCountSpinEdit
			// 
			resources.ApplyResources(this.baseNameDotCountSpinEdit, "baseNameDotCountSpinEdit");
			this.baseNameDotCountSpinEdit.BackgroundImage = null;
			this.baseNameDotCountSpinEdit.MenuManager = this.barManager;
			this.baseNameDotCountSpinEdit.Name = "baseNameDotCountSpinEdit";
			this.baseNameDotCountSpinEdit.Properties.AccessibleDescription = null;
			this.baseNameDotCountSpinEdit.Properties.AccessibleName = null;
			this.baseNameDotCountSpinEdit.Properties.AutoHeight = ((bool)(resources.GetObject("baseNameDotCountSpinEdit.Properties.AutoHeight")));
			this.baseNameDotCountSpinEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
			this.baseNameDotCountSpinEdit.Properties.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("baseNameDotCountSpinEdit.Properties.Mask.AutoComplete")));
			this.baseNameDotCountSpinEdit.Properties.Mask.BeepOnError = ((bool)(resources.GetObject("baseNameDotCountSpinEdit.Properties.Mask.BeepOnError")));
			this.baseNameDotCountSpinEdit.Properties.Mask.EditMask = resources.GetString("baseNameDotCountSpinEdit.Properties.Mask.EditMask");
			this.baseNameDotCountSpinEdit.Properties.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("baseNameDotCountSpinEdit.Properties.Mask.IgnoreMaskBlank")));
			this.baseNameDotCountSpinEdit.Properties.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("baseNameDotCountSpinEdit.Properties.Mask.MaskType")));
			this.baseNameDotCountSpinEdit.Properties.Mask.PlaceHolder = ((char)(resources.GetObject("baseNameDotCountSpinEdit.Properties.Mask.PlaceHolder")));
			this.baseNameDotCountSpinEdit.Properties.Mask.SaveLiteral = ((bool)(resources.GetObject("baseNameDotCountSpinEdit.Properties.Mask.SaveLiteral")));
			this.baseNameDotCountSpinEdit.Properties.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("baseNameDotCountSpinEdit.Properties.Mask.ShowPlaceHolders")));
			this.baseNameDotCountSpinEdit.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("baseNameDotCountSpinEdit.Properties.Mask.UseMaskAsDisplayFormat")));
			this.baseNameDotCountSpinEdit.Properties.NullValuePrompt = resources.GetString("baseNameDotCountSpinEdit.Properties.NullValuePrompt");
			this.baseNameDotCountSpinEdit.Properties.NullValuePromptShowForEmptyValue = ((bool)(resources.GetObject("baseNameDotCountSpinEdit.Properties.NullValuePromptShowForEmptyValue")));
			// 
			// defaultTypesTextEdit
			// 
			resources.ApplyResources(this.defaultTypesTextEdit, "defaultTypesTextEdit");
			this.defaultTypesTextEdit.BackgroundImage = null;
			this.defaultTypesTextEdit.EditValue = null;
			this.defaultTypesTextEdit.Name = "defaultTypesTextEdit";
			this.defaultTypesTextEdit.Properties.AccessibleDescription = null;
			this.defaultTypesTextEdit.Properties.AccessibleName = null;
			this.defaultTypesTextEdit.Properties.AutoHeight = ((bool)(resources.GetObject("defaultTypesTextEdit.Properties.AutoHeight")));
			this.defaultTypesTextEdit.Properties.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("defaultTypesTextEdit.Properties.Mask.AutoComplete")));
			this.defaultTypesTextEdit.Properties.Mask.BeepOnError = ((bool)(resources.GetObject("defaultTypesTextEdit.Properties.Mask.BeepOnError")));
			this.defaultTypesTextEdit.Properties.Mask.EditMask = resources.GetString("defaultTypesTextEdit.Properties.Mask.EditMask");
			this.defaultTypesTextEdit.Properties.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("defaultTypesTextEdit.Properties.Mask.IgnoreMaskBlank")));
			this.defaultTypesTextEdit.Properties.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("defaultTypesTextEdit.Properties.Mask.MaskType")));
			this.defaultTypesTextEdit.Properties.Mask.PlaceHolder = ((char)(resources.GetObject("defaultTypesTextEdit.Properties.Mask.PlaceHolder")));
			this.defaultTypesTextEdit.Properties.Mask.SaveLiteral = ((bool)(resources.GetObject("defaultTypesTextEdit.Properties.Mask.SaveLiteral")));
			this.defaultTypesTextEdit.Properties.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("defaultTypesTextEdit.Properties.Mask.ShowPlaceHolders")));
			this.defaultTypesTextEdit.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("defaultTypesTextEdit.Properties.Mask.UseMaskAsDisplayFormat")));
			this.defaultTypesTextEdit.Properties.NullValuePrompt = resources.GetString("defaultTypesTextEdit.Properties.NullValuePrompt");
			this.defaultTypesTextEdit.Properties.NullValuePromptShowForEmptyValue = ((bool)(resources.GetObject("defaultTypesTextEdit.Properties.NullValuePromptShowForEmptyValue")));
			// 
			// nonNeutralLanguageFileNamePatternTextEdit
			// 
			resources.ApplyResources(this.nonNeutralLanguageFileNamePatternTextEdit, "nonNeutralLanguageFileNamePatternTextEdit");
			this.nonNeutralLanguageFileNamePatternTextEdit.BackgroundImage = null;
			this.nonNeutralLanguageFileNamePatternTextEdit.EditValue = null;
			this.nonNeutralLanguageFileNamePatternTextEdit.Name = "nonNeutralLanguageFileNamePatternTextEdit";
			this.nonNeutralLanguageFileNamePatternTextEdit.Properties.AccessibleDescription = null;
			this.nonNeutralLanguageFileNamePatternTextEdit.Properties.AccessibleName = null;
			this.nonNeutralLanguageFileNamePatternTextEdit.Properties.AutoHeight = ((bool)(resources.GetObject("nonNeutralLanguageFileNamePatternTextEdit.Properties.AutoHeight")));
			this.nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.AutoComplete")));
			this.nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.BeepOnError = ((bool)(resources.GetObject("nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.BeepOnError")));
			this.nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.EditMask = resources.GetString("nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.EditMask");
			this.nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.IgnoreMaskBlank")));
			this.nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.MaskType")));
			this.nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.PlaceHolder = ((char)(resources.GetObject("nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.PlaceHolder")));
			this.nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.SaveLiteral = ((bool)(resources.GetObject("nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.SaveLiteral")));
			this.nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.ShowPlaceHolders")));
			this.nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("nonNeutralLanguageFileNamePatternTextEdit.Properties.Mask.UseMaskAsDisplayFormat")));
			this.nonNeutralLanguageFileNamePatternTextEdit.Properties.NullValuePrompt = resources.GetString("nonNeutralLanguageFileNamePatternTextEdit.Properties.NullValuePrompt");
			this.nonNeutralLanguageFileNamePatternTextEdit.Properties.NullValuePromptShowForEmptyValue = ((bool)(resources.GetObject("nonNeutralLanguageFileNamePatternTextEdit.Properties.NullValuePromptShowForEmptyV" +
					"alue")));
			// 
			// neutralLanguageFileNamePatternTextEdit
			// 
			resources.ApplyResources(this.neutralLanguageFileNamePatternTextEdit, "neutralLanguageFileNamePatternTextEdit");
			this.neutralLanguageFileNamePatternTextEdit.BackgroundImage = null;
			this.neutralLanguageFileNamePatternTextEdit.EditValue = null;
			this.neutralLanguageFileNamePatternTextEdit.Name = "neutralLanguageFileNamePatternTextEdit";
			this.neutralLanguageFileNamePatternTextEdit.Properties.AccessibleDescription = null;
			this.neutralLanguageFileNamePatternTextEdit.Properties.AccessibleName = null;
			this.neutralLanguageFileNamePatternTextEdit.Properties.AutoHeight = ((bool)(resources.GetObject("neutralLanguageFileNamePatternTextEdit.Properties.AutoHeight")));
			this.neutralLanguageFileNamePatternTextEdit.Properties.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("neutralLanguageFileNamePatternTextEdit.Properties.Mask.AutoComplete")));
			this.neutralLanguageFileNamePatternTextEdit.Properties.Mask.BeepOnError = ((bool)(resources.GetObject("neutralLanguageFileNamePatternTextEdit.Properties.Mask.BeepOnError")));
			this.neutralLanguageFileNamePatternTextEdit.Properties.Mask.EditMask = resources.GetString("neutralLanguageFileNamePatternTextEdit.Properties.Mask.EditMask");
			this.neutralLanguageFileNamePatternTextEdit.Properties.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("neutralLanguageFileNamePatternTextEdit.Properties.Mask.IgnoreMaskBlank")));
			this.neutralLanguageFileNamePatternTextEdit.Properties.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("neutralLanguageFileNamePatternTextEdit.Properties.Mask.MaskType")));
			this.neutralLanguageFileNamePatternTextEdit.Properties.Mask.PlaceHolder = ((char)(resources.GetObject("neutralLanguageFileNamePatternTextEdit.Properties.Mask.PlaceHolder")));
			this.neutralLanguageFileNamePatternTextEdit.Properties.Mask.SaveLiteral = ((bool)(resources.GetObject("neutralLanguageFileNamePatternTextEdit.Properties.Mask.SaveLiteral")));
			this.neutralLanguageFileNamePatternTextEdit.Properties.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("neutralLanguageFileNamePatternTextEdit.Properties.Mask.ShowPlaceHolders")));
			this.neutralLanguageFileNamePatternTextEdit.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("neutralLanguageFileNamePatternTextEdit.Properties.Mask.UseMaskAsDisplayFormat")));
			this.neutralLanguageFileNamePatternTextEdit.Properties.NullValuePrompt = resources.GetString("neutralLanguageFileNamePatternTextEdit.Properties.NullValuePrompt");
			this.neutralLanguageFileNamePatternTextEdit.Properties.NullValuePromptShowForEmptyValue = ((bool)(resources.GetObject("neutralLanguageFileNamePatternTextEdit.Properties.NullValuePromptShowForEmptyValu" +
					"e")));
			// 
			// pictureBox5
			// 
			this.pictureBox5.AccessibleDescription = null;
			this.pictureBox5.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.pictureBox5, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("pictureBox5.AllowHtmlText"))));
			resources.ApplyResources(this.pictureBox5, "pictureBox5");
			this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox5.BackgroundImage = null;
			this.pictureBox5.Font = null;
			this.pictureBox5.ImageLocation = null;
			this.pictureBox5.Name = "pictureBox5";
			this.defaultToolTipController1.SetSuperTip(this.pictureBox5, null);
			this.pictureBox5.TabStop = false;
			this.defaultToolTipController1.SetTitle(this.pictureBox5, resources.GetString("pictureBox5.Title"));
			this.defaultToolTipController1.SetToolTip(this.pictureBox5, resources.GetString("pictureBox5.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.pictureBox5, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("pictureBox5.ToolTipIconType"))));
			// 
			// labelControl10
			// 
			this.labelControl10.AccessibleDescription = null;
			this.labelControl10.AccessibleName = null;
			resources.ApplyResources(this.labelControl10, "labelControl10");
			this.labelControl10.Name = "labelControl10";
			// 
			// labelControl6
			// 
			this.labelControl6.AccessibleDescription = null;
			this.labelControl6.AccessibleName = null;
			resources.ApplyResources(this.labelControl6, "labelControl6");
			this.labelControl6.Name = "labelControl6";
			// 
			// labelControl9
			// 
			this.labelControl9.AccessibleDescription = null;
			this.labelControl9.AccessibleName = null;
			resources.ApplyResources(this.labelControl9, "labelControl9");
			this.labelControl9.Name = "labelControl9";
			// 
			// labelControl8
			// 
			this.labelControl8.AccessibleDescription = null;
			this.labelControl8.AccessibleName = null;
			resources.ApplyResources(this.labelControl8, "labelControl8");
			this.labelControl8.Name = "labelControl8";
			// 
			// labelControl5
			// 
			this.labelControl5.AccessibleDescription = null;
			this.labelControl5.AccessibleName = null;
			resources.ApplyResources(this.labelControl5, "labelControl5");
			this.labelControl5.Name = "labelControl5";
			// 
			// xtraTabPage3
			// 
			this.xtraTabPage3.AccessibleDescription = null;
			this.xtraTabPage3.AccessibleName = null;
			resources.ApplyResources(this.xtraTabPage3, "xtraTabPage3");
			this.xtraTabPage3.BackgroundImage = null;
			this.xtraTabPage3.Controls.Add(this.groupControl6);
			this.xtraTabPage3.Controls.Add(this.groupControl5);
			this.xtraTabPage3.Font = null;
			this.xtraTabPage3.Image = ((System.Drawing.Image)(resources.GetObject("xtraTabPage3.Image")));
			this.xtraTabPage3.Name = "xtraTabPage3";
			// 
			// groupControl6
			// 
			this.groupControl6.AccessibleDescription = null;
			this.groupControl6.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.groupControl6, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("groupControl6.AllowHtmlText"))));
			resources.ApplyResources(this.groupControl6, "groupControl6");
			this.groupControl6.Controls.Add(this.pictureBox10);
			this.groupControl6.Controls.Add(this.showCommentsColumnInGridCheckEdit);
			this.groupControl6.Controls.Add(this.colorifyNullCellsCheckEdit);
			this.groupControl6.Controls.Add(this.persistGridSettingsCheckEdit);
			this.groupControl6.Controls.Add(this.shallowCumulationCheckEdit);
			this.groupControl6.Controls.Add(this.hideEmptyRowsCheck);
			this.groupControl6.Controls.Add(this.hideInternalDesignerRowsCheckEdit);
			this.groupControl6.Name = "groupControl6";
			this.defaultToolTipController1.SetSuperTip(this.groupControl6, null);
			this.defaultToolTipController1.SetTitle(this.groupControl6, resources.GetString("groupControl6.Title"));
			this.defaultToolTipController1.SetToolTip(this.groupControl6, resources.GetString("groupControl6.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.groupControl6, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("groupControl6.ToolTipIconType"))));
			// 
			// pictureBox10
			// 
			this.pictureBox10.AccessibleDescription = null;
			this.pictureBox10.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.pictureBox10, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("pictureBox10.AllowHtmlText"))));
			resources.ApplyResources(this.pictureBox10, "pictureBox10");
			this.pictureBox10.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox10.BackgroundImage = null;
			this.pictureBox10.Font = null;
			this.pictureBox10.ImageLocation = null;
			this.pictureBox10.Name = "pictureBox10";
			this.defaultToolTipController1.SetSuperTip(this.pictureBox10, null);
			this.pictureBox10.TabStop = false;
			this.defaultToolTipController1.SetTitle(this.pictureBox10, resources.GetString("pictureBox10.Title"));
			this.defaultToolTipController1.SetToolTip(this.pictureBox10, resources.GetString("pictureBox10.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.pictureBox10, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("pictureBox10.ToolTipIconType"))));
			// 
			// colorifyNullCellsCheckEdit
			// 
			resources.ApplyResources(this.colorifyNullCellsCheckEdit, "colorifyNullCellsCheckEdit");
			this.colorifyNullCellsCheckEdit.BackgroundImage = null;
			this.colorifyNullCellsCheckEdit.Name = "colorifyNullCellsCheckEdit";
			this.colorifyNullCellsCheckEdit.Properties.AccessibleDescription = null;
			this.colorifyNullCellsCheckEdit.Properties.AccessibleName = null;
			this.colorifyNullCellsCheckEdit.Properties.AutoHeight = ((bool)(resources.GetObject("colorifyNullCellsCheckEdit.Properties.AutoHeight")));
			this.colorifyNullCellsCheckEdit.Properties.AutoWidth = true;
			this.colorifyNullCellsCheckEdit.Properties.Caption = resources.GetString("colorifyNullCellsCheckEdit.Properties.Caption");
			this.colorifyNullCellsCheckEdit.Properties.DisplayValueChecked = resources.GetString("colorifyNullCellsCheckEdit.Properties.DisplayValueChecked");
			this.colorifyNullCellsCheckEdit.Properties.DisplayValueGrayed = resources.GetString("colorifyNullCellsCheckEdit.Properties.DisplayValueGrayed");
			this.colorifyNullCellsCheckEdit.Properties.DisplayValueUnchecked = resources.GetString("colorifyNullCellsCheckEdit.Properties.DisplayValueUnchecked");
			// 
			// persistGridSettingsCheckEdit
			// 
			resources.ApplyResources(this.persistGridSettingsCheckEdit, "persistGridSettingsCheckEdit");
			this.persistGridSettingsCheckEdit.BackgroundImage = null;
			this.persistGridSettingsCheckEdit.Name = "persistGridSettingsCheckEdit";
			this.persistGridSettingsCheckEdit.Properties.AccessibleDescription = null;
			this.persistGridSettingsCheckEdit.Properties.AccessibleName = null;
			this.persistGridSettingsCheckEdit.Properties.AutoHeight = ((bool)(resources.GetObject("persistGridSettingsCheckEdit.Properties.AutoHeight")));
			this.persistGridSettingsCheckEdit.Properties.AutoWidth = true;
			this.persistGridSettingsCheckEdit.Properties.Caption = resources.GetString("persistGridSettingsCheckEdit.Properties.Caption");
			this.persistGridSettingsCheckEdit.Properties.DisplayValueChecked = resources.GetString("persistGridSettingsCheckEdit.Properties.DisplayValueChecked");
			this.persistGridSettingsCheckEdit.Properties.DisplayValueGrayed = resources.GetString("persistGridSettingsCheckEdit.Properties.DisplayValueGrayed");
			this.persistGridSettingsCheckEdit.Properties.DisplayValueUnchecked = resources.GetString("persistGridSettingsCheckEdit.Properties.DisplayValueUnchecked");
			// 
			// groupControl5
			// 
			this.groupControl5.AccessibleDescription = null;
			this.groupControl5.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.groupControl5, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("groupControl5.AllowHtmlText"))));
			resources.ApplyResources(this.groupControl5, "groupControl5");
			this.groupControl5.Controls.Add(this.useCrypticExcelExportSheetNamesCheckEdit);
			this.groupControl5.Controls.Add(this.pictureBox9);
			this.groupControl5.Name = "groupControl5";
			this.defaultToolTipController1.SetSuperTip(this.groupControl5, null);
			this.defaultToolTipController1.SetTitle(this.groupControl5, resources.GetString("groupControl5.Title"));
			this.defaultToolTipController1.SetToolTip(this.groupControl5, resources.GetString("groupControl5.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.groupControl5, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("groupControl5.ToolTipIconType"))));
			// 
			// useCrypticExcelExportSheetNamesCheckEdit
			// 
			resources.ApplyResources(this.useCrypticExcelExportSheetNamesCheckEdit, "useCrypticExcelExportSheetNamesCheckEdit");
			this.useCrypticExcelExportSheetNamesCheckEdit.BackgroundImage = null;
			this.useCrypticExcelExportSheetNamesCheckEdit.Name = "useCrypticExcelExportSheetNamesCheckEdit";
			this.useCrypticExcelExportSheetNamesCheckEdit.Properties.AccessibleDescription = null;
			this.useCrypticExcelExportSheetNamesCheckEdit.Properties.AccessibleName = null;
			this.useCrypticExcelExportSheetNamesCheckEdit.Properties.AutoHeight = ((bool)(resources.GetObject("useCrypticExcelExportSheetNamesCheckEdit.Properties.AutoHeight")));
			this.useCrypticExcelExportSheetNamesCheckEdit.Properties.AutoWidth = true;
			this.useCrypticExcelExportSheetNamesCheckEdit.Properties.Caption = resources.GetString("useCrypticExcelExportSheetNamesCheckEdit.Properties.Caption");
			this.useCrypticExcelExportSheetNamesCheckEdit.Properties.DisplayValueChecked = resources.GetString("useCrypticExcelExportSheetNamesCheckEdit.Properties.DisplayValueChecked");
			this.useCrypticExcelExportSheetNamesCheckEdit.Properties.DisplayValueGrayed = resources.GetString("useCrypticExcelExportSheetNamesCheckEdit.Properties.DisplayValueGrayed");
			this.useCrypticExcelExportSheetNamesCheckEdit.Properties.DisplayValueUnchecked = resources.GetString("useCrypticExcelExportSheetNamesCheckEdit.Properties.DisplayValueUnchecked");
			// 
			// pictureBox9
			// 
			this.pictureBox9.AccessibleDescription = null;
			this.pictureBox9.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.pictureBox9, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("pictureBox9.AllowHtmlText"))));
			resources.ApplyResources(this.pictureBox9, "pictureBox9");
			this.pictureBox9.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox9.BackgroundImage = null;
			this.pictureBox9.Font = null;
			this.pictureBox9.ImageLocation = null;
			this.pictureBox9.Name = "pictureBox9";
			this.defaultToolTipController1.SetSuperTip(this.pictureBox9, null);
			this.pictureBox9.TabStop = false;
			this.defaultToolTipController1.SetTitle(this.pictureBox9, resources.GetString("pictureBox9.Title"));
			this.defaultToolTipController1.SetToolTip(this.pictureBox9, resources.GetString("pictureBox9.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.pictureBox9, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("pictureBox9.ToolTipIconType"))));
			// 
			// panelControl1
			// 
			this.panelControl1.AccessibleDescription = null;
			this.panelControl1.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this.panelControl1, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("panelControl1.AllowHtmlText"))));
			resources.ApplyResources(this.panelControl1, "panelControl1");
			this.panelControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
			this.panelControl1.Controls.Add(this.xtraTabControl1);
			this.panelControl1.Controls.Add(this.buttonCancel);
			this.panelControl1.Controls.Add(this.buttonOK);
			this.panelControl1.Name = "panelControl1";
			this.defaultToolTipController1.SetSuperTip(this.panelControl1, null);
			this.defaultToolTipController1.SetTitle(this.panelControl1, resources.GetString("panelControl1.Title"));
			this.defaultToolTipController1.SetToolTip(this.panelControl1, resources.GetString("panelControl1.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this.panelControl1, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("panelControl1.ToolTipIconType"))));
			// 
			// defaultToolTipController1
			// 
			// 
			// 
			// 
			this.defaultToolTipController1.DefaultController.AutoPopDelay = 50000;
			// 
			// ProjectSettingsForm
			// 
			this.AcceptButton = this.buttonOK;
			this.AccessibleDescription = null;
			this.AccessibleName = null;
			this.defaultToolTipController1.SetAllowHtmlText(this, ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("$this.AllowHtmlText"))));
			this.Appearance.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			this.Appearance.Options.UseFont = true;
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			resources.ApplyResources(this, "$this");
			this.CancelButton = this.buttonCancel;
			this.Controls.Add(this.panelControl1);
			this.Controls.Add(this.barDockControlLeft);
			this.Controls.Add(this.barDockControlRight);
			this.Controls.Add(this.barDockControlBottom);
			this.Controls.Add(this.barDockControlTop);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ProjectSettingsForm";
			this.ShowInTaskbar = false;
			this.defaultToolTipController1.SetSuperTip(this, null);
			this.defaultToolTipController1.SetTitle(this, resources.GetString("$this.Title"));
			this.defaultToolTipController1.SetToolTip(this, resources.GetString("$this.ToolTip"));
			this.defaultToolTipController1.SetToolTipIconType(this, ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("$this.ToolTipIconType"))));
			this.Load += new System.EventHandler(this.projectSettingsForm_Load);
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.projectSettingsForm_FormClosing);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.optionsGroupBox)).EndInit();
			this.optionsGroupBox.ResumeLayout(false);
			this.optionsGroupBox.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.readOnlySaveBehaviourComboBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.barManager)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.ignoreWindowsFormsDesignerFiles.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.optionsPopupMenu)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.omitEmptyItemsCheckBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.createBackupsCheckBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.nameTextBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.locationTextBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.hideInternalDesignerRowsCheckEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.shallowCumulationCheckEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.showCommentsColumnInGridCheckEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.hideEmptyRowsCheck.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.descriptionTextBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.neutralLanguageCodeTextEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.useSpellCheckingCheckEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
			this.groupControl1.ResumeLayout(false);
			this.groupControl1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
			this.groupControl2.ResumeLayout(false);
			this.groupControl2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.hyperLinkEdit1.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
			this.xtraTabControl1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.imageCollection2)).EndInit();
			this.xtraTabPage1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.groupControl3)).EndInit();
			this.groupControl3.ResumeLayout(false);
			this.groupControl3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
			this.xtraTabPage2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.groupControl4)).EndInit();
			this.groupControl4.ResumeLayout(false);
			this.groupControl4.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.baseNameDotCountSpinEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.defaultTypesTextEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.nonNeutralLanguageFileNamePatternTextEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.neutralLanguageFileNamePatternTextEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
			this.xtraTabPage3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.groupControl6)).EndInit();
			this.groupControl6.ResumeLayout(false);
			this.groupControl6.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.colorifyNullCellsCheckEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.persistGridSettingsCheckEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.groupControl5)).EndInit();
			this.groupControl5.ResumeLayout(false);
			this.groupControl5.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.useCrypticExcelExportSheetNamesCheckEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
			this.panelControl1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.PictureBox pictureBox1;
		private DevExpress.XtraEditors.GroupControl optionsGroupBox;
		private DevExpress.XtraEditors.SimpleButton buttonCancel;
		private DevExpress.XtraEditors.SimpleButton buttonOK;
		private DevExpress.XtraEditors.TextEdit nameTextBox;
		private DevExpress.XtraEditors.TextEdit locationTextBox;
		private DevExpress.XtraEditors.LabelControl label2;
		private DevExpress.XtraEditors.LabelControl label1;
		private DevExpress.XtraEditors.CheckEdit omitEmptyItemsCheckBox;
		private DevExpress.XtraEditors.CheckEdit createBackupsCheckBox;
		private DevExpress.XtraEditors.MemoEdit descriptionTextBox;
		private DevExpress.XtraEditors.DropDownButton button1;
		private DevExpress.XtraBars.PopupMenu optionsPopupMenu;
		private DevExpress.XtraBars.BarButtonItem openButton;
		private DevExpress.XtraBars.BarManager barManager;
		private DevExpress.XtraBars.BarDockControl barDockControlTop;
		private DevExpress.XtraBars.BarDockControl barDockControlBottom;
		private DevExpress.XtraBars.BarDockControl barDockControlLeft;
		private DevExpress.XtraBars.BarDockControl barDockControlRight;
		private DevExpress.Utils.ImageCollection imageCollection1;
		private DevExpress.XtraEditors.TextEdit neutralLanguageCodeTextEdit;
		private DevExpress.XtraEditors.LabelControl labelControl2;
		private DevExpress.XtraEditors.LabelControl labelControl1;
		private DevExpress.XtraEditors.CheckEdit hideEmptyRowsCheck;
		private DevExpress.XtraEditors.CheckEdit useSpellCheckingCheckEdit;
		private DevExpress.XtraEditors.GroupControl groupControl1;
		private System.Windows.Forms.PictureBox pictureBox2;
		private DevExpress.XtraEditors.GroupControl groupControl2;
		private DevExpress.XtraEditors.HyperLinkEdit hyperLinkEdit1;
		private DevExpress.XtraEditors.LabelControl labelControl3;
		private System.Windows.Forms.PictureBox pictureBox3;
		private DevExpress.XtraEditors.LabelControl labelControl4;
		private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
		private DevExpress.Utils.ImageCollection imageCollection2;
		private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
		private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
		private DevExpress.XtraEditors.GroupControl groupControl3;
		private System.Windows.Forms.PictureBox pictureBox4;
		private DevExpress.XtraEditors.CheckEdit ignoreWindowsFormsDesignerFiles;
		private DevExpress.XtraEditors.PanelControl panelControl1;
		private DevExpress.XtraEditors.CheckEdit hideInternalDesignerRowsCheckEdit;
		private DevExpress.XtraEditors.GroupControl groupControl4;
		private DevExpress.XtraEditors.TextEdit neutralLanguageFileNamePatternTextEdit;
		private System.Windows.Forms.PictureBox pictureBox5;
		private DevExpress.XtraEditors.LabelControl labelControl5;
		private DevExpress.XtraEditors.TextEdit nonNeutralLanguageFileNamePatternTextEdit;
		private DevExpress.XtraEditors.LabelControl labelControl8;
		private DevExpress.XtraEditors.LabelControl labelControl9;
		private DevExpress.XtraEditors.SpinEdit baseNameDotCountSpinEdit;
		private DevExpress.XtraEditors.LabelControl labelControl10;
		private DevExpress.Utils.DefaultToolTipController defaultToolTipController1;
		private System.Windows.Forms.PictureBox pictureBox7;
		private System.Windows.Forms.PictureBox pictureBox6;
		private System.Windows.Forms.PictureBox pictureBox8;
		private DevExpress.XtraEditors.TextEdit defaultTypesTextEdit;
		private DevExpress.XtraEditors.LabelControl labelControl6;
		private DevExpress.XtraEditors.CheckEdit showCommentsColumnInGridCheckEdit;
		private DevExpress.XtraTab.XtraTabPage xtraTabPage3;
		private DevExpress.XtraEditors.GroupControl groupControl5;
		private System.Windows.Forms.PictureBox pictureBox9;
		private DevExpress.XtraEditors.CheckEdit useCrypticExcelExportSheetNamesCheckEdit;
		private DevExpress.XtraEditors.ComboBoxEdit readOnlySaveBehaviourComboBox;
		private DevExpress.XtraEditors.LabelControl labelControl7;
		private DevExpress.XtraEditors.CheckEdit shallowCumulationCheckEdit;
        private DevExpress.XtraEditors.GroupControl groupControl6;
        private System.Windows.Forms.PictureBox pictureBox10;
        private DevExpress.XtraEditors.CheckEdit persistGridSettingsCheckEdit;
		private DevExpress.XtraEditors.CheckEdit colorifyNullCellsCheckEdit;
	}
}