namespace ZetaResourceEditor.UI.Helper
{
	partial class TextBoxForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose( bool disposing )
		{
			if ( disposing && (components != null) )
			{
				components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager( typeof( TextBoxForm ) );
			this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
			this.wordWrapCheckEdit = new DevExpress.XtraEditors.CheckEdit();
			this.textMemoEdit = new DevExpress.XtraEditors.MemoEdit();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.buttonCancel = new DevExpress.XtraEditors.SimpleButton();
			this.buttonCopyTextToClipboard = new DevExpress.XtraEditors.SimpleButton();
			((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
			this.groupControl1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.wordWrapCheckEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.textMemoEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// groupControl1
			// 
			resources.ApplyResources( this.groupControl1, "groupControl1" );
			this.groupControl1.Controls.Add( this.wordWrapCheckEdit );
			this.groupControl1.Controls.Add( this.textMemoEdit );
			this.groupControl1.Controls.Add( this.pictureBox1 );
			this.groupControl1.Name = "groupControl1";
			// 
			// wordWrapCheckEdit
			// 
			resources.ApplyResources( this.wordWrapCheckEdit, "wordWrapCheckEdit" );
			this.wordWrapCheckEdit.Name = "wordWrapCheckEdit";
			this.wordWrapCheckEdit.Properties.AutoWidth = true;
			this.wordWrapCheckEdit.Properties.Caption = resources.GetString( "wordWrapCheckEdit.Properties.Caption" );
			this.wordWrapCheckEdit.CheckedChanged += new System.EventHandler( this.wordWrapCheckEdit_CheckedChanged );
			// 
			// textMemoEdit
			// 
			resources.ApplyResources( this.textMemoEdit, "textMemoEdit" );
			this.textMemoEdit.Name = "textMemoEdit";
			this.textMemoEdit.Properties.Appearance.BackColor = System.Drawing.SystemColors.Window;
			this.textMemoEdit.Properties.Appearance.Font = new System.Drawing.Font( "Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)) );
			this.textMemoEdit.Properties.Appearance.Options.UseBackColor = true;
			this.textMemoEdit.Properties.Appearance.Options.UseFont = true;
			this.textMemoEdit.Properties.ReadOnly = true;
			this.textMemoEdit.KeyDown += new System.Windows.Forms.KeyEventHandler( this.textMemoEdit_KeyDown );
			// 
			// pictureBox1
			// 
			resources.ApplyResources( this.pictureBox1, "pictureBox1" );
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.TabStop = false;
			// 
			// buttonCancel
			// 
			resources.ApplyResources( this.buttonCancel, "buttonCancel" );
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.Name = "buttonCancel";
			// 
			// buttonCopyTextToClipboard
			// 
			resources.ApplyResources( this.buttonCopyTextToClipboard, "buttonCopyTextToClipboard" );
			this.buttonCopyTextToClipboard.Image = ((System.Drawing.Image)(resources.GetObject( "buttonCopyTextToClipboard.Image" )));
			this.buttonCopyTextToClipboard.Name = "buttonCopyTextToClipboard";
			this.buttonCopyTextToClipboard.Click += new System.EventHandler( this.buttonCopyTextToClipboard_Click );
			// 
			// TextBoxForm
			// 
			resources.ApplyResources( this, "$this" );
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.Controls.Add( this.groupControl1 );
			this.Controls.Add( this.buttonCopyTextToClipboard );
			this.Controls.Add( this.buttonCancel );
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "TextBoxForm";
			this.ShowInTaskbar = false;
			this.Load += new System.EventHandler( this.textBoxForm_Load );
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler( this.textBoxForm_FormClosing );
			((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
			this.groupControl1.ResumeLayout( false );
			this.groupControl1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.wordWrapCheckEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.textMemoEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout( false );

		}

		#endregion

		private DevExpress.XtraEditors.GroupControl groupControl1;
		private DevExpress.XtraEditors.MemoEdit textMemoEdit;
		private System.Windows.Forms.PictureBox pictureBox1;
		private DevExpress.XtraEditors.SimpleButton buttonCancel;
		private DevExpress.XtraEditors.SimpleButton buttonCopyTextToClipboard;
		private DevExpress.XtraEditors.CheckEdit wordWrapCheckEdit;
	}
}