namespace ZetaResourceEditor.UI.Helper
{
	partial class ReportItemsForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose( bool disposing )
		{
			if ( disposing && (components != null) )
			{
				components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager( typeof( ReportItemsForm ) );
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.supportUserControl1 = new ZetaResourceEditor.UI.Helper.SupportUserControl();
			this.groupBox2 = new DevExpress.XtraEditors.GroupControl();
			this.itemsListView = new DevExpress.XtraEditors.ImageListBoxControl();
			this.imageCollection1 = new DevExpress.Utils.ImageCollection( this.components );
			this.label1 = new DevExpress.XtraEditors.LabelControl();
			this.buttonShow = new DevExpress.XtraEditors.SimpleButton();
			this.groupBox1 = new DevExpress.XtraEditors.GroupControl();
			this.additionalRemarksTextBox = new DevExpress.XtraEditors.MemoEdit();
			this.emailAddressTextBox = new DevExpress.XtraEditors.TextEdit();
			this.label4 = new DevExpress.XtraEditors.LabelControl();
			this.label3 = new DevExpress.XtraEditors.LabelControl();
			this.buttonOK = new DevExpress.XtraEditors.SimpleButton();
			this.buttonCancel = new DevExpress.XtraEditors.SimpleButton();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.groupBox2)).BeginInit();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.itemsListView)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.groupBox1)).BeginInit();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.additionalRemarksTextBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.emailAddressTextBox.Properties)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			resources.ApplyResources( this.pictureBox1, "pictureBox1" );
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.TabStop = false;
			// 
			// pictureBox2
			// 
			resources.ApplyResources( this.pictureBox2, "pictureBox2" );
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.TabStop = false;
			// 
			// supportUserControl1
			// 
			resources.ApplyResources( this.supportUserControl1, "supportUserControl1" );
			this.supportUserControl1.MaximumSize = new System.Drawing.Size( 142, 17 );
			this.supportUserControl1.MinimumSize = new System.Drawing.Size( 142, 17 );
			this.supportUserControl1.Name = "supportUserControl1";
			// 
			// groupBox2
			// 
			resources.ApplyResources( this.groupBox2, "groupBox2" );
			this.groupBox2.Controls.Add( this.itemsListView );
			this.groupBox2.Controls.Add( this.label1 );
			this.groupBox2.Controls.Add( this.buttonShow );
			this.groupBox2.Controls.Add( this.pictureBox2 );
			this.groupBox2.Name = "groupBox2";
			// 
			// itemsListView
			// 
			resources.ApplyResources( this.itemsListView, "itemsListView" );
			this.itemsListView.ImageList = this.imageCollection1;
			this.itemsListView.Name = "itemsListView";
			this.itemsListView.DoubleClick += new System.EventHandler( this.itemsListView_DoubleClick );
			this.itemsListView.SelectedIndexChanged += new System.EventHandler( this.itemsListView_SelectedIndexChanged );
			// 
			// imageCollection1
			// 
			this.imageCollection1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject( "imageCollection1.ImageStream" )));
			this.imageCollection1.Images.SetKeyName( 0, "document" );
			// 
			// label1
			// 
			resources.ApplyResources( this.label1, "label1" );
			this.label1.Name = "label1";
			// 
			// buttonShow
			// 
			resources.ApplyResources( this.buttonShow, "buttonShow" );
			this.buttonShow.Image = ((System.Drawing.Image)(resources.GetObject( "buttonShow.Image" )));
			this.buttonShow.Name = "buttonShow";
			this.buttonShow.Click += new System.EventHandler( this.buttonShow_Click );
			// 
			// groupBox1
			// 
			resources.ApplyResources( this.groupBox1, "groupBox1" );
			this.groupBox1.Controls.Add( this.additionalRemarksTextBox );
			this.groupBox1.Controls.Add( this.emailAddressTextBox );
			this.groupBox1.Controls.Add( this.label4 );
			this.groupBox1.Controls.Add( this.label3 );
			this.groupBox1.Controls.Add( this.pictureBox1 );
			this.groupBox1.Name = "groupBox1";
			// 
			// additionalRemarksTextBox
			// 
			resources.ApplyResources( this.additionalRemarksTextBox, "additionalRemarksTextBox" );
			this.additionalRemarksTextBox.Name = "additionalRemarksTextBox";
			// 
			// emailAddressTextBox
			// 
			resources.ApplyResources( this.emailAddressTextBox, "emailAddressTextBox" );
			this.emailAddressTextBox.Name = "emailAddressTextBox";
			// 
			// label4
			// 
			resources.ApplyResources( this.label4, "label4" );
			this.label4.Name = "label4";
			// 
			// label3
			// 
			resources.ApplyResources( this.label3, "label3" );
			this.label3.Name = "label3";
			// 
			// buttonOK
			// 
			resources.ApplyResources( this.buttonOK, "buttonOK" );
			this.buttonOK.Image = ((System.Drawing.Image)(resources.GetObject( "buttonOK.Image" )));
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Click += new System.EventHandler( this.buttonOK_Click );
			// 
			// buttonCancel
			// 
			resources.ApplyResources( this.buttonCancel, "buttonCancel" );
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.Name = "buttonCancel";
			// 
			// ReportItemsForm
			// 
			this.AcceptButton = this.buttonOK;
			resources.ApplyResources( this, "$this" );
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.CancelButton = this.buttonCancel;
			this.Controls.Add( this.buttonCancel );
			this.Controls.Add( this.buttonOK );
			this.Controls.Add( this.groupBox1 );
			this.Controls.Add( this.groupBox2 );
			this.Controls.Add( this.supportUserControl1 );
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ReportItemsForm";
			this.ShowInTaskbar = false;
			this.Load += new System.EventHandler( this.ReportIssueForm_Load );
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler( this.ReportIssueForm_FormClosing );
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.groupBox2)).EndInit();
			this.groupBox2.ResumeLayout( false );
			this.groupBox2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.itemsListView)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.groupBox1)).EndInit();
			this.groupBox1.ResumeLayout( false );
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.additionalRemarksTextBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.emailAddressTextBox.Properties)).EndInit();
			this.ResumeLayout( false );

		}

		#endregion

		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.PictureBox pictureBox2;
		private SupportUserControl supportUserControl1;
		private DevExpress.XtraEditors.GroupControl groupBox2;
		private DevExpress.XtraEditors.LabelControl label1;
		private DevExpress.XtraEditors.SimpleButton buttonShow;
		private DevExpress.XtraEditors.GroupControl groupBox1;
		private DevExpress.XtraEditors.MemoEdit additionalRemarksTextBox;
		private DevExpress.XtraEditors.TextEdit emailAddressTextBox;
		private DevExpress.XtraEditors.LabelControl label4;
		private DevExpress.XtraEditors.LabelControl label3;
		private DevExpress.XtraEditors.SimpleButton buttonOK;
		private DevExpress.XtraEditors.SimpleButton buttonCancel;
		private DevExpress.XtraEditors.ImageListBoxControl itemsListView;
		private DevExpress.Utils.ImageCollection imageCollection1;
	}
}