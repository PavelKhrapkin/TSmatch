﻿namespace ZetaResourceEditor.Code.DL
{
	public interface ITranslationStateInformation
	{
		FileGroupStateColor TranslationStateColor
		{
			get;
		}
	}
}