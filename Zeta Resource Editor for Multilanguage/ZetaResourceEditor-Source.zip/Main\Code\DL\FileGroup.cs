namespace ZetaResourceEditor.Code.DL
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System;
	using System.Collections.Generic;
	using System.Data;
	using System.Globalization;
	using System.IO;
	using System.Text;
	using System.Text.RegularExpressions;
	using System.Xml;
	using AppHost;
	using Helper;
	using Properties;
	using Zeta.EnterpriseLibrary.Common;
	using Zeta.EnterpriseLibrary.Common.Collections;
	using Zeta.EnterpriseLibrary.Common.IO;
	using Zeta.EnterpriseLibrary.Windows.Controls;

	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// Groups multiple single files.
	/// </summary>
	public class FileGroup :
		List<FileFileInfo>,
		ITranslationStateInformation,
		IComparable,
		IComparable<FileGroup>,
		IUniqueID,
		IOrderPosition,
		IGridEditableData
	{
		public FileGroup(Project project)
		{
			_project = project;
		}

		private Project _project;

		private string _name;
		private Guid _projectFolderUniqueID;
		private int _orderPosition;

		FileFileInfo[] IGridEditableData.GetFileFileInfosSorted()
		{
			Sort();
			return ToArray();
		}

		public IInheritedSettings ParentSettings
		{
			get
			{
				var projectFolder = ProjectFolder;
				var project = Project;

				if (projectFolder == null)
				{
					if (project == null)
					{
						// When opening without a project,
						// use a dummy project.
						return Project.Empty;
					}
					else
					{
						return project;
					}
				}
				else
				{
					return projectFolder;
				}
			}
		}

		public static FileGroupStateColor TranslateStateToColorKey(
			FileGroupStates state)
		{
			if (state == FileGroupStates.Empty)
			{
				return FileGroupStateColor.Grey;
			}
			else if (state == FileGroupStates.CompletelyTranslated)
			{
				return FileGroupStateColor.Green;
			}
			else if ((state & FileGroupStates.FormatParameterMismatches) != 0)
			{
				return FileGroupStateColor.Red;
			}
			else if ((state & FileGroupStates.TranslationsMissing) != 0)
			{
				return FileGroupStateColor.Yellow;
			}
			// AJ CHANGE
			// Let's use Blue for comments since it's not used earlier and the picture is in place
			else if ((state & FileGroupStates.AutomaticTranslationsExist) != 0)
			{
				return FileGroupStateColor.Blue;
			}
			else //if ((state & FileGroupStates.EmptyRows) != 0)
			{
				return FileGroupStateColor.Green;
				//}
				//else
				//{
				//    return FileGroupStateColor.Blue;
			}
		}

		public static FileGroupStateColor CombineColorKeys(
			FileGroupStateColor c1,
			FileGroupStateColor c2)
		{
			if (c1 == FileGroupStateColor.None) return c2;

			switch (c2)
			{
				case FileGroupStateColor.None:
					return c1;

				case FileGroupStateColor.Grey:
					return c1;

				case FileGroupStateColor.Green:
					switch (c1)
					{
						case FileGroupStateColor.Grey:
						case FileGroupStateColor.Yellow:
							return FileGroupStateColor.Yellow;
						case FileGroupStateColor.Green:
							return FileGroupStateColor.Green;
						case FileGroupStateColor.Blue:
							return FileGroupStateColor.Blue;
						case FileGroupStateColor.Red:
							return FileGroupStateColor.Red;

						default:
							throw new ArgumentException();
					}

				case FileGroupStateColor.Yellow:
					switch (c1)
					{
						case FileGroupStateColor.Grey:
						case FileGroupStateColor.Green:
						case FileGroupStateColor.Yellow:
						case FileGroupStateColor.Blue:
							return FileGroupStateColor.Yellow;
						case FileGroupStateColor.Red:
							return FileGroupStateColor.Red;

						default:
							throw new ArgumentException();
					}

				case FileGroupStateColor.Red:
					return FileGroupStateColor.Red;

				case FileGroupStateColor.Blue:
					switch (c1)
					{
						case FileGroupStateColor.Green:
						case FileGroupStateColor.Blue:
							return FileGroupStateColor.Blue;
						case FileGroupStateColor.Grey:
						case FileGroupStateColor.Yellow:
							return FileGroupStateColor.Yellow;
						case FileGroupStateColor.Red:
							return FileGroupStateColor.Red;

						default:
							throw new ArgumentException();
					}
				default:
					throw new ArgumentException();
			}
		}

		//public static FileGroupStateColor CombineColorKeys(
		//    FileGroupStateColor c1,
		//    FileGroupStateColor c2 )
		//{
		//    switch ( c2 )
		//    {
		//        case FileGroupStateColor.Grey:
		//            switch ( c1 )
		//            {
		//                case FileGroupStateColor.Grey:
		//                    return FileGroupStateColor.Grey;
		//                case FileGroupStateColor.Green:
		//                    return FileGroupStateColor.Green;
		//                case FileGroupStateColor.Yellow:
		//                    return FileGroupStateColor.Yellow;
		//                case FileGroupStateColor.Red:
		//                    return FileGroupStateColor.Red;

		//                default:
		//                    throw new ArgumentException();
		//            }

		//        case FileGroupStateColor.Green:
		//            switch ( c1 )
		//            {
		//                case FileGroupStateColor.Grey:
		//                    return FileGroupStateColor.Green;
		//                case FileGroupStateColor.Green:
		//                    return FileGroupStateColor.Green;
		//                case FileGroupStateColor.Yellow:
		//                    return FileGroupStateColor.Yellow;
		//                case FileGroupStateColor.Red:
		//                    return FileGroupStateColor.Red;

		//                default:
		//                    throw new ArgumentException();
		//            }

		//        case FileGroupStateColor.Yellow:
		//            switch ( c1 )
		//            {
		//                case FileGroupStateColor.Grey:
		//                    return FileGroupStateColor.Yellow;
		//                case FileGroupStateColor.Green:
		//                    return FileGroupStateColor.Yellow;
		//                case FileGroupStateColor.Yellow:
		//                    return FileGroupStateColor.Yellow;
		//                case FileGroupStateColor.Red:
		//                    return FileGroupStateColor.Red;

		//                default:
		//                    throw new ArgumentException();
		//            }

		//        case FileGroupStateColor.Red:
		//            switch ( c1 )
		//            {
		//                case FileGroupStateColor.Grey:
		//                    return FileGroupStateColor.Red;
		//                case FileGroupStateColor.Green:
		//                    return FileGroupStateColor.Red;
		//                case FileGroupStateColor.Yellow:
		//                    return FileGroupStateColor.Red;
		//                case FileGroupStateColor.Red:
		//                    return FileGroupStateColor.Red;

		//                default:
		//                    throw new ArgumentException();
		//            }

		//        default:
		//            throw new ArgumentException();
		//    }
		//}

		public ProjectFolder ProjectFolder
		{
			get
			{
				return _project == null ? null : _project.GetProjectFolderByUniqueID(_projectFolderUniqueID);
			}
			set
			{
				if (value == null)
				{
					_projectFolderUniqueID = Guid.Empty;
				}
				else
				{
					_projectFolderUniqueID = value.UniqueID;
				}
			}
		}

		public static FileGroup CheckCreate(
			Project project,
			string joinedFilePaths)
		{
			if (string.IsNullOrEmpty(joinedFilePaths))
			{
				return new FileGroup(project);
			}
			else
			{
				return CheckCreate(project, SplitFilePaths(joinedFilePaths));
			}
		}

		/*
				/// <summary>
				/// Creates the specified joined file paths.
				/// </summary>
				/// <param name="project">The project.</param>
				/// <param name="joinedFilePaths">The joined file paths.</param>
				/// <returns></returns>
				internal static FileGroup Create(
					Project project,
					string joinedFilePaths )
				{
					if ( string.IsNullOrEmpty( joinedFilePaths ) )
					{
						return new FileGroup( project );
					}
					else
					{
						return create( project, SplitFilePaths( joinedFilePaths ) );
					}
				}
		*/

		/*
				/// <summary>
				/// Creates a new <see cref="FileGroup"/> object with the specified file paths.
				/// </summary>
				/// <param name="project">The project.</param>
				/// <param name="filePaths">The file paths.</param>
				/// <returns></returns>
				private static FileGroup create(
					Project project,
					IEnumerable<string> filePaths )
				{
					var fs = new List<FileInfo>();

					foreach ( var filePath in filePaths )
					{
						fs.Add( new FileInfo( filePath ) );
					}

					return create( project, fs.ToArray() );
				}
		*/

		public static FileGroup CheckCreate(
			Project project,
			string[] filePaths)
		{
			var fs = new List<FileInfo>();

			foreach (var filePath in filePaths)
			{
				fs.Add(new FileInfo(filePath));
			}

			return CheckCreate(project, fs.ToArray());
		}

		/*
				/// <summary>
				/// Creates a new <see cref="FileGroup"/> object with the specified file paths.
				/// </summary>
				/// <param name="project">The project.</param>
				/// <param name="filePaths">The file paths.</param>
				/// <returns></returns>
				private static FileGroup create(
					Project project,
					ICollection<FileInfo> filePaths )
				{
					var result = new FileGroup( project );

					if ( filePaths.Count > 0 )
					{
						foreach ( var filePath in filePaths )
						{
							result.Add(
								new FileFileInfo( result )
									{
										File = filePath
									} );
						}
					}

					return result;
				}
		*/

		public static FileGroup CheckCreate(
			Project project,
			FileInfo[] filePaths)
		{
			var result = new FileGroup(project);

			if (filePaths.Length > 0)
			{
				foreach (var filePath in filePaths)
				{
					result.Add(
						new FileFileInfo(result)
							{
								File = filePath
							});
				}
			}

			var same =
				project == null
					? null
					: project.GetFileGroupByCheckSum(result.GetChecksum(project));

			if (same == null)
			{
				return result;
			}
			else
			{
				return same;
			}
		}

		public FileGroupStates TranslationState
		{
			get
			{
				if (_inMemoryState.HasValue)
				{
					return _inMemoryState.Value;
				}
				else
				{
					return calculateEditingState();
				}
			}
		}

		public FileGroupStateColor TranslationStateColor
		{
			get
			{
				return TranslateStateToColorKey(TranslationState);
			}
		}

		private FileGroupStates calculateEditingState()
		{
			var data = new DataProcessing(this);
			var table = data.GetDataTableFromResxFiles();

			return DoCalculateEditingState(table);
		}

		public static FileGroupStates DoCalculateEditingState(DataTable table)
		{
			if (table == null)
			{
				return FileGroupStates.Empty;
			}
			else
			{
				var result = FileGroupStates.CompletelyTranslated;

				foreach (DataRow row in table.Rows)
				{
					if (IsCompleteRowEmpty(row))
					{
						result |= FileGroupStates.EmptyRows;
					}

					if (areTranslationsMissing(row))
					{
						result |= FileGroupStates.TranslationsMissing;
					}

					if (hasPlaceholderMismatch(row))
					{
						result |= FileGroupStates.FormatParameterMismatches;
					}

					if (doesAutomaticTranslationsExist(row))
					{
						result |= FileGroupStates.AutomaticTranslationsExist;
					}
				}

				return result;
			}
		}

		// AJ CHANGE
		private static bool doesAutomaticTranslationsExist(DataRow row)
		{
			for (var i = 2; i < row.Table.Columns.Count - (DataProcessing.CommentsAreVisible(row) ? 1 : 0); ++i)
			{
				var s = ConvertHelper.ToString(row[i], string.Empty);
				if (s.StartsWith(DefaultTranslatedPrefix)) return true;
			}

			return false;
		}

		private static bool areTranslationsMissing(DataRow row)
		{
			var hasEmpty = false;
			var hasNonEmpty = false;

			// AJ CHANGE
			// Don't check the comments column
			for (var i = 1; i < row.Table.Columns.Count - (DataProcessing.CommentsAreVisible(row) ? 1 : 0); ++i)
			{
				var s = ConvertHelper.ToString(row[i], string.Empty);

				if (string.IsNullOrEmpty(s))
				{
					hasEmpty = true;
				}
				else
				{
					hasNonEmpty = true;
				}
			}

			return hasEmpty && hasNonEmpty;
		}

		private static bool hasPlaceholderMismatch(DataRow row)
		{
			var columnCount = row.Table.Columns.Count;

			var s0 =
				columnCount > 0
					? ConvertHelper.ToString(row[1], string.Empty)
					: string.Empty;
			var placeholderCount = ExtractPlaceholders(s0);

			// AJ CHANGE, skip the comments column
			for (var i = 2; i < columnCount - (DataProcessing.CommentsAreVisible(row) ? 1 : 0); ++i)
			{
				var s = ConvertHelper.ToString(row[i], string.Empty);
				var c = ExtractPlaceholders(s);

				if (c != placeholderCount)
				{
					return true;
				}
			}

			return false;
		}

		public static bool IsCompleteRowEmpty(DataRow row)
		{
			for (var i = 1; i < row.Table.Columns.Count; ++i)
			{
				if (ConvertHelper.ToString(row[i], string.Empty).Trim().Length > 0)
				{
					return false;
				}
			}

			return true;
		}

		// http://www.codeproject.com/KB/aspnet/ZetaResourceEditor.aspx?msg=3367544#xx3367544xx
		public static bool IsInternalRow(DataRow row)
		{
			var name = row[@"Name"] as string;

			if (string.IsNullOrEmpty(name) ||
				name.StartsWith(@">>") ||
				(!name.Equals(@"$this.Text") && name.StartsWith(@"$this.")))
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// Counts the placeholders.
		/// </summary>
		/// <param name="text">The text.</param>
		/// <returns></returns>
		public static string ExtractPlaceholders(
			string text)
		{
			if (string.IsNullOrEmpty(text) || text.IndexOf('{') < 0 ||
				text.IndexOf('}') < 0)
			{
				return string.Empty;
			}
			else
			{
				const string pattern = @"\{(\d+(:\w+)?)\}";

				var matches = Regex.Matches(
					text,
					pattern,
					RegexOptions.IgnoreCase);

				if (matches.Count <= 0)
				{
					return string.Empty;
				}
				else
				{
					var indexes = new Set<int>();

					foreach (Match match in matches)
					{
						var i = match.Groups[1].Value;
						indexes.Add(ConvertHelper.ToInt32(i));
					}

					indexes.Sort();

					var result = new StringBuilder();

					foreach (var i in indexes)
					{
						result.Append('-');
						result.Append(i);
					}

					// Do not return the count but the hash to allow
					// for comparing the exact placeholders equality.
					return result.ToString();
				}
			}
		}

		/// <summary>
		/// Determines whether an element is in the 
		/// <see cref="T:System.Collections.Generic.List`1"/>.
		/// </summary>
		/// <param name="item">The object to locate in the 
		/// <see cref="T:System.Collections.Generic.List`1"/>. The value can be 
		/// null for reference types.</param>
		/// <returns>
		/// true if <paramref name="item"/> is found in the 
		/// <see cref="T:System.Collections.Generic.List`1"/>; otherwise, false.
		/// </returns>
		public new bool Contains(
			FileFileInfo item)
		{
			foreach (var fileInfo in this)
			{
				if (string.Compare(item.File.FullName, fileInfo.File.FullName, true) == 0)
				{
					return true;
				}
			}

			return false;
		}

		/// <summary>
		/// Adds an object to the end of the 
		/// <see cref="T:System.Collections.Generic.List`1"/>.
		/// </summary>
		/// <param name="item">The object to be added to the end of the 
		/// <see cref="T:System.Collections.Generic.List`1"/>. The value can be 
		/// null for reference types.</param>
		public new void Add(
			FileFileInfo item)
		{
			if (!Contains(item))
			{
				base.Add(item);
			}
		}

		/// <summary>
		/// Stores to XML.
		/// </summary>
		/// <param name="project">The project.</param>
		/// <param name="parentNode">The parent node.</param>
		internal void StoreToXml(
			Project project,
			XmlElement parentNode)
		{
			foreach (var fileInfo in this)
			{
				var fileNode =
					parentNode.OwnerDocument.CreateElement(@"file");
				parentNode.AppendChild(fileNode);

				fileInfo.StoreToXml(project, fileNode);
			}

			var a = parentNode.OwnerDocument.CreateAttribute(@"name");
			a.Value = _name;
			parentNode.Attributes.Append(a);

			a = parentNode.OwnerDocument.CreateAttribute(@"projectFolderUniqueID");
			a.Value = _projectFolderUniqueID.ToString();
			parentNode.Attributes.Append(a);

			a = parentNode.OwnerDocument.CreateAttribute(@"orderPosition");
			a.Value = OrderPosition.ToString();
			parentNode.Attributes.Append(a);

			var remarksNode =
				parentNode.OwnerDocument.CreateElement(@"remarks");
			parentNode.AppendChild(remarksNode);
			remarksNode.InnerText = Remarks;

			a = parentNode.OwnerDocument.CreateAttribute(@"uniqueID");
			a.Value = _uniqueID.ToString();
			parentNode.Attributes.Append(a);
		}

		/// <summary>
		/// Loads from XML.
		/// </summary>
		/// <param name="project">The project.</param>
		/// <param name="parentNode">The parent node.</param>
		internal void LoadFromXml(
			Project project,
			XmlNode parentNode)
		{
			Clear();

			var fileNodes = parentNode.SelectNodes(@"file");

			if (fileNodes != null)
			{
				foreach (XmlNode fileNode in fileNodes)
				{
					var ffi = new FileFileInfo(this);

					if (ffi.LoadFromXml(project, fileNode))
					{
						Add(ffi);
					}
				}
			}

			// --

			XmlHelper.ReadAttribute(
				out _uniqueID,
				parentNode.Attributes[@"uniqueID"]);

			if (_uniqueID == Guid.Empty)
			{
				_uniqueID = Guid.NewGuid();
			}

			// --

			XmlHelper.ReadAttribute(
				out _projectFolderUniqueID,
				parentNode.Attributes[@"projectFolderUniqueID"]);

			XmlHelper.ReadAttribute(
				out _name,
				parentNode.Attributes[@"name"]);

			XmlHelper.ReadAttribute(
				out _orderPosition,
				parentNode.Attributes[@"orderPosition"]);

			var remarksNode = parentNode.SelectSingleNode(@"remarks");
			if (remarksNode != null)
			{
				Remarks = remarksNode.InnerText;
			}
			else
			{
				Remarks = null;
			}

			// --

			Sort();
		}

		public string GetNameIntelligent(
			Project project)
		{
			if (string.IsNullOrEmpty(_name) && Count > 0)
			{
				// Try guessing several names.

				var filePath = this[0].File;
				var folderPath = filePath.Directory;

				if (folderPath != null)
				{
					if ((string.Equals(@"Properties", folderPath.Name,
									   StringComparison.InvariantCultureIgnoreCase) ||
						 string.Equals(@"App_GlobalResources", folderPath.Name,
									   StringComparison.InvariantCultureIgnoreCase)) &&
						filePath.Name.StartsWith(
							@"Resources.", StringComparison.InvariantCultureIgnoreCase))
					{
						var parentFolderPath = folderPath.Parent;
						if (parentFolderPath == null)
						{
							return _name;
						}
						else
						{
							var pathToMakeRelative = parentFolderPath.FullName;
							return
								shortenFilePath(
									PathHelper.GetRelativePath(
										project == null
											? string.Empty
											: project.ProjectConfigurationFilePath.DirectoryName,
										pathToMakeRelative));
						}
					}
					else if (string.Equals(@"App_LocalResources", folderPath.Name,
										   StringComparison.InvariantCultureIgnoreCase))
					{
						var name =
							PathHelper.GetRelativePath(
								project == null
									? string.Empty
									: project.ProjectConfigurationFilePath.DirectoryName,
								filePath.FullName);

						var ext = Path.GetExtension(name);
						var result = name.Substring(0, name.Length - ext.Length);

						return shortenFilePath(result);
					}
					else
					{
						return
							shortenFilePath(
								PathHelper.GetRelativePath(
									project == null
										? string.Empty
										: project.ProjectConfigurationFilePath.DirectoryName,
									filePath.FullName));
					}
				}
				else
				{
					return _name;
				}
			}
			else
			{
				return _name;
			}
		}

		/// <summary>
		/// Gets or sets the name.
		/// </summary>
		/// <value>The name.</value>
		public string Name
		{
			get
			{
				if (string.IsNullOrEmpty(_name) && Count > 0)
				{
					// Try guessing several names.

					var filePath = this[0].File;
					var folderPath = filePath.Directory;

					if (folderPath != null)
					{
						if (string.Equals(@"Properties", folderPath.Name,
											   StringComparison.InvariantCultureIgnoreCase) ||
								string.Equals(@"App_GlobalResources", folderPath.Name,
											   StringComparison.InvariantCultureIgnoreCase))
						{
							var parentFolderPath = folderPath.Parent;
							if (parentFolderPath == null)
							{
								return _name;
							}
							else
							{
								return
									PathHelper.Combine(
										parentFolderPath.Name,
										folderPath.Name);
							}
						}
						else if (string.Equals(@"App_LocalResources", folderPath.Name,
													StringComparison.InvariantCultureIgnoreCase))
						{
							return
								PathHelper.Combine(
									@"App_LocalResources",
									Path.GetFileNameWithoutExtension(filePath.Name));
						}
						else
						{
							return filePath.Name;
						}
					}
					else
					{
						return _name;
					}
				}
				else
				{
					return _name;
				}
			}
			set
			{
				_name = value;
			}
		}

		/// <summary>
		/// Gets the name intelligent.
		/// </summary>
		/// <value>The name intelligent.</value>
		//public string NameIntelli
		//{
		//    get
		//    {
		//        var name = Name;

		//        if ( string.IsNullOrEmpty( name ) )
		//        {
		//            if ( Count <= 0 )
		//            {
		//                return Resources.SR_FileGroup_NameIntelli_Unnamed;
		//            }
		//            else
		//            {
		//                return ShortenFilePath( this[0].DirectoryName, 70 );
		//            }
		//        }
		//        else
		//        {
		//            return name;
		//        }
		//    }
		//}

		/// <summary>
		/// Gets the full name intelligent.
		/// </summary>
		/// <value>The full name intelligent.</value>
		public string GetFullNameIntelligent(
			Project project)
		{
			if (Count <= 0)
			{
				return GetNameIntelligent(project);
			}
			else
			{
				return this[0].File.DirectoryName;
			}
		}

		public DirectoryInfo FolderPath
		{
			get
			{
				if (Count <= 0)
				{
					return null;
				}
				else
				{
					return this[0].File.Directory;
				}
			}
		}

		/// <summary>
		/// Gets the checksum.
		/// </summary>
		/// <param name="project">The project.</param>
		/// <returns></returns>
		/// <value>The checksum.</value>
		public long GetChecksum(
			Project project)
		{
			return BuildChecksum(project, this);
		}

		/// <summary>
		/// Gets the joined file paths.
		/// </summary>
		/// <value>The joined file paths.</value>
		public string JoinedFilePaths
		{
			get
			{
				return JoinFilePaths(FilePaths);
			}
		}

		public static string JoinFilePaths(
			params string[] paths)
		{
			if (paths == null || paths.Length <= 0)
			{
				return string.Empty;
			}
			else
			{
				return string.Join(@";", paths);
			}
		}

		public static string[] SplitFilePaths(string paths)
		{
			if (string.IsNullOrEmpty(paths))
			{
				return new string[] { };
			}
			else
			{
				return paths.Split(';');
			}
		}

		/// <summary>
		/// Gets the file paths.
		/// </summary>
		/// <value>The file paths.</value>
		public string[] FilePaths
		{
			get
			{
				var ss = new List<string>();

				foreach (var filePath in sortFiles(ToArray()))
				{
					ss.Add(filePath.File.FullName);
				}

				return ss.ToArray();
			}
		}

		public string[] GetLanguageCodes(
			Project project)
		{
			var result = new Set<string>();

			foreach (var filePath in FilePaths)
			{
				var lc =
					new LanguageCodeDetection(project).DetectLanguageCodeFromFileName(
						ParentSettings,
						filePath);

				if (!string.IsNullOrEmpty(lc))
				{
					result.Add(lc.ToLowerInvariant());
				}
			}

			return result.ToArray();
		}

		public Pair<string, string>[] GetLanguageCodesExtended(
			Project project)
		{
			var result = new Set<Pair<string, string>>();

			foreach (var filePath in FilePaths)
			{
				var lc =
					new LanguageCodeDetection(project).DetectLanguageCodeFromFileName(
						ParentSettings,
						filePath);

				if (!string.IsNullOrEmpty(lc))
				{
					result.Add(
						new Pair<string, string>(
							lc.ToLowerInvariant(),
							filePath));
				}
			}

			return result.ToArray();
		}

		public FileFileInfo GetFileByLanguageCode(
			Project project,
			string languageCode)
		{
			foreach (var ffi in this)
			{
				var lc = new LanguageCodeDetection(project).DetectLanguageCodeFromFileName(
					ParentSettings,
					ffi.File.FullName);

				if (string.Compare(languageCode, lc, true) == 0)
				{
					return ffi;
				}
			}

			// Not found.
			return null;
		}

		public static string DefaultTranslatedPrefix
		{
			get
			{
				return @"####";
			}
		}

		public static string DefaultTranslationErrorPrefix
		{
			get
			{
				return @"****";
			}
		}

		/// <summary>
		/// Gets the base name.
		/// </summary>
		/// <remarks>
		/// E.g. for:
		///  - Main.master.resx
		///  - Main.master.de.resx
		///  - Main.master.en-us.resx
		/// it would be "Main.master"
		/// 
		/// E.g. for:
		///  - Properties.resx
		///  - Properties.de.resx
		/// it would be "Properties".
		/// </remarks>
		/// <value>The base name.</value>
		public string BaseName
		{
			get
			{
				return new LanguageCodeDetection(_project).GetBaseName(this);
			}
		}

		public string BaseExtension
		{
			get
			{
				return new LanguageCodeDetection(_project).GetBaseExtension(this);
			}
		}

		public string BaseOptionalDefaultType
		{
			get
			{
				return new LanguageCodeDetection(_project).GetBaseOptionalDefaultType(this);
			}
		}

		public string Remarks { get; set; }

		public Guid ProjectFolderUniqueID
		{
			get
			{
				return _projectFolderUniqueID;
			}
		}

		public void StoreOrderPosition(AsynchronousMode asynchronousMode)
		{
			_project.MarkAsModified();
		}

		public int OrderPosition
		{
			get
			{
				return _orderPosition;
			}
			set
			{
				_orderPosition = value;
			}
		}

		private FileGroupStates? _inMemoryState;
		private Guid _uniqueID;

		public FileGroupStates InMemoryState
		{
			get
			{
				return _inMemoryState.GetValueOrDefault(FileGroupStates.Empty);
			}
			set
			{
				_inMemoryState = value;
			}
		}

		/// <summary>
		/// Sorts the files.
		/// </summary>
		/// <param name="filePaths">The file paths.</param>
		/// <returns></returns>
		private static IEnumerable<FileFileInfo> sortFiles(
			ICollection<FileFileInfo> filePaths)
		{
			if (filePaths == null || filePaths.Count < 2)
			{
				return filePaths;
			}
			else
			{
				var sortableP = new List<FileFileInfo>(filePaths);

				sortableP.Sort();

				return sortableP.ToArray();
			}
		}

		/// <summary>
		/// Builds the checksum.
		/// </summary>
		/// <param name="project">The project.</param>
		/// <param name="filePaths">The file paths.</param>
		/// <returns></returns>
		internal static long BuildChecksum(
			Project project,
			IEnumerable<FileFileInfo> filePaths)
		{
			long result = 0;

			if (filePaths != null)
			{
				foreach (var filePath in filePaths)
				{
					// Changed 2009-07-11, Uwe Keim:
					// Use relative path if available.
					var realPath =
						project == null
							? filePath.File.FullName
							: project.MakeRelativeFilePath(filePath.File.FullName);

					result += Math.Abs(realPath.ToLowerInvariant().GetHashCode());
				}
			}

			return result;
		}

		/// <summary>
		/// Shortens the file path.
		/// </summary>
		/// <param name="filePath">The file path.</param>
		/// <returns></returns>
		private static string shortenFilePath(
			string filePath)
		{
			return ShortenFilePath(filePath, 150);
		}

		public static string ShortenFilePath(
			string filePath,
			int maxLength)
		{
			if (string.IsNullOrEmpty(filePath) || filePath.Length <= maxLength)
			{
				return filePath;
			}
			else
			{
				return ZrePathHelper.ShortenPathName(filePath, maxLength);
			}
		}

		#region Override
		// ------------------------------------------------------------------

		public int CompareTo(FileGroup other)
		{
			var a = _orderPosition.CompareTo(other._orderPosition);

			if (a == 0)
			{
				return Name.CompareTo(other.Name);
			}
			else
			{
				return a;
			}
		}

		public int CompareTo(object obj)
		{
			return CompareTo((FileGroup)obj);
		}

		public override bool Equals(object obj)
		{
			if (obj is FileGroup)
			{
				var compareTo = obj as FileGroup;

				return compareTo.GetChecksum(null) == GetChecksum(null);
			}
			else
			{
				return false;
			}
		}

		public override int GetHashCode()
		{
			return GetChecksum(null).GetHashCode();
		}

		// ------------------------------------------------------------------
		#endregion

		public Guid UniqueID
		{
			get
			{
				return _uniqueID;
			}
		}

		public GridSourceType SourceType
		{
			get
			{
				return GridSourceType.FileGroup;
			}
		}

		FileGroup IGridEditableData.FileGroup
		{
			get
			{
				return this;
			}
		}

		public Project Project
		{
			get
			{
				return _project;
			}
			set
			{
				_project = value;
			}
		}

		public void CreateAndAddNewFile(
			string sourceFilePath,
			string newFileName,
			string sourceLanguageCode,
			string newLanguageCode,
			bool copyTextsFromSource,
			bool automaticallyTranslateTexts,
			string prefix)
		{
			if (newFileName.StartsWith(BaseName, StringComparison.InvariantCultureIgnoreCase) &&
				newFileName.EndsWith(BaseExtension, StringComparison.InvariantCultureIgnoreCase))
			{
				var newFilePath = Path.Combine(Path.GetDirectoryName(sourceFilePath), newFileName);

				bool didCopy;

				if (File.Exists(newFilePath))
				{
					// Simply ignore and add.

					didCopy = false;

					// File may already exist but was not yet added
					// to the file group.

					/*
					throw new Exception(
						string.Format(
							"New file '{0}' already exists.",
							newFileName));
					 */

				}
				else
				{
					// Copy only if not exists.

					File.Copy(sourceFilePath, newFilePath);
					didCopy = true;
				}

				// Add to myself.
				var ffi =
					new FileFileInfo(this)
						{
							File = new FileInfo(newFilePath)
						};
				Add(ffi);

				// --
				// Further process.

				if (!copyTextsFromSource && !automaticallyTranslateTexts)
				{
					if (didCopy)
					{
						clearAllTexts(ffi);
					}
				}

				if (automaticallyTranslateTexts)
				{
					if (didCopy)
					{
						translateTexts(
							ffi,
							sourceLanguageCode,
							newLanguageCode,
							prefix);
					}
				}
			}
			else
			{
				throw new Exception(
					string.Format(
						Resources.SR_FileGroup_CreateAndAddNewFile_New_file_name_does_not_match,
						BaseName,
						BaseExtension));
			}
		}

		//private FileFileInfo getFfiForFilePath( string filePath )
		//{
		//    var fileName = Path.GetFileName( filePath );

		//    foreach ( var ffi in this )
		//    {
		//        if ( string.Compare( ffi.File.Name, fileName, true ) == 0 )
		//        {
		//            return ffi;
		//        }
		//    }

		//    return null;
		//}

		private void clearAllTexts(FileFileInfo ffi)
		{
			var tmpFileGroup = new FileGroup(Project) { ffi };

			var data = new DataProcessing(tmpFileGroup);
			var table = data.GetDataTableFromResxFiles();

			foreach (DataRow row in table.Rows)
			{
				// Clear.
				row[1] = null;
			}

			// Write back.
			data.SaveDataTableToResxFiles(table, false, false);
		}

		private void translateTexts(
			FileFileInfo destinationFfi,
			string sourceLanguageCode,
			string destinationLanguageCode,
			string prefix)
		{
			var tmpFileGroup = new FileGroup(Project) { destinationFfi };

			var data = new DataProcessing(tmpFileGroup);
			var table = data.GetDataTableFromResxFiles();

			foreach (DataRow row in table.Rows)
			{
				var sourceText = ConvertHelper.ToString(row[1]);

				if (!string.IsNullOrEmpty(sourceText))
				{
					var destinationText =
						prefix +
						Host.TranslationHelper.Translate(
							sourceText,
							string.IsNullOrEmpty(sourceLanguageCode)
								? @"auto"
								: sourceLanguageCode,
							destinationLanguageCode);

					row[1] = destinationText;
				}
			}

			// Write back.
			data.SaveDataTableToResxFiles(table, false, false);
		}

		public bool IsDeepChildOf(ProjectFolder folder)
		{
			var pf = ProjectFolder;
			while (pf != null)
			{
				if (pf.UniqueID == folder.UniqueID)
				{
					return true;
				}

				pf = pf.Parent;
			}

			return false;
		}

		public bool HasLanguageCode(CultureInfo cultureInfo)
		{
			var lcd = new LanguageCodeDetection(Project);

			foreach (var filePath in FilePaths)
			{
				var ci = lcd.DetectCultureFromFileName(
					ParentSettings,
					filePath);

				if (string.Compare(ci.Name, cultureInfo.Name, true) == 0)
				{
					return true;
				}
			}

			return false;
		}
	}

	/////////////////////////////////////////////////////////////////////////
}