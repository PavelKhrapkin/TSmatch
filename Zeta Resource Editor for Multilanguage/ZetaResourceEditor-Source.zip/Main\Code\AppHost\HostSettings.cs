namespace ZetaResourceEditor.Code.AppHost
{
	using Runtime.Code.DL;
	using Zeta.EnterpriseLibrary.Common;
	using Zeta.EnterpriseLibrary.Windows.Common;

	internal sealed class HostSettings
	{
		private static HostSettings _current;
		private static readonly object TypeLock = new object();

		public static HostSettings Current
		{
			get
			{
				if (_current == null)
				{
					lock (TypeLock)
					{
						if (_current == null)
						{
							_current = new HostSettings();
						}
					}
				}

				return _current;
			}
		}

		private ZreLicense _license;

		public ZreLicense License
		{
			get
			{
				if (_license == null)
				{
					_license = new ZreLicense();
					_license.NeedStore +=
						l => FormHelper.SaveValue(@"License", l.SaveToString());

					_license.LoadFromString(FormHelper.RestoreValue(@"License") as string);
				}

				return _license;
			}
		}

		public bool ShowNewsInMainWindow
		{
			get
			{
				return ConvertHelper.ToBoolean(
					FormHelper.RestoreValue(@"ShowNewsInMainWindow"),
					false);
			}
			set
			{
				FormHelper.SaveValue(@"ShowNewsInMainWindow", value);
			}
		}

		public bool ShowDonateButtonInMainWindow
		{
			get
			{
				return ConvertHelper.ToBoolean(
					FormHelper.RestoreValue(@"ShowDonateButtonInMainWindow"),
					true);
			}
			set
			{
				FormHelper.SaveValue(@"ShowDonateButtonInMainWindow", value);
			}
		}
	}
}