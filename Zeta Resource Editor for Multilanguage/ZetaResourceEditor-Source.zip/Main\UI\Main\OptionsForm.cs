namespace ZetaResourceEditor.UI.Main
{
	using System;
	using System.Net;
	using System.Windows.Forms;
	using Code.App;
	using Code.AppHost;
	using Helper.Base;
	using Properties;
	using Runtime.Code.DL;
	using Zeta.EnterpriseLibrary.Windows.Common;

	public partial class OptionsForm :
		FormBase
	{
		public OptionsForm()
		{
			InitializeComponent();
		}

		public int ActiveTabPageIndex
		{
			get
			{
				return xtraTabControl1.SelectedTabPageIndex;
			}
			set
			{
				xtraTabControl1.SelectedTabPageIndex = value;
			}
		}

		public override void FillControlsToItem()
		{
			base.FillControlsToItem();

			HostSettings.Current.ShowNewsInMainWindow =
				showNewsCheckEdit.Checked;
			HostSettings.Current.License.RawString =
				licenseKeyMemoEdit.Text;
		}

		public override void FillItemToControls()
		{
			base.FillItemToControls();

			showNewsCheckEdit.Checked =
				HostSettings.Current.ShowNewsInMainWindow;

			licenseKeyMemoEdit.Text = HostSettings.Current.License.RawString;
			updateLicenseInfo();
		}

		private void OptionsForm_Load(object sender, EventArgs e)
		{
			FormHelper.RestoreState(this);
			CenterToParent();

			InitiallyFillLists();
			FillItemToControls();

			UpdateUI();
		}

		private void OptionsForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			FormHelper.SaveState(this);
		}

		private void buttonOK_Click(object sender, EventArgs e)
		{
			FillControlsToItem();
		}

		private void licenseKeyMemoEdit_EditValueChanged(object sender, EventArgs e)
		{
			UpdateUI();
			updateLicenseInfo();
		}

		private void updateLicenseInfo()
		{
			var l = new ZreLicense();
			l.LoadFromString(licenseKeyMemoEdit.Text);

			if (l.IsLicenseValid)
			{
				licenseInformationLabel.Text = l.LicenseTypeName;
			}
			else
			{
				licenseInformationLabel.Text =
					Resources.SR_OptionsForm_updateLicenseInfo__Invalid_license_key_;
			}
		}

		private void purchaseLicenseButton_Click(object sender, EventArgs e)
		{
			var sei =
				new ShellExecuteInformation
					{
						FileName =
							Resources.SR_OptionsForm_purchaseLicenseButton_Click
					};
			sei.Execute();
		}

        private void proxyButton_Click(object sender, EventArgs e)
        {
            using(var form = new WebProxySettingsForm())
            {
                form.WebProxy = WebServiceManager.Current.WebServiceProxy as WebProxy;
                form.WebProxyUsage = WebServiceManager.Current.WebProxyUsage;

                if (form.ShowDialog(this) == DialogResult.OK)
                {
                    WebServiceManager.Current.WebServiceProxy = form.WebProxy;
                    WebServiceManager.Current.WebProxyUsage = form.WebProxyUsage;
                }
            }
        }
	}
}