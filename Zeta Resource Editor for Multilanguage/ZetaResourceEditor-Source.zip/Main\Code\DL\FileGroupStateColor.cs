﻿namespace ZetaResourceEditor.Code.DL
{
	public enum FileGroupStateColor
	{
		None = -1,
		Grey = 0,
		Green = 1,
		Yellow = 2,
		Red = 3,
		Blue = 4
	}
}