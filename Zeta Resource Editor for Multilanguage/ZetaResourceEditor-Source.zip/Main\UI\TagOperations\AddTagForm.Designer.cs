namespace ZetaResourceEditor.UI.TagOperations
{
	partial class AddTagForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager( typeof( AddTagForm ) );
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.groupBox1 = new DevExpress.XtraEditors.GroupControl();
			this.textBox1 = new DevExpress.XtraEditors.TextEdit();
			this.label1 = new DevExpress.XtraEditors.LabelControl();
			this.button1 = new DevExpress.XtraEditors.SimpleButton();
			this.button2 = new DevExpress.XtraEditors.SimpleButton();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.groupBox1)).BeginInit();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.textBox1.Properties)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.AccessibleDescription = null;
			this.pictureBox1.AccessibleName = null;
			resources.ApplyResources( this.pictureBox1, "pictureBox1" );
			this.pictureBox1.BackgroundImage = null;
			this.pictureBox1.Font = null;
			this.pictureBox1.ImageLocation = null;
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.TabStop = false;
			// 
			// groupBox1
			// 
			this.groupBox1.AccessibleDescription = null;
			this.groupBox1.AccessibleName = null;
			resources.ApplyResources( this.groupBox1, "groupBox1" );
			this.groupBox1.Controls.Add( this.textBox1 );
			this.groupBox1.Controls.Add( this.label1 );
			this.groupBox1.Controls.Add( this.pictureBox1 );
			this.groupBox1.Name = "groupBox1";
			// 
			// textBox1
			// 
			resources.ApplyResources( this.textBox1, "textBox1" );
			this.textBox1.BackgroundImage = null;
			this.textBox1.EditValue = null;
			this.textBox1.Name = "textBox1";
			this.textBox1.Properties.AccessibleDescription = null;
			this.textBox1.Properties.AccessibleName = null;
			this.textBox1.Properties.AutoHeight = ((bool)(resources.GetObject( "textBox1.Properties.AutoHeight" )));
			this.textBox1.Properties.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject( "textBox1.Properties.Mask.AutoComplete" )));
			this.textBox1.Properties.Mask.BeepOnError = ((bool)(resources.GetObject( "textBox1.Properties.Mask.BeepOnError" )));
			this.textBox1.Properties.Mask.EditMask = resources.GetString( "textBox1.Properties.Mask.EditMask" );
			this.textBox1.Properties.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject( "textBox1.Properties.Mask.IgnoreMaskBlank" )));
			this.textBox1.Properties.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject( "textBox1.Properties.Mask.MaskType" )));
			this.textBox1.Properties.Mask.PlaceHolder = ((char)(resources.GetObject( "textBox1.Properties.Mask.PlaceHolder" )));
			this.textBox1.Properties.Mask.SaveLiteral = ((bool)(resources.GetObject( "textBox1.Properties.Mask.SaveLiteral" )));
			this.textBox1.Properties.Mask.ShowPlaceHolders = ((bool)(resources.GetObject( "textBox1.Properties.Mask.ShowPlaceHolders" )));
			this.textBox1.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject( "textBox1.Properties.Mask.UseMaskAsDisplayFormat" )));
			this.textBox1.Properties.NullValuePrompt = resources.GetString( "textBox1.Properties.NullValuePrompt" );
			this.textBox1.TextChanged += new System.EventHandler( this.textBox1_TextChanged );
			// 
			// label1
			// 
			this.label1.AccessibleDescription = null;
			this.label1.AccessibleName = null;
			resources.ApplyResources( this.label1, "label1" );
			this.label1.Name = "label1";
			// 
			// button1
			// 
			this.button1.AccessibleDescription = null;
			this.button1.AccessibleName = null;
			resources.ApplyResources( this.button1, "button1" );
			this.button1.BackgroundImage = null;
			this.button1.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.button1.Name = "button1";
			// 
			// button2
			// 
			this.button2.AccessibleDescription = null;
			this.button2.AccessibleName = null;
			resources.ApplyResources( this.button2, "button2" );
			this.button2.BackgroundImage = null;
			this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.button2.Name = "button2";
			// 
			// AddTagForm
			// 
			this.AcceptButton = this.button1;
			this.AccessibleDescription = null;
			this.AccessibleName = null;
			this.Appearance.Font = new System.Drawing.Font( "Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel );
			this.Appearance.Options.UseFont = true;
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			resources.ApplyResources( this, "$this" );
			this.CancelButton = this.button2;
			this.Controls.Add( this.button2 );
			this.Controls.Add( this.button1 );
			this.Controls.Add( this.groupBox1 );
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "AddTagForm";
			this.ShowInTaskbar = false;
			this.Load += new System.EventHandler( this.AddTagForm_Load );
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler( this.AddTagForm_FormClosing );
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.groupBox1)).EndInit();
			this.groupBox1.ResumeLayout( false );
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.textBox1.Properties)).EndInit();
			this.ResumeLayout( false );

		}

		#endregion

		private System.Windows.Forms.PictureBox pictureBox1;
		private DevExpress.XtraEditors.GroupControl groupBox1;
		private DevExpress.XtraEditors.TextEdit textBox1;
		private DevExpress.XtraEditors.LabelControl label1;
		private DevExpress.XtraEditors.SimpleButton button1;
		private DevExpress.XtraEditors.SimpleButton button2;
	}
}