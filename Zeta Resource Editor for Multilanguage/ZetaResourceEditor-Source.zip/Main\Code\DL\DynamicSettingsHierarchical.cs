﻿namespace ZetaResourceEditor.Code.DL
{
	using System;
	using Zeta.EnterpriseLibrary.Tools.Storage;

	public class DynamicSettingsHierarchical :
		IPersistentPairStorage
	{
		private readonly IPersistentPairStorage _parent;
		private readonly IPersistentPairStorage _regular;

		public DynamicSettingsHierarchical(
			IPersistentPairStorage regular,
			IPersistentPairStorage parent )
		{
			_regular = regular;
			_parent = parent;
		}

		public void PersistValue( string name, object value )
		{
			_regular.PersistValue( name, value );
			_parent.PersistValue( name, value );
		}

		public object RetrieveValue( string name )
		{
			var r = _regular.RetrieveValue( name );

			if ( r == null )
			{
				return _parent.RetrieveValue( name );
			}
			else
			{
				return r;
			}
		}

		public object RetrieveValue( string name, object fallBackValue )
		{
			var r = _regular.RetrieveValue( name, fallBackValue );

			if ( r == fallBackValue )
			{
				return _parent.RetrieveValue( name, fallBackValue );
			}
			else
			{
				return r;
			}
		}

		public void DeleteValue( string name )
		{
			_regular.DeleteValue( name );
			_parent.DeleteValue( name );
		}

		public void Flush()
		{
		}
	}
}