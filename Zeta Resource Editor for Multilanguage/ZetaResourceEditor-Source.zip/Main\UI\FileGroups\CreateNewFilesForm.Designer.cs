namespace ZetaResourceEditor.UI.FileGroups
{
	partial class CreateNewFilesForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose( bool disposing )
		{
			if ( disposing && (components != null) )
			{
				components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateNewFilesForm));
			this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
			this.informationLightUserControl1 = new ZetaResourceEditor.UI.Helper.InformationLightUserControl();
			this.optionsGroupBox = new DevExpress.XtraEditors.GroupControl();
			this.buttonDefault = new DevExpress.XtraEditors.SimpleButton();
			this.prefixTextBox = new DevExpress.XtraEditors.TextEdit();
			this.prefixCheckBox = new DevExpress.XtraEditors.CheckEdit();
			this.parentElementTextBox = new DevExpress.XtraEditors.TextEdit();
			this.label1 = new DevExpress.XtraEditors.LabelControl();
			this.copyTextsCheckBox = new DevExpress.XtraEditors.CheckEdit();
			this.automaticallyTranslateCheckBox = new DevExpress.XtraEditors.CheckEdit();
			this.newLanguageComboBox = new DevExpress.XtraEditors.ComboBoxEdit();
			this.referenceLanguageComboBox = new DevExpress.XtraEditors.ComboBoxEdit();
			this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
			this.label2 = new DevExpress.XtraEditors.LabelControl();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.buttonCancel = new DevExpress.XtraEditors.SimpleButton();
			this.buttonOK = new DevExpress.XtraEditors.SimpleButton();
			((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
			this.panelControl1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.optionsGroupBox)).BeginInit();
			this.optionsGroupBox.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.prefixTextBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.prefixCheckBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.parentElementTextBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.copyTextsCheckBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.automaticallyTranslateCheckBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.newLanguageComboBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.referenceLanguageComboBox.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// panelControl1
			// 
			this.panelControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
			this.panelControl1.Controls.Add(this.informationLightUserControl1);
			this.panelControl1.Controls.Add(this.optionsGroupBox);
			this.panelControl1.Controls.Add(this.buttonCancel);
			this.panelControl1.Controls.Add(this.buttonOK);
			resources.ApplyResources(this.panelControl1, "panelControl1");
			this.panelControl1.Name = "panelControl1";
			// 
			// informationLightUserControl1
			// 
			resources.ApplyResources(this.informationLightUserControl1, "informationLightUserControl1");
			this.informationLightUserControl1.BackColor = System.Drawing.SystemColors.AppWorkspace;
			this.informationLightUserControl1.Cursor = System.Windows.Forms.Cursors.Default;
			this.informationLightUserControl1.MinimumSize = new System.Drawing.Size(167, 24);
			this.informationLightUserControl1.Name = "informationLightUserControl1";
			// 
			// optionsGroupBox
			// 
			resources.ApplyResources(this.optionsGroupBox, "optionsGroupBox");
			this.optionsGroupBox.Controls.Add(this.buttonDefault);
			this.optionsGroupBox.Controls.Add(this.prefixTextBox);
			this.optionsGroupBox.Controls.Add(this.prefixCheckBox);
			this.optionsGroupBox.Controls.Add(this.parentElementTextBox);
			this.optionsGroupBox.Controls.Add(this.label1);
			this.optionsGroupBox.Controls.Add(this.copyTextsCheckBox);
			this.optionsGroupBox.Controls.Add(this.automaticallyTranslateCheckBox);
			this.optionsGroupBox.Controls.Add(this.newLanguageComboBox);
			this.optionsGroupBox.Controls.Add(this.referenceLanguageComboBox);
			this.optionsGroupBox.Controls.Add(this.labelControl1);
			this.optionsGroupBox.Controls.Add(this.label2);
			this.optionsGroupBox.Controls.Add(this.pictureBox1);
			this.optionsGroupBox.Name = "optionsGroupBox";
			// 
			// buttonDefault
			// 
			resources.ApplyResources(this.buttonDefault, "buttonDefault");
			this.buttonDefault.Name = "buttonDefault";
			this.buttonDefault.Click += new System.EventHandler(this.buttonDefault_Click);
			// 
			// prefixTextBox
			// 
			resources.ApplyResources(this.prefixTextBox, "prefixTextBox");
			this.prefixTextBox.Name = "prefixTextBox";
			this.prefixTextBox.EditValueChanged += new System.EventHandler(this.prefixTextBox_EditValueChanged);
			// 
			// prefixCheckBox
			// 
			resources.ApplyResources(this.prefixCheckBox, "prefixCheckBox");
			this.prefixCheckBox.Name = "prefixCheckBox";
			this.prefixCheckBox.Properties.AutoWidth = true;
			this.prefixCheckBox.Properties.Caption = resources.GetString("prefixCheckBox.Properties.Caption");
			this.prefixCheckBox.CheckedChanged += new System.EventHandler(this.prefixCheckBox_CheckedChanged);
			// 
			// parentElementTextBox
			// 
			resources.ApplyResources(this.parentElementTextBox, "parentElementTextBox");
			this.parentElementTextBox.Name = "parentElementTextBox";
			this.parentElementTextBox.Properties.ReadOnly = true;
			// 
			// label1
			// 
			resources.ApplyResources(this.label1, "label1");
			this.label1.Name = "label1";
			// 
			// copyTextsCheckBox
			// 
			resources.ApplyResources(this.copyTextsCheckBox, "copyTextsCheckBox");
			this.copyTextsCheckBox.Name = "copyTextsCheckBox";
			this.copyTextsCheckBox.Properties.AutoWidth = true;
			this.copyTextsCheckBox.Properties.Caption = resources.GetString("copyTextsCheckBox.Properties.Caption");
			this.copyTextsCheckBox.CheckedChanged += new System.EventHandler(this.copyTextsCheckBox_CheckedChanged);
			// 
			// automaticallyTranslateCheckBox
			// 
			resources.ApplyResources(this.automaticallyTranslateCheckBox, "automaticallyTranslateCheckBox");
			this.automaticallyTranslateCheckBox.Name = "automaticallyTranslateCheckBox";
			this.automaticallyTranslateCheckBox.Properties.AutoWidth = true;
			this.automaticallyTranslateCheckBox.Properties.Caption = resources.GetString("automaticallyTranslateCheckBox.Properties.Caption");
			this.automaticallyTranslateCheckBox.CheckedChanged += new System.EventHandler(this.automaticallyTranslateCheckBox_CheckedChanged);
			// 
			// newLanguageComboBox
			// 
			resources.ApplyResources(this.newLanguageComboBox, "newLanguageComboBox");
			this.newLanguageComboBox.Name = "newLanguageComboBox";
			this.newLanguageComboBox.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("newLanguageComboBox.Properties.Buttons"))))});
			this.newLanguageComboBox.Properties.DropDownRows = 20;
			this.newLanguageComboBox.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.newLanguageComboBox.Properties.SelectedIndexChanged += new System.EventHandler(this.referenceLanguageGroupBox_SelectedIndexChanged);
			this.newLanguageComboBox.SelectedIndexChanged += new System.EventHandler(this.newLanguageComboBox_SelectedIndexChanged);
			this.newLanguageComboBox.TextChanged += new System.EventHandler(this.newLanguageComboBox_TextChanged);
			// 
			// referenceLanguageComboBox
			// 
			resources.ApplyResources(this.referenceLanguageComboBox, "referenceLanguageComboBox");
			this.referenceLanguageComboBox.Name = "referenceLanguageComboBox";
			this.referenceLanguageComboBox.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("referenceLanguageComboBox.Properties.Buttons"))))});
			this.referenceLanguageComboBox.Properties.DropDownRows = 20;
			this.referenceLanguageComboBox.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
			this.referenceLanguageComboBox.Properties.SelectedIndexChanged += new System.EventHandler(this.referenceLanguageGroupBox_SelectedIndexChanged);
			this.referenceLanguageComboBox.SelectedIndexChanged += new System.EventHandler(this.referenceLanguageComboBox_SelectedIndexChanged);
			// 
			// labelControl1
			// 
			resources.ApplyResources(this.labelControl1, "labelControl1");
			this.labelControl1.Name = "labelControl1";
			// 
			// label2
			// 
			resources.ApplyResources(this.label2, "label2");
			this.label2.Name = "label2";
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
			resources.ApplyResources(this.pictureBox1, "pictureBox1");
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.TabStop = false;
			// 
			// buttonCancel
			// 
			resources.ApplyResources(this.buttonCancel, "buttonCancel");
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.Name = "buttonCancel";
			// 
			// buttonOK
			// 
			resources.ApplyResources(this.buttonOK, "buttonOK");
			this.buttonOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// CreateNewFilesForm
			// 
			this.AcceptButton = this.buttonOK;
			this.Appearance.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			this.Appearance.Options.UseFont = true;
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.CancelButton = this.buttonCancel;
			resources.ApplyResources(this, "$this");
			this.Controls.Add(this.panelControl1);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "CreateNewFilesForm";
			this.ShowInTaskbar = false;
			this.Load += new System.EventHandler(this.CreateNewFileForm_Load);
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CreateNewFileForm_FormClosing);
			((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
			this.panelControl1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.optionsGroupBox)).EndInit();
			this.optionsGroupBox.ResumeLayout(false);
			this.optionsGroupBox.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.prefixTextBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.prefixCheckBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.parentElementTextBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.copyTextsCheckBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.automaticallyTranslateCheckBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.newLanguageComboBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.referenceLanguageComboBox.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private DevExpress.XtraEditors.PanelControl panelControl1;
		private DevExpress.XtraEditors.GroupControl optionsGroupBox;
		private System.Windows.Forms.PictureBox pictureBox1;
		private DevExpress.XtraEditors.SimpleButton buttonCancel;
		private DevExpress.XtraEditors.SimpleButton buttonOK;
		private DevExpress.XtraEditors.ComboBoxEdit referenceLanguageComboBox;
		private DevExpress.XtraEditors.LabelControl label2;
		private DevExpress.XtraEditors.ComboBoxEdit newLanguageComboBox;
		private DevExpress.XtraEditors.LabelControl labelControl1;
		private DevExpress.XtraEditors.CheckEdit automaticallyTranslateCheckBox;
		private DevExpress.XtraEditors.CheckEdit copyTextsCheckBox;
		private DevExpress.XtraEditors.TextEdit parentElementTextBox;
		private DevExpress.XtraEditors.LabelControl label1;
		private ZetaResourceEditor.UI.Helper.InformationLightUserControl informationLightUserControl1;
		private DevExpress.XtraEditors.SimpleButton buttonDefault;
		private DevExpress.XtraEditors.TextEdit prefixTextBox;
		private DevExpress.XtraEditors.CheckEdit prefixCheckBox;
	}
}