namespace ZetaResourceEditor.UI.Helper.Progress
{
	partial class BackgroundWorkerLongProgressForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose( bool disposing )
		{
			if ( disposing && (components != null) )
			{
				components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager( typeof( BackgroundWorkerLongProgressForm ) );
			this.cancelGuardTimer = new System.Windows.Forms.Timer( this.components );
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.CmdCancel = new DevExpress.XtraEditors.SimpleButton();
			this.backgroundWorker = new ZetaResourceEditor.UI.Helper.Progress.BackgroundWorkerLongProgress();
			this.ProgressBarControl = new DevExpress.XtraEditors.MarqueeProgressBarControl();
			this.ProgressTextControl = new DevExpress.XtraEditors.LabelControl();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.ProgressBarControl.Properties)).BeginInit();
			this.SuspendLayout();
			// 
			// cancelGuardTimer
			// 
			this.cancelGuardTimer.Interval = 5000;
			this.cancelGuardTimer.Tick += new System.EventHandler( this.cancelGuardTimer_Tick );
			// 
			// pictureBox1
			// 
			resources.ApplyResources( this.pictureBox1, "pictureBox1" );
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.TabStop = false;
			// 
			// CmdCancel
			// 
			resources.ApplyResources( this.CmdCancel, "CmdCancel" );
			this.CmdCancel.Appearance.Font = new System.Drawing.Font( "Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel );
			this.CmdCancel.Appearance.Options.UseFont = true;
			this.CmdCancel.Image = ((System.Drawing.Image)(resources.GetObject( "CmdCancel.Image" )));
			this.CmdCancel.Name = "CmdCancel";
			this.CmdCancel.Click += new System.EventHandler( this.CmdCancel_Click );
			// 
			// backgroundWorker
			// 
			this.backgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler( this.backgroundWorker_RunWorkerCompleted );
			// 
			// ProgressBarControl
			// 
			resources.ApplyResources( this.ProgressBarControl, "ProgressBarControl" );
			this.ProgressBarControl.Name = "ProgressBarControl";
			// 
			// ProgressTextControl
			// 
			resources.ApplyResources( this.ProgressTextControl, "ProgressTextControl" );
			this.ProgressTextControl.Appearance.Options.UseTextOptions = true;
			this.ProgressTextControl.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
			this.ProgressTextControl.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
			this.ProgressTextControl.Name = "ProgressTextControl";
			// 
			// BackgroundWorkerLongProgressForm
			// 
			this.Appearance.Font = new System.Drawing.Font( "Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel );
			this.Appearance.Options.UseFont = true;
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			resources.ApplyResources( this, "$this" );
			this.Controls.Add( this.ProgressTextControl );
			this.Controls.Add( this.ProgressBarControl );
			this.Controls.Add( this.CmdCancel );
			this.Controls.Add( this.pictureBox1 );
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "BackgroundWorkerLongProgressForm";
			this.ShowInTaskbar = false;
			this.Load += new System.EventHandler( this.BackgroundWorkerLongProgressForm_Load );
			this.Shown += new System.EventHandler( this.BackgroundWorkerLongProgressForm_Shown );
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler( this.ProgressForm_FormClosing );
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.ProgressBarControl.Properties)).EndInit();
			this.ResumeLayout( false );
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Timer cancelGuardTimer;
		private System.Windows.Forms.PictureBox pictureBox1;
		private DevExpress.XtraEditors.SimpleButton CmdCancel;
		private BackgroundWorkerLongProgress backgroundWorker;
		private DevExpress.XtraEditors.MarqueeProgressBarControl ProgressBarControl;
		private DevExpress.XtraEditors.LabelControl ProgressTextControl;
	}
}