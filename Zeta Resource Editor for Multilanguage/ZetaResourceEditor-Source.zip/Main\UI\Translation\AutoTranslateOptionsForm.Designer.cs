namespace ZetaResourceEditor.UI.Translation
{
	partial class AutoTranslateOptionsForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AutoTranslateOptionsForm));
			this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
			this.groupBox1 = new DevExpress.XtraEditors.GroupControl();
			this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
			this.label2 = new DevExpress.XtraEditors.LabelControl();
			this.translationDelayTextEdit = new DevExpress.XtraEditors.TextEdit();
			this.checkEditContinueOnErrors = new DevExpress.XtraEditors.CheckEdit();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.buttonOK = new DevExpress.XtraEditors.SimpleButton();
			this.buttonCancel = new DevExpress.XtraEditors.SimpleButton();
			((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
			this.panelControl1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.groupBox1)).BeginInit();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.translationDelayTextEdit.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.checkEditContinueOnErrors.Properties)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// panelControl1
			// 
			this.panelControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
			this.panelControl1.Controls.Add(this.groupBox1);
			this.panelControl1.Controls.Add(this.buttonOK);
			this.panelControl1.Controls.Add(this.buttonCancel);
			resources.ApplyResources(this.panelControl1, "panelControl1");
			this.panelControl1.Name = "panelControl1";
			// 
			// groupBox1
			// 
			resources.ApplyResources(this.groupBox1, "groupBox1");
			this.groupBox1.Controls.Add(this.labelControl1);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.translationDelayTextEdit);
			this.groupBox1.Controls.Add(this.checkEditContinueOnErrors);
			this.groupBox1.Controls.Add(this.pictureBox1);
			this.groupBox1.Name = "groupBox1";
			// 
			// labelControl1
			// 
			resources.ApplyResources(this.labelControl1, "labelControl1");
			this.labelControl1.Name = "labelControl1";
			// 
			// label2
			// 
			resources.ApplyResources(this.label2, "label2");
			this.label2.Name = "label2";
			// 
			// translationDelayTextEdit
			// 
			resources.ApplyResources(this.translationDelayTextEdit, "translationDelayTextEdit");
			this.translationDelayTextEdit.Name = "translationDelayTextEdit";
			this.translationDelayTextEdit.Properties.MaxLength = 5;
			this.translationDelayTextEdit.EditValueChanged += new System.EventHandler(this.translationDelayTextEdit_EditValueChanged);
			// 
			// checkEditContinueOnErrors
			// 
			resources.ApplyResources(this.checkEditContinueOnErrors, "checkEditContinueOnErrors");
			this.checkEditContinueOnErrors.Name = "checkEditContinueOnErrors";
			this.checkEditContinueOnErrors.Properties.AutoWidth = true;
			this.checkEditContinueOnErrors.Properties.Caption = resources.GetString("checkEditContinueOnErrors.Properties.Caption");
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
			resources.ApplyResources(this.pictureBox1, "pictureBox1");
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.TabStop = false;
			// 
			// buttonOK
			// 
			resources.ApplyResources(this.buttonOK, "buttonOK");
			this.buttonOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.buttonOK.Name = "buttonOK";
			this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// buttonCancel
			// 
			resources.ApplyResources(this.buttonCancel, "buttonCancel");
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.Name = "buttonCancel";
			// 
			// AutoTranslateOptionsForm
			// 
			this.AcceptButton = this.buttonOK;
			this.Appearance.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
			this.Appearance.Options.UseFont = true;
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.CancelButton = this.buttonCancel;
			resources.ApplyResources(this, "$this");
			this.Controls.Add(this.panelControl1);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "AutoTranslateOptionsForm";
			this.ShowInTaskbar = false;
			this.Load += new System.EventHandler(this.AutoTranslateOptionsForm_Load);
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AutoTranslateOptionsForm_FormClosing);
			((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
			this.panelControl1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.groupBox1)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.translationDelayTextEdit.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.checkEditContinueOnErrors.Properties)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private DevExpress.XtraEditors.PanelControl panelControl1;
		private DevExpress.XtraEditors.SimpleButton buttonOK;
		private DevExpress.XtraEditors.SimpleButton buttonCancel;
		private DevExpress.XtraEditors.GroupControl groupBox1;
		private DevExpress.XtraEditors.TextEdit translationDelayTextEdit;
		private DevExpress.XtraEditors.CheckEdit checkEditContinueOnErrors;
		private System.Windows.Forms.PictureBox pictureBox1;
		private DevExpress.XtraEditors.LabelControl label2;
		private DevExpress.XtraEditors.LabelControl labelControl1;
	}
}