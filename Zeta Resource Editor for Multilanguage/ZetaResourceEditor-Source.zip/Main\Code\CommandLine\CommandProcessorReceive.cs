﻿namespace ZetaResourceEditor.Code.CommandLine
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System;
	using System.Collections.Generic;
	using System.ComponentModel;
	using System.Data;
	using System.IO;
	using Aspose.Cells;
	using DL;
	using Helper;
	using Properties;
	using Zeta.EnterpriseLibrary.Common;
	using Zeta.EnterpriseLibrary.Common.Collections;
	using Zeta.EnterpriseLibrary.Common.IO;

	// ----------------------------------------------------------------------
	#endregion

	internal class CommandProcessorReceive
	{
		private CommandProcessorReceiveInformation _information;

		public void Prepare(
			CommandProcessorReceiveInformation information)
		{
			_information = information;
		}

		public static FileGroup[] DetectFileGroupsFromExcelFile(
			Project project,
			string filePath)
		{
			if (string.IsNullOrEmpty(filePath) ||
				Path.GetExtension(filePath).ToLowerInvariant() != @".xls" ||
				!File.Exists(filePath))
			{
				return null;
			}
			else
			{
				var result = new List<FileGroup>();

				var wb = new Workbook();
				wb.Open(filePath);

				var checkSums = new Set<long>();

				foreach (Worksheet worksheet in wb.Worksheets)
				{
					checkSums.AddRange(extractColumnCheckSums(worksheet));
				}

				foreach (var checkSum in checkSums)
				{
					var fileGroup = getFileGroupForCheckSum(project, checkSum);

					if (fileGroup != null)
					{
						result.Add(fileGroup);
					}
				}

				return result.ToArray();
			}
		}

		private static IEnumerable<long> extractColumnCheckSums(
			Worksheet worksheet)
		{
			var result = new Set<long>();

			var cells = worksheet.Cells;

			if (cells.Columns.Count >= 1)
			{
				for (var rowIndex = 1; rowIndex < cells.Rows.Count; rowIndex++)
				{
					var cellValue = ConvertHelper.ToString(cells[rowIndex, 0].Value);

					// First blank line to stop.
					if (string.IsNullOrEmpty(cellValue))
					{
						break;
					}
					else
					{
						var checkSum = ConvertHelper.ToInt64(cellValue);
						if (checkSum > 0)
						{
							result.Add(checkSum);
						}
					}
				}
			}

			return result.ToArray();
		}

		private static FileGroup getFileGroupForCheckSum(
			Project project,
			long checkSum)
		{
			foreach (var fileGroup in project.FileGroups)
			{
				if (fileGroup.GetChecksum(project) == checkSum)
				{
					return fileGroup;
				}
			}

			return null;
		}

		public static string[] DetectLanguagesFromExcelFile(
			string filePath)
		{
			if (string.IsNullOrEmpty(filePath) ||
				Path.GetExtension(filePath).ToLowerInvariant() != @".xls" ||
				!File.Exists(filePath))
			{
				return null;
			}
			else
			{
				var result = new Set<string>();

				var wb = new Workbook();
				wb.Open(filePath);

				foreach (Worksheet worksheet in wb.Worksheets)
				{
					var cells = worksheet.Cells;

					// --
					// Header.

					const int headerStartRowIndex = 0;
					const int columnStartIndex = 0;

					for (var index = columnStartIndex + 0; index < 30; ++index)
					{
						var languageCode =
							(string)cells[headerStartRowIndex, index].Value;

						if (languageCode != Resources.SR_CommandProcessorSend_Process_Name &&
							languageCode != Resources.SR_CommandProcessorSend_Process_Group)
						{
							if (string.IsNullOrEmpty(languageCode) ||
								languageCode.Trim().Length <= 0)
							{
								break;
							}
							else
							{
								var lc = languageCode.Trim().ToLowerInvariant();
								if (LanguageCodeDetection.IsValidCultureName(lc))
								{
									result.Add(lc);
								}
							}
						}
					}
				}

				return result.ToArray();
			}
		}

		public void Process(
			BackgroundWorker bw)
		{
			var wb = new Workbook();
			wb.Open(_information.SourceFilePath);

			var worksheetIndex = 0;
			foreach (Worksheet worksheet in wb.Worksheets)
			{
				if (bw.CancellationPending)
				{
					throw new CancelOperationException();
				}

				if (_information.IsFileGroupLessXlsFile)
				{
					processWorkSheetFileGroupLess(
						worksheetIndex,
						wb,
						worksheet,
						bw);
				}
				else
				{
					processWorkSheetNormal(
						worksheetIndex,
						wb,
						worksheet,
						bw);
				}

				worksheetIndex++;
			}
		}

		private void processWorkSheetNormal(
			int worksheetIndex,
			Workbook wb,
			Worksheet worksheet,
			BackgroundWorker bw)
		{
			const int headerStartRowIndex = 0;
			const int columnStartIndex = 0;

			var cells = worksheet.Cells;
			var rowCount = cells.Rows.Count;

			for (var rowIndex = headerStartRowIndex + 1;
				rowIndex < rowCount; ++rowIndex)
			{
				var checkSum =
					ConvertHelper.ToInt64(
						cells[rowIndex, columnStartIndex + 0].Value);

				if (wantUseFileGroupWithCheckSum(checkSum))
				{
					var key =
						ConvertHelper.ToString(
							cells[rowIndex, columnStartIndex + 1].Value);

					// TODO: Optimize this later by caching in memory (if not too large!).
					var fileGroup = getFileGroupForCheckSum(_information.Project, checkSum);
					var db = new DataProcessing(fileGroup);
					var table = db.GetDataTableFromResxFiles();

					var anyChanges = false;

					foreach (var languageCode in _information.LanguageCodes)
					{
						// UI progress and cancelation handling.
						if ((rowIndex + 1) % 20 == 0)
						{
							if (bw.CancellationPending)
							{
								throw new CancelOperationException();
							}

							bw.ReportProgress(
								0,
								string.Format(
									Resources.SR_CommandProcessorReceive_Process_ProcessingWorkSheetOfRowOf,
									worksheetIndex + 1,
									wb.Worksheets.Count,
									rowIndex + 1,
									rowCount,
									(int)
									(((rowIndex + 1.0) /
									  (worksheet.Cells.Rows.Count) *
									  ((worksheetIndex + 1.0) /
									   (wb.Worksheets.Count))) * 100)));
						}

						// --

						var row = getTableRow(table, key);
						if (row != null)
						{
							var tableColumnIndex =
								getTableColumnIndex(
									fileGroup.ParentSettings,
									table,
									languageCode);

							if (tableColumnIndex >= 1)
							{
								var worksheetColumnIndex =
									getColumnIndex(
										worksheet,
										languageCode);
								var sourceValue =
									ConvertHelper.ToString(
										cells[rowIndex,
										      worksheetColumnIndex].Value,
										string.Empty);

								if (!string.IsNullOrEmpty(sourceValue))
								{
									var originalValue =
										ConvertHelper.ToString(
											row[tableColumnIndex],
											string.Empty);

									if (originalValue != sourceValue)
									{
										row[tableColumnIndex] = sourceValue;
										anyChanges = true;
									}
								}
							}
						}
					}

					if (anyChanges)
					{
						db.SaveDataTableToResxFiles(
							table,
							_information.Project);
					}
				}
			}
		}

		private void processWorkSheetFileGroupLess(
			int worksheetIndex,
			Workbook wb,
			Worksheet worksheet,
			BackgroundWorker bw)
		{
			const int headerStartRowIndex = 0;
			const int columnStartIndex = 0;

			var sourceCells = worksheet.Cells;
			var sourceRowCount = sourceCells.Rows.Count;

			for (var sourceRowIndex = headerStartRowIndex + 1;
				sourceRowIndex < sourceRowCount; ++sourceRowIndex)
			{
				// Need to process all file groups.
				foreach (var fileGroup in _information.Project.FileGroups)
				{
					var db = new DataProcessing(fileGroup);
					var table = db.GetDataTableFromResxFiles();

					var anyChanges = false;

					foreach (var languageCode in _information.LanguageCodes)
					{
						// UI progress and cancelation handling.
						if ((sourceRowIndex + 1) % 20 == 0)
						{
							if (bw.CancellationPending)
							{
								throw new CancelOperationException();
							}

							bw.ReportProgress(
								0,
								string.Format(
									Resources.SR_CommandProcessorReceive_Process_ProcessingWorkSheetOfRowOf,
									worksheetIndex + 1,
									wb.Worksheets.Count,
									sourceRowIndex + 1,
									sourceRowCount,
									(int)
									(((sourceRowIndex + 1.0) /
									  (worksheet.Cells.Rows.Count) *
									  ((worksheetIndex + 1.0) /
									   (wb.Worksheets.Count))) * 100)));
						}

						// --

						var destinationTableColumnIndex =
							getTableColumnIndex(
								fileGroup.ParentSettings,
								table,
								languageCode);

						if (destinationTableColumnIndex >= 1)
						{
							// Reference language is in the first column.
							var refLanguageValue =
								ConvertHelper.ToString(
									sourceCells[sourceRowIndex, columnStartIndex + 0].Value);

							//CHANGED:
							if (string.IsNullOrEmpty(refLanguageValue))
							{
								//skip empty worksheet rows
								continue;
							}

							var worksheetSourceColumnIndex =
								getColumnIndex(
									worksheet,
									languageCode);

							var rows = getTableRows(table, refLanguageValue);
							if (rows.Count > 0)
							{
								foreach (var row in rows)
								{
									//CHANGED: skip among other $this.Name rows
									if (FileGroup.IsInternalRow(row))
									{
										continue;
									}

									var sourceValue =
										ConvertHelper.ToString(
											sourceCells[sourceRowIndex,
											            worksheetSourceColumnIndex].Value,
											string.Empty);

									if (!string.IsNullOrEmpty(sourceValue))
									{
										var originalValue =
											ConvertHelper.ToString(
												row[destinationTableColumnIndex],
												string.Empty);

										if (originalValue != sourceValue)
										{
											row[destinationTableColumnIndex] = sourceValue;
											anyChanges = true;
										}
									}
								}
							}
						}
					}

					if (anyChanges)
					{
						db.SaveDataTableToResxFiles(
							table,
							_information.Project);
					}
				}
			}
		}

		private int getTableColumnIndex(
			IInheritedSettings settings,
			DataTable dataTable,
			string languageCode)
		{
			var columnIndex = 0;
			foreach (DataColumn column in dataTable.Columns)
			{
				if (columnIndex > 0)
				{
					var lc =
						new LanguageCodeDetection(
							_information.Project)
							.DetectLanguageCodeFromFileName(
							settings,
							column.ColumnName);

					if (string.Compare(lc, languageCode, true) == 0)
					{
						return column.Ordinal;
					}
				}

				columnIndex++;
			}

			return -1;
		}

		private static DataRow getTableRow(
			DataTable table,
			string key)
		{
			if (!string.IsNullOrEmpty(key))
			{
				key = key.Trim();
			}

			foreach (DataRow row in table.Rows)
			{
				var lk = ConvertHelper.ToString(row[0]);
				if (string.Compare(lk, key, true) == 0)
				{
					return row;
				}
			}

			// --
			// Create new.

			var nr = table.NewRow();
			nr[0] = key;
			table.Rows.Add(nr);

			return nr;
		}

		private static List<DataRow> getTableRows(
			DataTable table,
			string referenceLanguageValue)
		{
			if (string.IsNullOrEmpty(referenceLanguageValue))
			{
				throw new ArgumentException(
					Resources.SR_CommandProcessorReceive_getTableRows_Reference_language_value,
					@"referenceLanguageValue");
			}
			else
			{
				var result = new List<DataRow>();

				// --

				foreach (DataRow row in table.Rows)
				{
					var lk = ConvertHelper.ToString(row[1]);
					if (string.Compare(lk, referenceLanguageValue, true) == 0)
					{
						result.Add(row);
					}
				}

				// --
				// Create new.

				/*if (result.Count <= 0)
				{
					var nr = table.NewRow();
					nr[0] = StringHelper.MakeMatchcode(referenceLanguageValue);
					nr[1] = referenceLanguageValue;
					table.Rows.Add(nr);

					result.Add(nr);
				}*/

				// --

				return result;
			}
		}

		private bool wantUseFileGroupWithCheckSum(long checkSum)
		{
			if (checkSum == 0)
			{
				return false;
			}
			else if (_information.IsFileGroupLessXlsFile)
			{
				// If this is a filegroup-less XLS file, import into all
				// file groups that are available.
				return true;
			}
			else
			{
				foreach (var fileGroup in _information.FileGroups)
				{
					if (fileGroup.GetChecksum(_information.Project) == checkSum)
					{
						return true;
					}
				}

				return false;
			}
		}

		private static int getColumnIndex(
			Worksheet worksheet,
			string languageCode)
		{
			foreach (Column column in worksheet.Cells.Columns)
			{
				var lc =
					ConvertHelper.ToString(
						worksheet.Cells[0, column.Index].Value);
				if (string.Compare(lc, languageCode, true) == 0)
				{
					return column.Index;
				}
			}

			return -1;
		}
	}
}