﻿namespace ZetaResourceEditor.Code.Misc
{
	using System;
	using System.Collections.Generic;
	using System.Diagnostics;
	using System.Globalization;
	using System.IO;
	using System.Reflection;
	using System.Threading;
	using System.Windows.Forms;
	using DevExpress.XtraSpellChecker;
	using Zeta.EnterpriseLibrary.Common.IO;
	using Zeta.EnterpriseLibrary.Logging;

	internal static class CultureHelper
	{
		private static DirectoryInfo dictionaryBaseFolderPath
		{
			get
			{
				var directory =
					new DirectoryInfo(
						PathHelper.Combine(
							PathHelper.GetDirectory(
								Assembly.GetEntryAssembly().Location ),
							@"Dictionaries" ) );

				return directory;
			}
		}

		private class CacheItem
		{
			public bool Available
			{
				get;
				set;
			}

			public string DictionaryFilePath
			{
				get;
				set;
			}
			public string GrammarFilePath
			{
				get;
				set;
			}
		}

		private static readonly Dictionary<CultureInfo, CacheItem> Cache =
			new Dictionary<CultureInfo, CacheItem>();

		public static bool HasDictionariesForCulture(
			CultureInfo culture,
			out string dictionaryFilePath,
			out string grammarFilePath )
		{
			CacheItem cacheItem;

			if ( !Cache.TryGetValue( culture, out cacheItem ) )
			{
				cacheItem = doHasDictionariesForCulture( culture );
				Cache[culture] = cacheItem;
			}

			dictionaryFilePath = cacheItem.DictionaryFilePath;
			grammarFilePath = cacheItem.GrammarFilePath;
			return cacheItem.Available;
		}

		private static CacheItem doHasDictionariesForCulture(
			CultureInfo culture )
		{
			var fileNames = getAllCompleteCultureFileNames();
			var cultureName = culture.Name;
			var cultureNameShort = culture.Name.Substring( 0, 2 );

			// --
			// First pass: direct match.

			foreach ( var fileName in fileNames )
			{
				var normalizedFileName = fileName.Replace( @"_", @"-" );

				if ( string.Equals(
					cultureName,
					normalizedFileName,
					StringComparison.InvariantCultureIgnoreCase ) )
				{
					return
						new CacheItem
							{
								Available = true,
								DictionaryFilePath = PathHelper.Combine( dictionaryBaseFolderPath.FullName, fileName + @".dic" ),
								GrammarFilePath = PathHelper.Combine( dictionaryBaseFolderPath.FullName, fileName + @".aff" )
							};
				}
			}

			// --
			// Second pass: base match.

			foreach ( var fileName in fileNames )
			{
				if ( fileName.Length >= 2 )
				{
					var normalizedFileName = fileName.Substring( 0, 2 );

					if ( string.Equals(
						cultureNameShort,
						normalizedFileName,
						StringComparison.InvariantCultureIgnoreCase ) )
					{
						return
							new CacheItem
							{
								Available = true,
								DictionaryFilePath = PathHelper.Combine( dictionaryBaseFolderPath.FullName, fileName + @".dic" ),
								GrammarFilePath = PathHelper.Combine( dictionaryBaseFolderPath.FullName, fileName + @".aff" )
							};
					}
				}
			}

			// --
			// Not found.

			return
				new CacheItem
					{
						Available = false
					};
		}

		private static IEnumerable<string> getAllCompleteCultureFileNames()
		{
			var result = new List<string>();

			if ( dictionaryBaseFolderPath.Exists )
			{
				var files =
					new List<FileInfo>(dictionaryBaseFolderPath.GetFiles());

				foreach (var file in files)
				{
					if (file.Extension.Equals(
					    	@".dic",
					    	StringComparison.InvariantCultureIgnoreCase) &&
					    files.Find(
					    	x => x.Extension.Equals(
					    	     	@".aff",
					    	     	StringComparison.InvariantCultureIgnoreCase)) != null)
					{
						result.Add(Path.GetFileNameWithoutExtension(file.Name));
					}
				}

				result.Sort();
			}

			return result;
		}

/*
		public static SpellCheckerOpenOfficeDictionary[] GetAllDictionaries()
		{
			var result = new List<SpellCheckerOpenOfficeDictionary>();

			var fileNames = getAllCompleteCultureFileNames();

			foreach ( var fileName in fileNames )
			{
				var normalizedFileName = fileName.Replace( @"_", @"-" );

				var dictionary =
					new SpellCheckerOpenOfficeDictionary
						{
							Culture = CultureInfo.GetCultureInfo( normalizedFileName ),
							DictionaryPath = PathHelper.Combine( dictionaryBaseFolderPath.FullName, fileName + @".dic" ),
							GrammarPath = PathHelper.Combine( dictionaryBaseFolderPath.FullName, fileName + @".aff" )
						};

				result.Add( dictionary );
			}

			return result.ToArray();
		}
*/

		public static SpellChecker CreateSpellChecker(
			CultureInfo culture )
		{
			string dictionaryFilePath;
			string grammarFilePath;

			if ( HasDictionariesForCulture(
				culture,
				out dictionaryFilePath,
				out grammarFilePath ) )
			{
				Trace.WriteLine(
					string.Format(
						@"Using spell checker with culture '{0}'.",
						culture ) );

				// http://www.devexpress.com/Help/?document=XtraSpellChecker/CustomDocument3158.htm&levelup=true.
				var spellChecker =
					new SpellChecker
					{
						Culture = culture,
						SpellCheckMode = SpellCheckMode.AsYouType,
					};
				spellChecker.CheckAsYouTypeOptions.CheckControlsInParentContainer = true;

				var dictionary =
					new SpellCheckerOpenOfficeDictionary
					{
						Culture = culture,
						DictionaryPath = dictionaryFilePath,
						GrammarPath = grammarFilePath
					};
				spellChecker.Dictionaries.Add( dictionary );

				return spellChecker;
			}
			else
			{
				Trace.WriteLine(
					string.Format(
						@"No spell checker with culture '{0}' because no dictionaries available.",
						culture ) );

				return null;
			}
		}

		#region Public methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// Gets the name of the supported UI culture from two letter windows 
		/// language.
		/// </summary>
		/// <param name="twoLetterWindowsLanguageName">Name of the two letter 
		/// windows language.</param>
		/// <returns></returns>
		public static CultureInfo
			GetSupportedUICultureFromTwoLetterWindowsLanguageName(
			string twoLetterWindowsLanguageName)
		{
			return doGetCultureFromTwoLetterWindowsLanguageName(
				SupportedUICultures,
				twoLetterWindowsLanguageName);
		}

		/// <summary>
		/// Gets the name of the supported UI culture from three letter windows 
		/// language.
		/// </summary>
		/// <param name="threeLetterWindowsLanguageName">Name of the three letter 
		/// windows language.</param>
		/// <returns></returns>
		public static CultureInfo
			GetSupportedUICultureFromThreeLetterWindowsLanguageName(
			string threeLetterWindowsLanguageName)
		{
			return doGetCultureFromThreeLetterWindowsLanguageName(
				SupportedUICultures,
				threeLetterWindowsLanguageName);
		}

		/// <summary>
		/// Put the culture info to all threads and Windows Forms.
		/// </summary>
		/// <param name="cultureInfo">The culture info.</param>
		public static void ApplyCultureToAllUIElements(
			CultureInfo cultureInfo)
		{
			LogCentral.Current.LogInfo(
				string.Format(@"Applying culture '{0}' to all UI elements.",
					cultureInfo.Name));

			Thread.CurrentThread.CurrentCulture =
				Thread.CurrentThread.CurrentUICulture =
					Application.CurrentCulture =
						cultureInfo;
		}

		/// <summary>
		/// Lookup a matching (if any).
		/// </summary>
		/// <param name="cultureInfos">The culture infos.</param>
		/// <param name="cultureInfoToMatch">The culture info to match.</param>
		/// <returns></returns>
		public static CultureInfo GetMatchingCulture(
			CultureInfo[] cultureInfos,
			CultureInfo cultureInfoToMatch)
		{
			if (cultureInfos == null || cultureInfos.Length <= 0)
			{
				return null;
			}
			else
			{
				foreach (var ci in cultureInfos)
				{
					// 2007-11-26, only compare the first TWO, to allow
					// e.g. Austria (DEA) to still load German.
					if (string.Compare(
						ci.TwoLetterISOLanguageName,
						cultureInfoToMatch.TwoLetterISOLanguageName,
						true) == 0)
					{
						return ci;
					}
				}

				// Fallback.
				return cultureInfos[0];
			}
		}

		public static string GetSupportedLanguage3(CultureInfo cultureInfo)
		{
			var twoLetterWindowsLanguageName =
				cultureInfo.Name.Substring(0, 2);

			foreach (var ci in SupportedUICultures)
			{
				var l2 = ci.Name.Substring(0, 2);

				// 2007-11-26, only compare the first TWO, to allow
				// e.g. Austria (DEA) to still load German.
				if (string.Compare(
					l2,
					twoLetterWindowsLanguageName,
					true) == 0)
				{
					return ci.ThreeLetterWindowsLanguageName;
				}
			}

			// Fallback.
			return SupportedUICultures[0].ThreeLetterWindowsLanguageName;
		}

		// ------------------------------------------------------------------
		#endregion

		#region Private methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// Does the name of the get culture from two letter windows language.
		/// </summary>
		/// <param name="cultureToSearchIn">The culture to search in.</param>
		/// <param name="twoLetterWindowsLanguageName">Name of the two letter 
		/// windows language.</param>
		/// <returns></returns>
		private static CultureInfo
			doGetCultureFromTwoLetterWindowsLanguageName(
			IList<CultureInfo> cultureToSearchIn,
			string twoLetterWindowsLanguageName)
		{
			if (twoLetterWindowsLanguageName.Length != 2)
			{
				throw new ArgumentException();
			}
			else
			{
				foreach (var ci in cultureToSearchIn)
				{
					if (string.Compare(
						ci.TwoLetterISOLanguageName,
						twoLetterWindowsLanguageName,
						true) == 0)
					{
						return ci;
					}
				}

				// Fallback.
				return cultureToSearchIn[0];
			}
		}

		/// <summary>
		/// Does the name of the get culture from three letter windows language.
		/// </summary>
		/// <param name="cultureToSearchIn">The culture to search in.</param>
		/// <param name="threeLetterWindowsLanguageName">Name of the three 
		/// letter windows language.</param>
		/// <returns></returns>
		private static CultureInfo
			doGetCultureFromThreeLetterWindowsLanguageName(
			IList<CultureInfo> cultureToSearchIn,
			string threeLetterWindowsLanguageName)
		{
			if (threeLetterWindowsLanguageName.Length != 3)
			{
				throw new ArgumentException();
			}
			else
			{
				var twoLetterWindowsLanguageName =
					threeLetterWindowsLanguageName.Substring(0, 2);

				foreach (var ci in cultureToSearchIn)
				{
					// 2007-11-26, only compare the first TWO, to allow
					// e.g. Austria (DEA) to still load German.
					if (string.Compare(
						ci.TwoLetterISOLanguageName,
						twoLetterWindowsLanguageName,
						true) == 0)
					{
						return ci;
					}
				}

				// Fallback.
				return cultureToSearchIn[0];
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Public properties.
		// ------------------------------------------------------------------

		/// <summary>
		/// Returns the UI cultures that are supported by zeta producer.
		/// (I.e. dialogs, menus, messages, etc).
		/// </summary>
		/// <value>The supported UI cultures.</value>
		public static CultureInfo[] SupportedUICultures
		{
			get
			{
				var result =
					new List<CultureInfo>
					{
						new CultureInfo( @"en-US" ), 
						new CultureInfo( @"de-DE" )
						// Add more as they become available.
					};

				return result.ToArray();
			}
		}

		// ------------------------------------------------------------------
		#endregion
	}
}