namespace ZetaResourceEditor.UI.Helper.Base
{
	using System;
	using System.ComponentModel;
	using System.Diagnostics;
	using System.Globalization;
	using System.Text;
	using System.Windows.Forms;
	using DevExpress.XtraEditors;
	using DevExpress.XtraSpellChecker;
	using DevExpress.XtraTab;
	using Zeta.EnterpriseLibrary.Common;
	using Zeta.EnterpriseLibrary.Tools.Storage;
	using Zeta.EnterpriseLibrary.Windows.Common;

	public partial class FormBase :
		XtraForm
	{
		public FormBase()
		{
			InitializeComponent();
		}

		public static void ApplySpellCheckerCulture(
			SpellChecker spellChecker )
		{
			if ( spellChecker != null )
			{
				spellChecker.Culture = CultureInfo.CurrentUICulture;
			}
		}

		public static void ApplySpellCheckerCulture(
			SpellChecker spellChecker,
			string languageCode )
		{
			if ( spellChecker != null )
			{
				spellChecker.Culture = CultureInfo.GetCultureInfo( languageCode );
			}
		}

		public FormBase( IContainer container )
		{
			container.Add( this );

			InitializeComponent();
		}

		public static string BuildIDHierarchy(
			Control c )
		{
			var sb = new StringBuilder();

			while ( c != null )
			{
				if ( sb.Length > 0 )
				{
					sb.Append( '.' );
				}

				sb.Append( c.Name );
				c = c.Parent;
			}

			return sb.ToString();
		}

		public virtual void InitiallyFillLists()
		{
		}

		public virtual void FillItemToControls()
		{
		}

		public virtual void FillControlsToItem()
		{
		}

		public virtual void UpdateUI()
		{
		}

		public void PersistState()
		{
			FormHelper.SaveState( this );
		}

		/// <summary>
		/// Restores the state.
		/// </summary>
		/// <returns>Returns TRUE if changed, FALSE otherwise.</returns>
		public bool RestoreState()
		{
			var bounds = Bounds;
			var state = WindowState;

			FormHelper.RestoreState( this );

			return bounds != Bounds || state != WindowState;
		}

		/// <summary>
		/// Restores the state.
		/// </summary>
		/// <returns>Returns TRUE if changed, FALSE otherwise.</returns>
		public bool RestoreState( int zoom )
		{
			var bounds = Bounds;
			var state = WindowState;

			FormHelper.RestoreState(
				this,
				new RestoreInformation
				{
					SuggestZoomPercent = zoom,
					//RespectWindowRatio = false
				} );

			return bounds != Bounds || state != WindowState;
		}

		public static string BuildKey(
			Control c )
		{
			var result = string.Empty;

			while ( c != null )
			{
				if ( !string.IsNullOrEmpty( result ) )
				{
					result = @"." + result;
				}

				result = c.Name + result;
			}

			return result;
		}

		public static void SaveState(
			XtraTabControl tabControl )
		{
			FormHelper.SaveValue( tabControl + @".Index", tabControl.SelectedTabPageIndex );
		}

		public static void RestoreState(
			XtraTabControl tabControl )
		{
			var index =
				ConvertHelper.ToInt32(
					FormHelper.RestoreValue( tabControl + @".Index", tabControl.SelectedTabPageIndex ),
					tabControl.SelectedTabPageIndex );

			if ( index < tabControl.TabPages.Count )
			{
				tabControl.SelectedTabPageIndex = index;
			}
		}

		public static void SaveState(
			SplitContainerControl splitContainer )
		{
			saveState( FormHelper.Storage, splitContainer );
		}

		public static void RestoreState(
			SplitContainerControl splitContainer )
		{
			restoreState( FormHelper.Storage, splitContainer );
		}

		private static void restoreState(
			IPersistentPairStorage storage,
			SplitContainerControl c )
		{
			var prefix = c.Name;

			var o1 = FormHelper.RestoreValue( storage, prefix + @".SplitterPosition" );
			var o2 = FormHelper.RestoreValue( storage, prefix + @".RealSplitterPosition" );
			var o3 = FormHelper.RestoreValue( storage, prefix + @".PercentageSplitterPosition" );
			var o4 = FormHelper.RestoreValue( storage, prefix + @".PanelVisibility" );

			if ( o4!=null)
			{
				var s4 =
					ConvertHelper.ToString(
						o4,
						SplitPanelVisibility.Both.ToString());

				c.PanelVisibility =
					(SplitPanelVisibility)
					Enum.Parse(typeof (SplitPanelVisibility), s4, true);
			}

			if ( o3 != null )
			{
				// New method, saving and restoring the percentage.
				// See http://bytes.com/forum/thread616388.html.

				var percentageDistance = ConvertHelper.ToDouble( o3, CultureInfo.InvariantCulture );

				if ( c.Horizontal )
				{
					var realDistance = (int)(c.Height * (percentageDistance / 100.0));
					if ( realDistance > 0 )
					{
						c.SplitterPosition = realDistance;
					}
				}
				else
				{
					var realDistance = (int)(c.Width * (percentageDistance / 100.0));
					if ( realDistance > 0 )
					{
						c.SplitterPosition = realDistance;
					}
				}
			}
			else if ( o1 != null && o2 != null )
			{
				var realDistance = Convert.ToInt32( o2 );

				if ( c.Horizontal )
				{
					if ( c.FixedPanel == SplitFixedPanel.Panel1 ||
						c.FixedPanel == SplitFixedPanel.None )
					{
						if ( realDistance > 0 )
						{
							c.SplitterPosition = realDistance;
						}
					}
					else
					{
						Debug.Assert(
							c.FixedPanel == SplitFixedPanel.Panel2,
							@"You must set one panel inside a splitter to be fixed." );

						if ( (c.Height - realDistance) > 0 )
						{
							c.SplitterPosition = c.Height - realDistance;
						}
					}
				}
				else
				{
					if ( c.FixedPanel == SplitFixedPanel.Panel1 ||
						c.FixedPanel == SplitFixedPanel.None )
					{
						if ( realDistance > 0 )
						{
							c.SplitterPosition = realDistance;
						}
					}
					else
					{
						Debug.Assert(
							c.FixedPanel == SplitFixedPanel.Panel2,
							@"FixedPanel must be Panel2." );

						if ( (c.Width - realDistance) > 0 )
						{
							c.SplitterPosition = c.Width - realDistance;
						}
					}
				}
			}
		}

		private static void saveState(
			IPersistentPairStorage storage,
			SplitContainerControl c )
		{
			int realDistance;
			double percentageDistance;

			if (c.Horizontal)
			{
				if (c.FixedPanel == SplitFixedPanel.Panel1 ||
				    c.FixedPanel == SplitFixedPanel.None)
				{
					realDistance = c.SplitterPosition;
				}
				else
				{
					Debug.Assert(
						c.FixedPanel == SplitFixedPanel.Panel2,
						@"FixedPanel must be Panel2.");

					realDistance = c.Height - c.SplitterPosition;
				}

				percentageDistance = ((double) c.SplitterPosition/c.Height)*100.0;
			}
			else
			{
				if (c.FixedPanel == SplitFixedPanel.Panel1 ||
				    c.FixedPanel == SplitFixedPanel.None)
				{
					realDistance = c.SplitterPosition;
				}
				else
				{
					Debug.Assert(
						c.FixedPanel == SplitFixedPanel.Panel2,
						@"FixedPanel must be Panel2.");

					realDistance = c.Width - c.SplitterPosition;
				}

				percentageDistance = ((double) c.SplitterPosition/c.Width)*100.0;
			}

			// --

			var prefix = c.Name;

			if (c.SplitterPosition > 0)
			{
				FormHelper.SaveValue(storage, prefix + @".SplitterPosition", c.SplitterPosition);
			}
			if (realDistance > 0)
			{
				FormHelper.SaveValue(storage, prefix + @".RealSplitterPosition", realDistance);
			}
			if (percentageDistance > 0)
			{
				FormHelper.SaveValue(storage, prefix + @".PercentageSplitterPosition",
				                     percentageDistance.ToString(CultureInfo.InvariantCulture));
			}

			FormHelper.SaveValue(
				storage,
				prefix + @".PanelVisibility",
				c.PanelVisibility.ToString());
		}
	}
}