﻿namespace ZetaResourceEditor.UI.Tools
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System;
	using System.IO;
	using System.Reflection;
	using Code.App;
	using DevExpress.XtraEditors.Controls;
	using Helper.Base;
	using Properties;

	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// Form to show copyright and version information about zeta producer.
	/// </summary>
	public partial class AboutForm :
		FormBase
	{
		#region Public methods.
		// ------------------------------------------------------------------

		/// <summary>
		///
		/// </summary>
		public AboutForm()
		{
			InitializeComponent();
		}

		// ------------------------------------------------------------------
		#endregion

		#region Event handler.
		// ------------------------------------------------------------------

		/// <summary>
		/// Handles the Load event of the AboutForm control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance 
		/// containing the event data.</param>
		private void AboutForm_Load(
			object sender,
			EventArgs e )
		{
			CenterToParent();

			label4.Text = label4.Text.
				Replace( @"{VersionNo}",
				string.Format(
				@"{0} ({1})",
				Assembly.GetExecutingAssembly().GetName().Version,
#if DEBUG
				@"DEBUG"
#else
 @"RELEASE"
#endif
 ) ).
				Replace( @"{BuildDate}",
				File.GetLastWriteTime( Assembly.GetExecutingAssembly().Location ).ToString( @"g" ) );
		}

		private void linkLabel1_Properties_Click( object sender, EventArgs e )
		{
			var sei =
				new ShellExecuteInformation
				{
					FileName =
					Resources.SR_AboutForm_linkLabel1LinkClicked_Httpwwwzetasoftwaredelinkszrehome
				};
			sei.Execute();
		}

		private void linkLabel1_OpenLink(object sender, OpenLinkEventArgs e)
		{
			linkLabel1_Properties_Click(null, null);
		}

		// ------------------------------------------------------------------
		#endregion
	}

	/////////////////////////////////////////////////////////////////////////
}