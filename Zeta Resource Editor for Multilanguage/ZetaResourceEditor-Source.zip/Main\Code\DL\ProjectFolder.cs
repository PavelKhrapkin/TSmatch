﻿namespace ZetaResourceEditor.Code.DL
{
	using System;
	using System.Collections.Generic;
	using System.IO;
	using System.Xml;
	using Helper;
	using Zeta.EnterpriseLibrary.Common;
	using Zeta.EnterpriseLibrary.Common.Collections;
	using Zeta.EnterpriseLibrary.Windows.Controls;

	public class ProjectFolder :
		ITranslationStateInformation,
		IComparable,
		IComparable<ProjectFolder>,
		IUniqueID,
		IOrderPosition,
		IInheritedSettings,
		IGridEditableData
	{
		public ProjectFolder(Project project)
		{
			_project = project;
		}

		private Project _project;
		private Guid _uniqueID = Guid.NewGuid();
		private Guid _parentUniqueID;
		private string _name;
		private int _orderPosition;

		private readonly DynSettings _dynSettings = new DynSettings();

		public bool UseParentFilePatternSettings
		{
			get
			{
				return ConvertHelper.ToBoolean(
					_dynSettings.RetrieveValue(@"UseParentFilePatternSettings"),
					true);
			}
			set
			{
				_dynSettings.PersistValue(@"UseParentFilePatternSettings", value.ToString());
			}
		}

		public int BaseNameDotCount
		{
			get
			{
				return ConvertHelper.ToInt32(
					_dynSettings.RetrieveValue(@"BaseNameDotCount"),
					0);
			}
			set
			{
				_dynSettings.PersistValue(@"BaseNameDotCount", value.ToString());
			}
		}

		public string NeutralLanguageFileNamePattern
		{
			get
			{
				var result = ConvertHelper.ToString(
					_dynSettings.RetrieveValue(@"NeutralLanguageFileNamePattern"));

				if (string.IsNullOrEmpty(result))
				{
					return @"[basename][optionaldefaulttypes].[extension]";
				}
				else
				{
					return result;
				}
			}
			set
			{
				_dynSettings.PersistValue(@"NeutralLanguageFileNamePattern", value);
			}
		}

		public string NonNeutralLanguageFileNamePattern
		{
			get
			{
				var result = ConvertHelper.ToString(
					_dynSettings.RetrieveValue(@"NonNeutralLanguageFileNamePattern"));

				if (string.IsNullOrEmpty(result))
				{
					return @"[basename][optionaldefaulttypes].[languagecode].[extension]";
				}
				else
				{
					return result;
				}
			}
			set
			{
				_dynSettings.PersistValue(@"NonNeutralLanguageFileNamePattern", value);
			}
		}

		public string[] DefaultFileTypesToIgnoreArray
		{
			get
			{
				var types = DefaultFileTypesToIgnore;
				if (string.IsNullOrEmpty(types))
				{
					return new string[] { };
				}
				else
				{
					var result = new Set<string>();

					foreach (var s in types.Split(
						new[] { @",", @";" },
						StringSplitOptions.RemoveEmptyEntries))
					{
						var t = s.Trim('*', ' ');
						if (!string.IsNullOrEmpty(t))
						{
							if (!t.StartsWith(@"."))
							{
								t = @"." + t;
							}

							result.Add(t);
						}
					}

					return result.ToArray();
				}
			}
		}

		public string DefaultFileTypesToIgnore
		{
			get
			{
				var result = ConvertHelper.ToString(
					_dynSettings.RetrieveValue(@"DefaultFileTypesToIgnore"));

				if (result == null)
				{
					return @".aspx;.ascx;.asmx;.master;.sitemap";
				}
				else
				{
					return result;
				}
			}
			set
			{
				_dynSettings.PersistValue(@"DefaultFileTypesToIgnore", value);
			}
		}


		FileFileInfo[] IGridEditableData.GetFileFileInfosSorted()
		{
			// Only returns the direct ones, not nested.

			var result = new List<FileFileInfo>();

			var cfg = _project.UseShallowGridDataCumulation ? ChildFileGroups : ChildFileGroupsDeep;
			cfg.ForEach(result.AddRange);

			result.Sort();
			return result.ToArray();
		}

		public IInheritedSettings ParentSettings
		{
			get
			{
				var p = Parent;
				if (p == null)
				{
					return _project;
				}
				else
				{
					return p;
				}
			}
		}

		FileGroupStates IGridEditableData.InMemoryState
		{
			get
			{
				var sfg = _project.UseShallowGridDataCumulation ? ChildFileGroups : ChildFileGroupsDeep;
				if (sfg.Count <= 0)
				{
					return FileGroupStates.Empty;
				}
				else
				{
					return sfg[0].InMemoryState;
				}
			}
			set
			{
				var sfg = _project.UseShallowGridDataCumulation ? ChildFileGroups : ChildFileGroupsDeep;
				if (sfg.Count > 0)
				{
					sfg[0].InMemoryState = value;
				}
			}
		}

		string[] IGridEditableData.FilePaths
		{
			get
			{
				var ss = new List<string>();

				foreach (var filePath in ((IGridEditableData)this).GetFileFileInfosSorted())
				{
					ss.Add(filePath.File.FullName);
				}

				return ss.ToArray();
			}
		}

		string IGridEditableData.JoinedFilePaths
		{
			get
			{
				return FileGroup.JoinFilePaths(
					((IGridEditableData)this).FilePaths);
			}
		}

		string[] IGridEditableData.GetLanguageCodes(Project project)
		{
			var result = new Set<string>();

			foreach (var filePath in ((IGridEditableData)this).FilePaths)
			{
				var lc =
					new LanguageCodeDetection(
						((IGridEditableData)this).Project).DetectLanguageCodeFromFileName(
						((IGridEditableData)this).ParentSettings,
						filePath);

				if (!string.IsNullOrEmpty(lc))
				{
					result.Add(lc.ToLowerInvariant());
				}
			}

			return result.ToArray();
		}

		public string GetFullNameIntelligent(Project project)
		{
			return null;
		}

		string IGridEditableData.GetNameIntelligent(Project project)
		{
			return _name;
		}

		public long GetChecksum(Project project)
		{
			return _uniqueID.GetHashCode();
		}

		public int EffectiveBaseNameDotCount
		{
			get
			{
				if (UseParentFilePatternSettings)
				{
					return ParentSettings.EffectiveBaseNameDotCount;
				}
				else
				{
					return BaseNameDotCount;
				}
			}
		}

		public string EffectiveNeutralLanguageFileNamePattern
		{
			get
			{
				if (UseParentFilePatternSettings)
				{
					return ParentSettings.EffectiveNeutralLanguageFileNamePattern;
				}
				else
				{
					return NeutralLanguageFileNamePattern;
				}
			}
		}

		public string EffectiveNonNeutralLanguageFileNamePattern
		{
			get
			{
				if (UseParentFilePatternSettings)
				{
					return ParentSettings.EffectiveNonNeutralLanguageFileNamePattern;
				}
				else
				{
					return NonNeutralLanguageFileNamePattern;
				}
			}
		}

		public string[] EffectiveDefaultFileTypesToIgnoreArray
		{
			get
			{
				if (UseParentFilePatternSettings)
				{
					return ParentSettings.EffectiveDefaultFileTypesToIgnoreArray;
				}
				else
				{
					return DefaultFileTypesToIgnoreArray;
				}
			}
		}

		public string EffectiveDefaultFileTypesToIgnore
		{
			get
			{
				if (UseParentFilePatternSettings)
				{
					return ParentSettings.EffectiveDefaultFileTypesToIgnore;
				}
				else
				{
					return DefaultFileTypesToIgnore;
				}
			}
		}

		public string EffectiveNeutralLanguageCode
		{
			get
			{
				// For now, always goes to the project directly.
				return _project.NeutralLanguageCode;
			}
		}

		public FileGroupStateColor TranslationStateColor
		{
			get
			{
				var result = FileGroupStateColor.None;

				foreach (var fileGroup in ChildFileGroups)
				{
					// Shortcut evaluation.
					if (result == FileGroupStateColor.Red ||
						result == FileGroupStateColor.Yellow)
					{
						return result;
					}

					result =
						FileGroup.CombineColorKeys(
							result,
							fileGroup.TranslationStateColor);
				}

				foreach (var projectFolder in ChildProjectFolders)
				{
					// Shortcut evaluation.
					if (result == FileGroupStateColor.Red ||
						result == FileGroupStateColor.Yellow)
					{
						return result;
					}

					result =
						FileGroup.CombineColorKeys(
							result,
							projectFolder.TranslationStateColor);
				}

				// --

				if (result == FileGroupStateColor.None)
				{
					return FileGroupStateColor.Grey;
				}
				else
				{
					return result;
				}
			}
		}

		public ProjectFolder Parent
		{
			get
			{
				return _project.GetProjectFolderByUniqueID(_parentUniqueID);
			}
			set
			{
				if (value == null)
				{
					_parentUniqueID = Guid.Empty;
				}
				else
				{
					_parentUniqueID = value._uniqueID;
				}
			}
		}

		public ProjectFolderCollection ChildProjectFolders
		{
			get
			{
				return _project.GetProjectFoldersByParentUniqueID(_uniqueID);
			}
		}

		public FileGroupCollection ChildFileGroups
		{
			get
			{
				return _project.GetFileGroupsByProjectFolderUniqueID(_uniqueID);
			}
		}

		public FileGroupCollection ChildFileGroupsDeep
		{
			get
			{
				var result = new FileGroupCollection(_project);

				result.AddRange(ChildFileGroups);

				foreach (var childProjectFolder in ChildProjectFolders)
				{
					result.AddRange(childProjectFolder.ChildFileGroupsDeep);
				}

				return result;
			}
		}

		public VirtualViewCollection ChildVirtualViews
		{
			get
			{
				return _project.GetVirtualViewsByProjectFolderUniqueID(_uniqueID);
			}
		}

		public string Name
		{
			get
			{
				return _name;
			}
			set
			{
				_name = value;
			}
		}

		public string Remarks { get; set; }

		public void StoreOrderPosition(AsynchronousMode asynchronousMode)
		{
			_project.MarkAsModified();
		}

		public int OrderPosition
		{
			get
			{
				return _orderPosition;
			}
			set
			{
				_orderPosition = value;
			}
		}

		public Guid UniqueID
		{
			get
			{
				return _uniqueID;
			}
		}

		public Guid ParentUniqueID
		{
			get
			{
				return _parentUniqueID;
			}
		}

		public string NameIntelli
		{
			get
			{
				var p = Parent;

				if (p == null)
				{
					return _project.Name + @" » " + Name;
				}
				else
				{
					return p.NameIntelli + @" » " + Name;
				}
			}
		}

		public GridSourceType SourceType
		{
			get { return GridSourceType.ProjectFolder; }
		}

		FileGroup IGridEditableData.FileGroup
		{
			get { return null; }
		}

		public Project Project
		{
			get
			{
				return _project;
			}
			set
			{
				_project = value;
			}
		}

		DirectoryInfo IGridEditableData.FolderPath
		{
			get
			{
				var r = ((IGridEditableData)this).GetFileFileInfosSorted();
				if (r.Length <= 0)
				{
					return null;
				}
				else
				{
					return r[0].File.Directory;
				}
			}
		}

		public FileGroupCollection FileGroupsDeep
		{
			get
			{
				var result = new FileGroupCollection(Project);

				foreach (var fg in Project.FileGroups)
				{
					if (fg.IsDeepChildOf(this))
					{
						result.Add(fg);
					}
				}

				return result;
			}
		}

		internal void LoadFromXml(
			XmlNode node)
		{
			XmlHelper.ReadAttribute(out _uniqueID, node.Attributes[@"uniqueID"]);
			XmlHelper.ReadAttribute(out _parentUniqueID, node.Attributes[@"parentUniqueID"]);
			XmlHelper.ReadAttribute(out _name, node.Attributes[@"name"]);
			XmlHelper.ReadAttribute(out _orderPosition, node.Attributes[@"orderPosition"]);

			var remarksNode = node.SelectSingleNode(@"remarks");
			if (remarksNode != null)
			{
				Remarks = remarksNode.InnerText;
			}
			else
			{
				Remarks = null;
			}

			var dynSettingsNode = node.SelectSingleNode(@"dynSettings");
			if (dynSettingsNode != null)
			{
				_dynSettings.LoadFromXml(dynSettingsNode);
			}
		}

		internal void StoreToXml(
			XmlElement node)
		{
			var a = node.OwnerDocument.CreateAttribute(@"uniqueID");
			a.Value = _uniqueID.ToString();
			node.Attributes.Append(a);

			a = node.OwnerDocument.CreateAttribute(@"parentUniqueID");
			a.Value = _parentUniqueID.ToString();
			node.Attributes.Append(a);

			a = node.OwnerDocument.CreateAttribute(@"name");
			a.Value = _name;
			node.Attributes.Append(a);

			a = node.OwnerDocument.CreateAttribute(@"orderPosition");
			a.Value = _orderPosition.ToString();
			node.Attributes.Append(a);

			var remarksNode =
				node.OwnerDocument.CreateElement(@"remarks");
			node.AppendChild(remarksNode);
			remarksNode.InnerText = Remarks;

			var dynSettingsNode =
				node.OwnerDocument.CreateElement(@"dynSettings");
			node.AppendChild(dynSettingsNode);

			_dynSettings.StoreToXml(dynSettingsNode);
		}

		public int CompareTo(object obj)
		{
			return CompareTo((ProjectFolder)obj);
		}

		public int CompareTo(ProjectFolder other)
		{
			var a = _orderPosition.CompareTo(other._orderPosition);

			if (a == 0)
			{
				return Name.CompareTo(other.Name);
			}
			else
			{
				return a;
			}
		}
	}
}