﻿namespace ZetaResourceEditor.UI.Helper.ExtendedControls
{
	#region Using directives.
	// ----------------------------------------------------------------------

	using System.Collections.Generic;
	using System.Windows.Forms;
	using Zeta.EnterpriseLibrary.Windows.Controls;

	// ----------------------------------------------------------------------
	#endregion

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// 
	/// </summary>
	public partial class ExtendedTreeViewControl :
		TriStateCheckBoxesTreeView
	{
		#region Navigating.
		// ------------------------------------------------------------------

		/// <summary>
		/// Navigates the forward.
		/// </summary>
		public void NavigateForward()
		{
			var cursor = _navigationList.NavigateForward();

			// when the new moved to is invalid
			// (e.g. when it was deleted), move as long as a valid found.
			while ( cursor == null && !_navigationList.IsEmpty )
			{
				cursor = _navigationList.NavigateForward();
				_navigationList.DeletePrevious();
			}

			if ( cursor != null && !_navigationList.IsEmpty )
			{
				_navigationList.Ignore = true;
				SelectedNode = cursor;
				cursor.EnsureVisible();
				_navigationList.Ignore = false;
			}
		}

		/// <summary>
		/// Navigates the backward.
		/// </summary>
		public void NavigateBackward()
		{
			TreeNode cursor = _navigationList.NavigateBackward();

			// when the new moved to is invalid
			// (e.g. when it was deleted), move as long as a valid found.
			while ( cursor == null && !_navigationList.IsEmpty )
			{
				cursor = _navigationList.NavigateBackward();
				_navigationList.DeleteNext();
			}

			if ( cursor != null && !_navigationList.IsEmpty )
			{
				_navigationList.Ignore = true;
				SelectedNode = cursor;
				cursor.EnsureVisible();
				_navigationList.Ignore = false;
			}
		}

		/// <summary>
		/// Gets a value indicating whether this instance can navigate forward.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if this instance can navigate forward; otherwise, <c>false</c>.
		/// </value>
		public bool CanNavigateForward
		{
			get
			{
				return _navigationList.CanNavigateForward;
			}
		}

		/// <summary>
		/// Gets a value indicating whether this instance can navigate backward.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if this instance can navigate backward; otherwise, <c>false</c>.
		/// </value>
		public bool CanNavigateBackward
		{
			get
			{
				return _navigationList.CanNavigateBackward;
			}
		}

		/// <summary>
		/// Clears the navigation list.
		/// </summary>
		public void ClearNavigationList()
		{
			_navigationList.ClearAll();
		}

		/// <summary>
		/// 
		/// </summary>
		private readonly TreeNavigationList _navigationList =
			new TreeNavigationList();

		// ------------------------------------------------------------------
		#endregion

		#region Public methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// Initializes a new instance of the 
		/// <see cref="ExtendedTreeViewControl"/> class.
		/// </summary>
		public ExtendedTreeViewControl()
		{
			InitializeComponent();
		}

		// ------------------------------------------------------------------
		#endregion

		#region Helper class for traversing.
		// ------------------------------------------------------------------

		/// <summary>
		/// 
		/// </summary>
		private class TreeTraverserDelegateWrapper :
			ITreeTraverser
		{
			#region Public methods.

			/// <summary>
			/// Initializes a new instance of the <see cref="TreeTraverserDelegateWrapper"/> class.
			/// </summary>
			/// <param name="traverser">The traverser.</param>
			public TreeTraverserDelegateWrapper(
				TreeTraverser traverser )
			{
				_traverser = traverser;
			}

			#endregion

			#region ITreeTraverser members.

			/// <summary>
			/// Callback for traversing the nodes of the tree view.
			/// </summary>
			/// <param name="node">The node.</param>
			/// <param name="tag">The tag.</param>
			/// <returns></returns>
			public ContinueType TraverseNode(
				TreeNode node,
				object tag )
			{
				return _traverser( node );
			}

			#endregion

			#region Private variables.

			private readonly TreeTraverser _traverser;

			#endregion
		}

		// ------------------------------------------------------------------
		#endregion

		#region Traversing.
		// ------------------------------------------------------------------

		/// <summary>
		/// Recursively traverse.
		/// </summary>
		/// <param name="rootNode">The root node.</param>
		/// <param name="traverser">The interface to be called upon
		/// traversing.</param>
		public void Traverse(
			TreeNode rootNode,
			TreeTraverser traverser )
		{
			Traverse(
				rootNode,
				new TreeTraverserDelegateWrapper( traverser ),
				null );
		}

		/// <summary>
		/// Recursively traverse.
		/// </summary>
		/// <param name="traverser">The interface to be called upon
		/// traversing.</param>
		public void Traverse(
			TreeTraverser traverser )
		{
			Traverse(
				new TreeTraverserDelegateWrapper( traverser ),
				null );
		}

		/// <summary>
		/// Recursively traverse.
		/// </summary>
		/// <param name="rootNode">The root node.</param>
		/// <param name="traverser">The interface to be called upon
		/// traversing.</param>
		public void Traverse(
			TreeNode rootNode,
			ITreeTraverser traverser )
		{
			Traverse( rootNode, traverser, null );
		}

		/// <summary>
		/// Recursively traverse.
		/// </summary>
		/// <param name="traverser">The interface to be called upon 
		/// traversing.</param>
		public void Traverse(
			ITreeTraverser traverser )
		{
			Traverse( traverser, null );
		}

		/// <summary>
		/// Recursively.
		/// </summary>
		/// <param name="traverser">The interface to be called upon
		/// traversing.</param>
		/// <param name="tag">A custom item to be passed to the traverser
		/// interface.</param>
		public void Traverse(
			ITreeTraverser traverser,
			object tag )
		{
			if ( Nodes.Count > 0 )
			{
				protectDoTraverse(
					Nodes[0],
					traverser,
					tag,
					true );
			}
		}

		/// <summary>
		/// Recursively.
		/// </summary>
		/// <param name="rootNode">The root node.</param>
		/// <param name="traverser">The interface to be called upon
		/// traversing.</param>
		/// <param name="tag">A custom item to be passed to the traverser
		/// interface.</param>
		public void Traverse(
			TreeNode rootNode,
			ITreeTraverser traverser,
			object tag )
		{
			protectDoTraverse(
				rootNode,
				traverser,
				tag,
				false );
		}

		/// <summary>
		/// Don't recursively traverse.
		/// </summary>
		private bool _isTraversing;

		/// <summary>
		/// Don't recursively traverse.
		/// </summary>
		/// <param name="treeNode">The tree node.</param>
		/// <param name="traverser">The traverser.</param>
		/// <param name="tag">The tag.</param>
		/// <param name="traverseSiblings">if set to <c>true</c> [traverse siblings].</param>
		private void protectDoTraverse(
			TreeNode treeNode,
			ITreeTraverser traverser,
			object tag,
			bool traverseSiblings )
		{
			if ( !_isTraversing )
			{
				_isTraversing = true;
				try
				{
					doTraverse( treeNode, traverser, tag, traverseSiblings );
				}
				finally
				{
					_isTraversing = false;
				}
			}
		}

		/// <summary>
		/// Does the traverse.
		/// </summary>
		/// <param name="treeNode">The tree node.</param>
		/// <param name="traverser">The traverser.</param>
		/// <param name="tag">The tag.</param>
		/// <param name="traverseSiblings">if set to <c>true</c> [traverse siblings].</param>
		/// <returns></returns>
		private static ContinueType doTraverse(
			TreeNode treeNode,
			ITreeTraverser traverser,
			object tag,
			bool traverseSiblings )
		{
			if ( treeNode != null )
			{
				// Call traverser.
				if ( traverser.TraverseNode( treeNode, tag ) ==
					ContinueType.Continue )
				{
					// Direct childs.
					foreach ( TreeNode node in treeNode.Nodes )
					{
						if ( doTraverse( node, traverser, tag, false ) ==
							ContinueType.Abort )
						{
							return ContinueType.Abort;
						}
					}

					// My siblings.
					if ( traverseSiblings )
					{
						treeNode = treeNode.NextNode;
						while ( treeNode != null )
						{
							if ( doTraverse( treeNode, traverser, tag, false )
								== ContinueType.Abort )
							{
								return ContinueType.Abort;
							}
							treeNode = treeNode.NextNode;
						}
					}
				}

				return ContinueType.Continue;
			}
			else
			{
				return ContinueType.Abort;
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Public operations.
		// ------------------------------------------------------------------

		/// <summary>
		/// Moves the specified node up by one,
		/// staying in the same level.
		/// Wraps if at the top.
		/// </summary>
		/// <param name="node">The node to move up by one.</param>
		public void MoveNodeSiblingUpByOne(
			TreeNode node )
		{
			//using ( new TemporaryRedrawPauser( this))
			{
				TreeNodeCollection siblings =
					node.Parent == null ?
					node.TreeView.Nodes :
					node.Parent.Nodes;

				int nodeIndex = siblings.IndexOf( node );

				siblings.RemoveAt( nodeIndex );

				int newNodeIndex = nodeIndex - 1;
				if ( newNodeIndex < 0 )
				{
					siblings.Add( node );
				}
				else
				{
					siblings.Insert( newNodeIndex, node );
				}
			}
		}

		/// <summary>
		/// Moves the specified node down by one, 
		/// staying in the same level.
		/// Wraps if at the top.
		/// </summary>
		/// <param name="node">The node to move up by one.</param>
		public void MoveNodeSiblingDownByOne(
			TreeNode node )
		{
			//using ( new TemporaryRedrawPauser( this ) )
			{
				TreeNodeCollection siblings =
					node.Parent == null ?
					node.TreeView.Nodes :
					node.Parent.Nodes;

				int nodeIndex = siblings.IndexOf( node );

				siblings.RemoveAt( nodeIndex );

				int newNodeIndex = nodeIndex + 1;
				if ( newNodeIndex > siblings.Count )
				{
					siblings.Insert( 0, node );
				}
				else if ( newNodeIndex == siblings.Count )
				{
					siblings.Add( node );
				}
				else
				{
					siblings.Insert( newNodeIndex, node );
				}
			}
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="path">The path with the TEXT values 
		/// of the nodes.</param>
		public void SelectNodePath(
			string[] path )
		{
			SelectNodePath( path, false );
		}

		/// <summary>
		/// Selects the node path.
		/// </summary>
		/// <param name="path">The path with the TEXT values
		/// of the nodes.</param>
		/// <param name="ignoreCase">if set to <c>true</c> [ignore case].</param>
		public void SelectNodePath(
			string[] path,
			bool ignoreCase )
		{
			if ( path != null && path.Length > 0 )
			{
				TreeNode node = null;

				foreach ( string p in path )
				{
					TreeNode newNode =
						FindChildNodeByText( node, p, ignoreCase );

					if ( newNode == null )
					{
						break;
					}

					node = newNode;
				}

				// Any found?
				if ( node != null )
				{
					SelectedNode = node;
				}
			}
		}

		/// <summary>
		/// Finds the child node by text.
		/// </summary>
		/// <param name="parentNode">The parent node.</param>
		/// <param name="text">The text.</param>
		/// <param name="ignoreCase">if set to <c>true</c> [ignore case].</param>
		/// <returns></returns>
		protected virtual TreeNode FindChildNodeByText(
			TreeNode parentNode,
			string text,
			bool ignoreCase )
		{
			TreeNodeCollection nodes;

			// On root.
			if ( parentNode == null )
			{
				nodes = Nodes;
			}
			else
			{
				nodes = parentNode.Nodes;
			}

			foreach ( TreeNode node in nodes )
			{
				if ( string.Compare( text, node.Text, ignoreCase ) == 0 )
				{
					return node;
				}
			}

			return null;
		}

		/// <summary>
		/// Checks whether '<paramref name="itemToCheck"/>' is a child 
		/// of '<paramref name="potentiallyParentItem"/>'.
		/// </summary>
		public bool IsChildNodeOf(
			TreeNode itemToCheck,
			TreeNode potentiallyParentItem )
		{
			if ( itemToCheck == null || potentiallyParentItem == null )
			{
				return false;
			}
			else
			{
				while ( itemToCheck != null )
				{
					if ( itemToCheck == potentiallyParentItem )
					{
						return true;
					}
					else
					{
						itemToCheck = itemToCheck.Parent;
					}
				}

				return false;
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Public properties.
		// ------------------------------------------------------------------

		/// <summary>
		/// Get the name of the nodes from root until the selected node 
		/// (including).
		/// Returns NULL if none.
		/// </summary>
		public string[] CurrentSelectedNodePath
		{
			get
			{
				if ( SelectedNode == null )
				{
					return null;
				}
				else
				{
					var result = new List<string>();

					var node = SelectedNode;

					while ( node != null )
					{
						result.Add( node.Text );

						node = node.Parent;
					}

					result.Reverse();

					// --

					if ( result.Count <= 0 )
					{
						return null;
					}
					else
					{
						return result.ToArray();
					}
				}
			}
		}

		/// <summary>
		/// Gets a value indicating whether [was double click].
		/// </summary>
		/// <value><c>true</c> if [was double click]; otherwise, <c>false</c>.</value>
		public bool WasDoubleClick
		{
			get
			{
				return _wasDoubleClick;
			}
			set
			{
				_wasDoubleClick = value;
			}
		}

		// ------------------------------------------------------------------
		#endregion

		private bool _wasDoubleClick;
		private const int WM_LBUTTONDBLCLK = 0x203;

		protected override void WndProc( ref Message m )
		{
			// http://groups.google.com/group/microsoft.public.dotnet.framework.windowsforms/msg/d16ac686dc6b42?hl=en&lr=&ie=UTF-8
			if ( m.Msg == WM_LBUTTONDBLCLK )
			{
				_wasDoubleClick = true;
			}

			base.WndProc( ref m );
		}

		/// <summary>
		/// Raises the <see cref="E:System.Windows.Forms.TreeView.AfterSelect"></see> event.
		/// </summary>
		/// <param name="e">A <see cref="T:System.Windows.Forms.TreeViewEventArgs"></see>
		/// that contains the event data.</param>
		protected override void OnAfterSelect(
			TreeViewEventArgs e )
		{
			base.OnAfterSelect( e );

			_navigationList.NotifyJumpedTo( e.Node );
		}

		#region Private variables.
		// ------------------------------------------------------------------

		protected bool _hasEverSetLastSelectedTreeNode;
		protected TreeNode _lastSelectedTreeNode;

		// ------------------------------------------------------------------
		#endregion
	}

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// Delegate to traverse a tree.
	/// </summary>
	/// <param name="node"></param>
	/// <returns></returns>
	public delegate ContinueType TreeTraverser(
		TreeNode node );

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// Interface for traversing a tree view control.
	/// </summary>
	public interface ITreeTraverser
	{
		#region Interface members.
		// ------------------------------------------------------------------

		/// <summary>
		/// Callback for traversing the nodes of the tree view.
		/// </summary>
		/// <param name="node">The node.</param>
		/// <param name="tag">The tag.</param>
		/// <returns></returns>
		ContinueType TraverseNode(
			TreeNode node,
			object tag );

		// ------------------------------------------------------------------
		#endregion
	}

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// How to continue from a callback.
	/// </summary>
	public enum ContinueType
	{
		#region Enum members.
		// ------------------------------------------------------------------

		/// <summary>
		/// 
		/// </summary>
		Continue,

		/// <summary>
		/// 
		/// </summary>
		Abort

		// ------------------------------------------------------------------
		#endregion
	}

	/////////////////////////////////////////////////////////////////////////

	/// <summary>
	/// Navigation class. Useful for implementing navigation history 
	/// feature for tree view controls.
	/// </summary>
	internal class TreeNavigationList
	{
		#region Public methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// 
		/// </summary>
		public void ClearAll()
		{
			_itemList.Clear();
			_currentItemIndex = 0;
		}

		/// <summary>
		/// 
		/// </summary>
		public void DeletePrevious()
		{
			if ( CanNavigateBackward )
			{
				_itemList.RemoveAt( _currentItemIndex - 1 );
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public void DeleteNext()
		{
			if ( CanNavigateForward )
			{
				_itemList.RemoveAt( _currentItemIndex + 1 );
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public TreeNode NavigateForward()
		{
			if ( CanNavigateForward )
			{
				_currentItemIndex++;
			}

			return CurrentItem;
		}

		/// <summary>
		/// 
		/// </summary>
		public TreeNode NavigateBackward()
		{
			if ( CanNavigateBackward )
			{
				_currentItemIndex--;
			}

			return CurrentItem;
		}

		/// <summary>
		/// 
		/// </summary>
		public void NotifyJumpedTo(
			TreeNode dst )
		{
			if ( !_ignoreNotifications )
			{
				deleteAfterPos( _currentItemIndex );

				_itemList.Add( dst );

				_currentItemIndex = _itemList.Count - 1;

				// max # of entries.
				while ( _itemList.Count > _MAXIMUMENTRIES )
				{
					_itemList.RemoveAt( 0 );
				}
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public void NotifyRemoved(
			TreeNode item )
		{
			if ( !_ignoreNotifications )
			{
				int pos = _itemList.IndexOf( item );

				if ( pos >= 0 )
				{
					_itemList.RemoveAt( pos );
				}
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Public properties.
		// ------------------------------------------------------------------

		/// <summary>
		/// 
		/// </summary>
		public bool Ignore
		{
			get
			{
				return _ignoreNotifications;
			}
			set
			{
				_ignoreNotifications = value;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public bool IsEmpty
		{
			get
			{
				return _itemList.Count <= 0;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public bool HasCurrentItem
		{
			get
			{
				return _itemList.Count > 0 &&
					_currentItemIndex >= 0 &&
					_currentItemIndex < _itemList.Count;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public bool CanNavigateForward
		{
			get
			{
				return
					_currentItemIndex + 1 >= 0 &&
					_currentItemIndex < _itemList.Count - 1;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public bool CanNavigateBackward
		{
			get
			{
				return _itemList.Count > 0 && _currentItemIndex > 0;
			}
		}

		/// <summary>
		/// 
		/// </summary>
		public TreeNode CurrentItem
		{
			get
			{
				if ( HasCurrentItem )
				{
					return _itemList[_currentItemIndex];
				}
				else
				{
					return null;
				}
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Private methods.
		// ------------------------------------------------------------------

		/// <summary>
		/// 
		/// </summary>
		private void deleteAfterPos(
			int pos )
		{
			if ( pos + 1 < _itemList.Count )
			{
				_itemList.RemoveRange(
					pos + 1,
					_itemList.Count - (pos + 1) );
			}
		}

		// ------------------------------------------------------------------
		#endregion

		#region Private variables.
		// ------------------------------------------------------------------

		private readonly List<TreeNode> _itemList = new List<TreeNode>();
		private int _currentItemIndex;
		private bool _ignoreNotifications;

		/// <summary>
		/// 
		/// </summary>
		private const int _MAXIMUMENTRIES = 1000;

		// ------------------------------------------------------------------
		#endregion
	}

	/////////////////////////////////////////////////////////////////////////
}