﻿namespace ZetaResourceEditor.Code.Helper
{
    internal enum ImportExportType
    {
        Excel,
    }
}