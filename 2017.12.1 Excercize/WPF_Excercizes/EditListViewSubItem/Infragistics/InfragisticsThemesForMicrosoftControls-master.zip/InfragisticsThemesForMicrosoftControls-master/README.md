# Infragistics Themes For Microsoft Controls
Free Infragistics themes for WPF and Silverlight Microsoft controls.  This includes the Infragistics IG Theme, Metro Theme, Metro Dark Theme, Office 2010 Blue Theme, and Office 2013 Theme.

Note: The Office2013 Theme is not avialable for Silverlight

A big thank you to Infragistics (http://www.infragistics.com) for providing these themes to the community.

# Install using NuGet:

WPF:

https://www.nuget.org/packages/Infragistics.Themes.IG.Wpf/
https://www.nuget.org/packages/Infragistics.Themes.MetroDark.Wpf/
https://www.nuget.org/packages/Infragistics.Themes.MetroLight.Wpf/
https://www.nuget.org/packages/Infragistics.Themes.Office2010Blue.Wpf/
https://www.nuget.org/packages/Infragistics.Themes.Office2013.Wpf/

Silverlight:

https://www.nuget.org/packages/Infragistics.Themes.IG.SL/
https://www.nuget.org/packages/Infragistics.Themes.MetroDark.SL/
https://www.nuget.org/packages/Infragistics.Themes.MetroLight.SL/
https://www.nuget.org/packages/Infragistics.Themes.Office2010Blue.SL/
