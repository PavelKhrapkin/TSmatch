﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Xbim.DPoW
{
    public enum AreaUnits
    {
        UNDEFINED,
        squarecentimeters,
        squarefeet,
        squareinches,
        squarekilometers,
        squaremeters,
        squaremiles,
        squaremillimeters,
        squareyards
    }
}
