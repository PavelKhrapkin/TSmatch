﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Xbim.DPoW
{
    public enum LinearUnits
    {
        UNDEFINED,
        centimeters,
        feet,
        inches,
        kilometers,
        meters,
        miles,
        millimeters,
        yards
    }
}
