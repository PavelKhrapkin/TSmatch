﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xbim.DPoW;
using Xbim.COBieLiteUK;

namespace XbimExchanger.DPoWToCOBieLiteUK
{
    class MappingSpaceTypeToZone : MappingDPoWObjectToCOBieObject<SpaceType, Zone>
    {
        //implement any eventual specialities here
    }
}
