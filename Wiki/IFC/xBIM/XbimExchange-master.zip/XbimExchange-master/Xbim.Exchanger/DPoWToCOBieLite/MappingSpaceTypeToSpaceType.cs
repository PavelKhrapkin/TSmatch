﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xbim.DPoW;
using Space = Xbim.COBieLite.SpaceType;

namespace XbimExchanger.DPoWToCOBieLite
{
    class MappingSpaceTypeToSpaceType : MappingDPoWObjectToCOBieObject<SpaceType, Space>
    {
        //implement any eventual specialities here
    }
}
