﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xsd2Code.Library.Helpers;

namespace Xsd2Code.Library
{

    /// <summary>
    /// Generator extension factory class 
    /// </summary>
    /// <remarks>
    /// Revision history:
    /// 
    ///     Created 2009-03-16 by Ruslan Urban
    /// 
    /// </remarks>
    internal static class CodeExtensionFactory
    {
        
    }
}
